// Aba "0. FAZER PRIMEIRO": o menor conjunto de lançamentos que já fecha a meta de 0,5% em todo mês.
// O resto (abas 1 a 9) continua valendo, mas pode esperar a próxima rodada.
module.exports = function ({ wb, titulo, cab, lin, F, fill, r2, COR, MONEY, nomeConta }) {
  const calcular = require('./prioridade.js');
  const { flat, resumoMeses, totalAcoesCompletas } = calcular();
  const M = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'];
  const fmt = v => 'R$ ' + Math.round(Math.abs(v)).toLocaleString('pt-BR');

  const ws = wb.addWorksheet('0. FAZER PRIMEIRO');
  ws.columns = [{ width: 8 }, { width: 44 }, { width: 15 }, { width: 30 }, { width: 22 }, { width: 90 }];
  titulo(ws, 'Fazer primeiro — o mínimo para fechar a meta (prazo curto)', 'Só ' + flat.length + ' lançamentos (de ' + totalAcoesCompletas + ' no total) já colocam todos os 6 meses dentro de 0,5% de diferença do gerencial. São os maiores valores, escolhidos para render o máximo com o menor número de lançamentos, sempre com o par completo (quando um lançamento provisiona em um mês, o lançamento que baixa em outro mês está junto aqui). O resto das abas (1 a 9) continua certo e pode ser feito depois, sem pressa.', 6);

  let r = 4;
  cab(ws, r, ['', 'Mês', 'Diferença hoje', 'Meta (±0,5%)', 'Diferença após os lançamentos', 'Situação']); r++;
  resumoMeses.forEach(x => {
    const ok = x.ok;
    lin(ws, r, ['', x.mes, x.gapAntes, r2(x.budget), x.gapDepois, ok ? '✅ dentro da meta' : '⚠ ainda fora'],
      { money: [2, 3, 4], fill: { 5: ok ? COR.VERDE : COR.AMARELO } });
    r += 1;
  });
  r += 1;

  ws.getCell(r, 1).value = 'Os ' + flat.length + ' lançamentos (nesta ordem: mês, depois maior valor primeiro)';
  ws.getCell(r, 1).font = F({ bold: true, size: 12, color: { argb: COR.NAVY } });
  r += 2;

  const h = r;
  cab(ws, h, ['Mês', 'Fornecedor', 'Valor', 'Conta', 'Tipo', 'O que fazer']);
  ws.views = [{ state: 'frozen', ySplit: h }];
  const COR_TIPO = {
    'COMPETÊNCIA 2025': COR.LILAS, 'ESTORNAR PROVISÃO': COR.VERMELHO, 'EXCLUIR DUPLICADO': COR.VERMELHO,
    'PROVISIONAR': COR.LARANJA, 'BAIXAR PROVISÃO': COR.LARANJA, 'REVERTER (NF adiantada)': COR.LARANJA, 'RECLASSIFICAR': COR.AZUL,
  };
  const ord = (a, b) => M.indexOf(a.mes) - M.indexOf(b.mes) || Math.abs(b.valor) - Math.abs(a.valor);
  flat.sort(ord).forEach((a, i) => {
    const row = ws.getRow(h + 1 + i);
    const conta = (a.tipo === 'RECLASSIFICAR' ? a.conta + ' → ' + a.contaPara : a.conta) + ' ' + (nomeConta[a.conta] || '');
    row.values = [a.mes, a.entidade, a.valor, conta, a.tipo, a.texto];
    row.font = F({ size: 10 });
    row.getCell(3).numFmt = MONEY;
    row.getCell(5).fill = fill(COR_TIPO[a.tipo] || COR.CINZA);
    row.alignment = { wrapText: true, vertical: 'top' };
    row.height = Math.min(60, 16 * Math.ceil(a.texto.length / 90));
  });
  ws.autoFilter = { from: { row: h, column: 1 }, to: { row: h + flat.length, column: 6 } };
};
