# Conciliação Contábil × Gerencial — processo mensal (Jusfy)

Objetivo: o DRE contábil (soma das contas do razão da Syhus) bater com o P&L gerencial por competência, **fornecedor por fornecedor**. O arquivo de saída diz à Syhus exatamente o que lançar; a Syhus só escritura.

## Entradas (todo mês)
1. `Razão01..NN.xlsx` da Syhus (um por mês, aba "Razão").
2. P&L por fornecedor (base gerencial) — hoje `gerencial_fornecedor.json`; conferir que soma o P&L oficial por sublinha (diferença tem que ser zero).
3. Realizado ERP por pessoa (`real_erp.json`), Cadastro People (`real_cadastro.json`), base de distratos (`base_mari_distratos.json`).

## Como rodar (Node, pasta `work/`)
```
npm install xlsx exceljs
node parse_razao.js     # lê os razões; confere cada conta contra o "Total do mês"
node normalizar.js      # fornecedor, tipo (provisão/NF/cartão/banco/reversão/estorno) e NF de cada linha
node casar.js           # casa fornecedor do P&L com fornecedor do razão
node folha.js           # folha PJ por pessoa (razão × ERP + distratos), conta certa pela área
node analisar.js        # aplica as regras de achado
node gerar_v4.js        # gera o Excel para a Syhus (usa quadro_dados.js e abas_v4.js: quadro mensal, linha a linha, notas)
node quadro_dados.js    # confere o quadro mensal (P&L + painel People × razão antes/depois) e a composição da diferença
```
Para um mês novo: acrescentar o arquivo em `FILES` no `parse_razao.js` e o mês em `MESES` nos scripts.

## Regras (arquivo `regras.js` — é o que se "guarda" de um mês para o outro)
- **Leitura do razão**: Débito coluna I, Crédito coluna J; excluir "Encerramento do exercício/zeramento". Se a soma não bater com o "Total do mês", parar.
- **Fornecedor da linha**: "nota fiscal nº X do fornecedor NOME" → senão contrapartida "NNN - NOME" (se não for banco/cartão/provisão) → senão formatos de cartão/boleto. Cuidado: "Banco de Dados" (Digesto) não é banco.
- **Casamento com o P&L**: por nome (≥ metade das palavras significativas). Plataformas de mídia por conta. Linhas agregadas do P&L (Hotels, Taxi, Supplies…) pela conta. De-paras confirmados em `ALIAS` (Treble = Messaging & Live Chat; Candia; Timework = Timework+WeWork; Microsoft do Brasil = Microsoft Ads; GCP = Google Cloud; CDL = Sede Nova…).
- **PJ com nome de empresa diferente** (`VINCULO_PJ`): só com prova de valor mensal idêntico ao ERP (ex.: DKSWEB = Deyvid Kenid, 6 meses iguais).
- **Conta certa**: árvore oficial do DRE (sublinha → conta). Folha: Engenharia/Produto = 6.2.1.01.001; demais = 4.1.6.01.007.
- **Competência da NF** (atribuição ótima NF × mês): cada NF vai para o mês do gerencial (folha: do ERP, incluindo dez/2025 e jul/2026) de valor idêntico (até R$ 2 de arredondamento), com até 4 meses de atraso ou 1 de adiantamento; valor só aproximado (±0,5%) vale apenas no próprio mês. Sem valor idêntico: a reversão que cita a NF. Senão o mês do lançamento.
- **Data de 2025 no histórico** (baixa de adiantamento, estorno de NF de 2025, "exercício anterior"): sai de 2026 quando o gerencial do mês não tem esse valor; fornecedor sem par no P&L sai sempre.
- **NF repetida**: duas NFs do mesmo valor no mesmo mês com o gerencial/ERP tendo uma só → excluir a de número maior; em jan (ou fornecedor que fatura com atraso) a de número menor é de 2025. Pagamento (cartão/banco) que cita o número de uma NF já lançada = despesa em dobro. Parcelas diferentes (PARC 1/2 × 2/2) não são duplicidade.
- **Distrato**: usar o mês do P&L (painel People, Contract Termination) quando a soma do mês só fecha com a troca.
- **Achados** (nesta ordem): trocar de conta → excluir duplicado (mesma NF 2x; NF + cartão do mesmo valor; NF formal = soma de 1–3 cobranças já lançadas; adiantamento lançado como despesa) → estornar provisão sem baixa → competência 2025 → provisionar/baixar por fornecedor → falta lançar.
- **Não se ajusta sem prova**: o que sobra vira "Pedir NF"; fornecedor do razão sem par vira "Sem par no gerencial"; diferença estrutural conhecida (Pagar.me) vira nota.
- **Nunca confiar no "Ok, ajustado" da Syhus**: todo mês conferir os ajustes pedidos no mês anterior contra o razão novo (aba 9).
- Tolerância: R$ 50 por fornecedor/mês.

## Achados desta rodada (jan–jun/2026) que viram regra
- Digesto, VIR, Nova DD, Judit, Carbigdata continuam em 6.2.1.03.002 (licença) e são APIs (6.2.1.03.003), apesar de marcados "Ok" na v2.
- Treble: NFs 291 e 293 de mai repetem faturas de jan/mar/abr já pagas no cartão (soma bate no centavo).
- Amazon AWS: fatura sempre 1 mês depois → provisão todo mês.
- Digesto: provisão estimada ≠ NF real todo mês → complementar; mai ficou sem provisão.
- Bônus/NFs de dez/2025 lançados em jan/2026 (competência 2025).
- HAGROEX = Hugo Bretz Cabral Hennies (Engenharia): resolvida a ressalva "pedir NF 155/159".
- Microsoft do Brasil em licença de software é Microsoft Ads.
- "Other Marketing Expenses" no P&L extraído repetia as filhas de BAR Associations — excluir da régua.


## Rodada de set/2026 (v4) — o que mudou
- Aba **Razão linha a linha**: todas as 13.509 linhas das contas 4.1/6.2 com status (✅ certo, ❌ conta errada / em dobro / de 2025 / provisão sem baixa / CAPEX, 🕒 mês errado, ⚠ sem prova / sem par, ℹ fora do DRE operacional) e o que fazer.
- **Resumo** com a régua completa (P&L por fornecedor + painel People) e a composição da diferença que sobra (Pagar.me, distratos de jun fora do P&L, sem prova, sem par, arredondamento).
- Aba **Notas explicativas**: Pagar.me, distratos de jun, Google Ads NF × gerencial, LinkedIn, Selki/JOINVIX, Syhus jan, treinamentos, bolsa-estágio, fornecedor trocado (ROLE/ZEE, Junqueira/Capi Candia), vínculos PJ.
- Descoberto nesta rodada: 156 baixas de adiantamento de 2025 lançadas em fev/2026 (R$ 126,6 mil); estornos de NFs de 2025 lançados em mai/2026; PJs que faturam 1 mês depois (NF de dez/2025 em jan); NFs de salário em dobro (Douglas, Rodrigo Trindade, Katsurayama); NF de jul lançada em jun (Larissa, Adriel); pagamento que cita NF já lançada (Cloud Humans, Guia da Alma).
