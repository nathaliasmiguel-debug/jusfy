# Conciliação Contábil × Gerencial — processo mensal (Jusfy)

Objetivo: o DRE contábil (soma das contas do razão da Syhus) bater com o P&L gerencial por competência, **fornecedor por fornecedor**. O arquivo de saída diz à Syhus exatamente o que lançar; a Syhus só escritura.

## Entradas (todo mês)
1. `Razão01..NN.xlsx` da Syhus (um por mês, aba "Razão").
2. P&L por fornecedor (base gerencial) — hoje `gerencial_fornecedor.json`; conferir que soma o P&L oficial por sublinha (diferença tem que ser zero).
3. Realizado ERP por pessoa (`real_erp.json`), Cadastro People (`real_cadastro.json`), base de distratos (`base_mari_distratos.json`).

## Como rodar (Node, pasta `work/`)
```
npm install xlsx exceljs
node parse_razao.js     # lê os razões; confere cada conta contra o "Total do mês" (ver nota de zeramento abaixo)
node normalizar.js      # fornecedor, tipo (provisão/NF/cartão/banco/reversão/estorno) e NF de cada linha
node casar.js           # casa fornecedor do P&L com fornecedor do razão
node folha.js           # folha PJ por pessoa (razão × ERP + distratos), conta certa pela área
node analisar.js        # aplica as regras de achado -> achados.json
node gerar_v4.js         # gera o Excel para a Syhus (chama aba_prioridade.js/prioridade.js e abas_v4.js)
node quadro_dados.js    # (opcional) só pra ver no terminal o quadro mensal e a composição da diferença, sem gerar Excel
```
Para um mês novo: acrescentar o arquivo em `FILES` no `parse_razao.js` e o mês em `MESES` em todos os scripts (`casar.js`, `folha.js`, `analisar.js`, `gerar_v4.js`, `quadro_dados.js`, `prioridade.js`).

**Checagem de integridade do parse (rodar sempre, é a última coisa que `parse_razao.js` imprime):**
"contas OK: N | contas com diferença: 0" — se aparecer qualquer diferença > 0, **não seguir em frente sem investigar**. No fechamento de trimestre/semestre (ex.: junho fechando Q1-Q2) a Syhus lança um "zeramento/Encerramento do Exercício" que zera o saldo da conta — isso já está tratado (soma-se de volta só pra validar, mas nunca entra nos lançamentos reais). Se a diferença for outra coisa, é sinal de mudança de layout do arquivo da Syhus: conferir manualmente as colunas de Débito/Crédito (índices 8/9) antes de confiar no resto do pipeline.

**Antes de confiar no mês mais recente:** conferir se o razão está completo — abrir o xlsx bruto, olhar a linha "Período:" no topo (tem que cobrir o mês inteiro) e os dias com lançamento (tem que ir até o último dia do mês). Não assumir — checar.

## Regras (arquivo `regras.js` — é o que se "guarda" de um mês para o outro)
- **Leitura do razão**: Débito coluna I, Crédito coluna J; excluir "Encerramento do exercício/zeramento". Se a soma não bater com o "Total do mês", parar.
- **Fornecedor da linha**: "nota fiscal nº X do fornecedor NOME" → senão contrapartida "NNN - NOME" (se não for banco/cartão/provisão) → senão formatos de cartão/boleto. Cuidado: "Banco de Dados" (Digesto) não é banco.
- **Casamento com o P&L**: por nome (≥ metade das palavras significativas). Plataformas de mídia por conta. Linhas agregadas do P&L (Hotels, Taxi, Supplies…) pela conta. De-paras confirmados em `ALIAS` (Treble = Messaging & Live Chat; Candia; Timework = Timework+WeWork; Microsoft do Brasil = Microsoft Ads; GCP = Google Cloud; CDL = Sede Nova…).
- **PJ com nome de empresa diferente** (`VINCULO_PJ`): só com prova de valor mensal idêntico ao ERP (ex.: DKSWEB = Deyvid Kenid, 6 meses iguais).
- **Conta certa**: árvore oficial do DRE (sublinha → conta). Folha: Engenharia/Produto = 6.2.1.01.001; demais = 4.1.6.01.007.
- **Competência da NF** (atribuição ótima NF × mês): cada NF vai para o mês do gerencial (folha: do ERP, incluindo dez/2025 e jul/2026) de valor idêntico (até R$ 2 de arredondamento), com até 4 meses de atraso ou 1 de adiantamento; valor só aproximado (±0,5%) vale apenas no próprio mês. Sem valor idêntico: a reversão que cita a NF. Senão o mês do lançamento.
- **Data de 2025 no histórico** (baixa de adiantamento, estorno de NF de 2025, "exercício anterior"): sai de 2026 quando o gerencial do mês não tem esse valor; fornecedor sem par no P&L sai sempre.
- **NF repetida**: duas NFs do mesmo valor no mesmo mês com o gerencial/ERP tendo uma só → excluir a de número maior; em jan (ou fornecedor que fatura com atraso) a de número menor é de 2025. Pagamento (cartão/banco) que cita o número de uma NF já lançada = despesa em dobro. Parcelas diferentes (PARC 1/2 × 2/2) não são duplicidade.
- **Distrato**: usar o mês do P&L (painel People, Contract Termination) quando a soma do mês só fecha com a troca.
- **Achados** (nesta ordem): trocar de conta → excluir duplicado (mesma NF 2x; NF + cartão do mesmo valor; NF formal = soma de 1–3 cobranças já lançadas; adiantamento lançado como despesa) → estornar provisão sem baixa → competência 2025 → provisionar/baixar por fornecedor → falta lançar.
- **Não se ajusta sem prova**: o que sobra vira "Pedir NF"; fornecedor do razão sem par vira "Sem par no gerencial"; diferença estrutural conhecida (Pagar.me) vira nota.
- **Nunca confiar no "Ok, ajustado" da Syhus**: todo mês conferir os ajustes pedidos no mês anterior contra o razão novo (rodar `v2_nao_aplicado.json` / script equivalente — não é mais aba do Excel da Syhus, é conferência interna da Jusfy).
- Tolerância: R$ 50 por fornecedor/mês.

## Achados desta rodada (jan–jun/2026) que viram regra
- Digesto, VIR, Nova DD, Judit, Carbigdata continuam em 6.2.1.03.002 (licença) e são APIs (6.2.1.03.003), apesar de marcados "Ok" na v2.
- Treble: NFs 291 e 293 de mai repetem faturas de jan/mar/abr já pagas no cartão (soma bate no centavo).
- Amazon AWS: fatura sempre 1 mês depois → provisão todo mês.
- Digesto: provisão estimada ≠ NF real todo mês → complementar; mai ficou sem provisão.
- Bônus/NFs de dez/2025 lançados em jan/2026 (competência 2025).
- HAGROEX = Hugo Bretz Cabral Hennies (Engenharia): resolvida a ressalva "pedir NF 155/159".
- Microsoft do Brasil em licença de software é Microsoft Ads.
- "Other Marketing Expenses" no P&L extraído repetia as filhas de BAR Associations — excluir da régua.


## Rodada de set/2026 (v4) — o que mudou
- Aba **Razão linha a linha**: todas as 13.509 linhas das contas 4.1/6.2 com status (✅ certo, ❌ conta errada / em dobro / de 2025 / provisão sem baixa / CAPEX, 🕒 mês errado, ⚠ sem prova / sem par, ℹ fora do DRE operacional) e o que fazer.
- **Resumo** com a régua completa (P&L por fornecedor + painel People) e a composição da diferença que sobra (Pagar.me, distratos de jun fora do P&L, sem prova, sem par, arredondamento).
- Aba **Notas explicativas**: Pagar.me, distratos de jun, Google Ads NF × gerencial, LinkedIn, Selki/JOINVIX, Syhus jan, treinamentos, bolsa-estágio, fornecedor trocado (ROLE/ZEE, Junqueira/Capi Candia), vínculos PJ.
- Descoberto nesta rodada: 156 baixas de adiantamento de 2025 lançadas em fev/2026 (R$ 126,6 mil); estornos de NFs de 2025 lançados em mai/2026; PJs que faturam 1 mês depois (NF de dez/2025 em jan); NFs de salário em dobro (Douglas, Rodrigo Trindade, Katsurayama); NF de jul lançada em jun (Larissa, Adriel); pagamento que cita NF já lançada (Cloud Humans, Guia da Alma).


## Regra fixa: nunca por linha do P&L, nunca genérico — sempre por fornecedor (`explode_fornecedor.js`)
A Nathália foi taxativa: nenhum lançamento pode ser "a diferença da linha X do P&L" sem um fornecedor real do razão por trás. Isso vale pra TODO o arquivo, não só pra prioridade.
- `RUBRICA_GENERICA` = blocos `'Linhas agregadas do P&L'` (Hotels, Airline and Bus Tickets, Eventos+Brindes, Taxi, Supplies, Telephony, Electrical Energy, Maintenance, Tax suppliers, Perdas, Processos Judiciais, Various Equipment, Other Executive Leadership) e `'CAPEX (sai da despesa)'` — nessas duas, o P&L não abre por fornecedor.
- `explodir(bloco, acoes)` em `explode_fornecedor.js`: pra ações dessas duas categorias, olha o `lanc` (as linhas reais do razão por trás da ação). Um fornecedor só → relabela a entidade pra esse fornecedor. Vários fornecedores juntos → separa uma linha por fornecedor, valor real de cada um. Nenhum fornecedor (lanc vazio, tipo "provisionar a diferença" sem prova) → **não vira lançamento**: cai em `semFornecedor`, que o `gerar_v4.js` manda pra aba "6. Pedir NF" marcado como "sem prova de fornecedor" (nunca é descartado silenciosamente).
- Usado tanto em `prioridade.js` (pro cálculo dos lançamentos mínimos) quanto em `gerar_v4.js` (pras abas 1-5 completas) — os dois têm que usar o MESMO módulo, senão dá lançamento duplicado (aconteceu uma vez: o mesmo Vila Ventura aparecia relabelado na aba 0 e ainda genérico como "Eventos + Brindes" na aba 2).
- Checagem de sanidade depois de gerar o Excel: somar as linhas de dado de cada aba (0 a 6) e comparar com a soma por tipo em `achados.json` já explodida — tem que bater exato, sem sobra nem falta (ver exemplo de script de conferência no fim deste arquivo, ou reaproveitar o do histórico da sessão).

## Aba "0. FAZER PRIMEIRO" — o mínimo de lançamentos que fecha a meta (`prioridade.js` + `aba_prioridade.js`)
Quando o prazo é curto (a Syhus não consegue fazer os 1.300+ lançamentos completos a tempo), gera-se uma lista enxuta que sozinha já fecha 0,5% em todo mês:
- `prioridade.js` exporta `calcular()`. Monta "movimentos": cada ação isolada (COMPETÊNCIA 2025, EXCLUIR, ESTORNAR, FALTA LANÇAR, RECLASSIFICAR pra CAPEX) é 1 movimento; cada par PROVISIONAR+BAIXAR PROVISÃO (ou REVERTER+PROVISIONAR) do mesmo fornecedor/NF em meses diferentes é tratado como **1 movimento só, nunca separado** — do contrário fica lançamento órfão (baixa sem provisão em outro mês, ou vice-versa), o que é errado mesmo que o número feche.
- RECLASSIFICAR entre duas contas do razão de resultado (4.1/6.2, nenhuma delas CAPEX) **não muda o total do mês** contra o gerencial — só troca de conta pra conta. Por isso 377 dos 392 reclassificar não entram na lista prioritária; só os que vão pra CAPEX (mudam o total) entram.
- Greedy iterativo: a cada passo, escolhe o movimento que mais reduz a soma dos desvios (|razão − gerencial|) dos meses ainda fora da meta, **descartando qualquer movimento que tiraria da meta um mês que já estava dentro**. Repete até todo mês ficar dentro de ±0,5% (ou não sobrar movimento que ajude).
- `gerar_v4.js` usa esse resultado pra: (a) montar a aba "0. FAZER PRIMEIRO" com a tabela de %/mês e a lista de lançamentos; (b) excluir da aba 1-5 qualquer item que já esteja na aba 0 (via assinatura mês+tipo+fornecedor+valor arredondado, `jaNaPrioridade`), pra ninguém fazer o mesmo lançamento duas vezes.
- Reclassificações que sobraram (não mudam o total, não são urgentes) viram a aba "1. Trocar de conta (outubro)" — trabalho de fundo, sem prazo apertado.
- Antes de mandar pra Syhus: sempre rodar `node prioridade.js` sozinho e conferir a tabela de %/mês no terminal bate com o que sai na aba 0 do Excel.

## Rodada de correção (mesma sessão) — cruzamento real contra a base financeira (ERP)
- Criado `cruza_sempar_erp.js`: cruza cada linha do razão sem par no P&L contra `base_mari_rows.json` (a base financeira que alimenta o P&L) por fornecedor + valor (até 1%) + competência/vencimento. Reduziu o sem-par de R$ 138 mil para R$ 80,9 mil, todos com evidência linha a linha na aba "Sem par × ERP".
- De-paras provados: Pagar.me (chave "PAGARME PAGAMENTOS", tarifa de maquininha); Números telefone Salvy; Anthropic Claude Team/Claude AI Subscription; GoDaddy Brasil; Mobbin.com; RR Cursos Jurídicos.
- Rubricas agregadas por fornecedor provadas pelo ERP: Processos Judiciais (Poder Judiciário, Rodrigues Lemes), Hotels (Serra Canela, Hotelaria POA), Taxi (Juliano Oliveira Costa), Telephony (Avato, RVT), Supplies (Hipersul, JRP), Eventos (Olada), Perdas agora inclui 4.1.8.10.002 (estornos a clientes, classe 2.2 do ERP).
- Distrato: o painel People lança pelo mês do VENCIMENTO na base financeira (coluna 8), não pela competência (coluna 14) — corrigido em `folha.js`. Prova: Arthur Moreira (jan→fev) e Vitor Bitencourt (mai→jun) batem exatos com o painel dessa forma.
- Achados de gerencial (P&L) incompleto, provados pelo ERP, não são erro do razão: falta a linha "Auxílio Educacional/Cursos e Treinamentos" inteira (R$ 30,9 mil no ERP), falta Bolsa Estágio + Provisão de Férias (R$ 9,85 mil), e o painel People de junho não tem 6 dos 7 distratos do mês (R$ 47,6 mil) que já estão certos no ERP e no razão.
- Restam R$ ~30 mil genuinamente sem par em nenhuma base (nem ERP nem P&L): listados na aba "Sem par × ERP" como "Não está no ERP" — pedir à Jusfy o que são.

## Rodada de 24/09/2026 — o que mudou (vale daqui pra frente)

Ordem de execução agora:
```
node parse_razao.js && node normalizar.js && node casar.js && node folha.js && node analisar.js
node ajusta_distratos.js      # distrato é sempre despesa (RH/Contract Termination, 4.1.6.02.007); MDR Pagar.me vira lançamento
node sempar_classif.js        # classifica o "sem par" contra a base do ERP (a maior parte estava no P&L por outra linha)
node gerar_v6.js              # escreve todas.json e gera o Excel (usa o resultado do otimizador)
```
Antes do gerar_v6.js: `node exporta_milp.js 0.005 0.005 0.005 && python3 otimo.py` (precisa de `pip install scipy numpy`).
Depois: `node validar.js "<arquivo>.xlsx"` — tem que dar 0 falhas antes de mandar.

Regras novas:
- **Custo × despesa separados, cada um em até 0,5% do P&L oficial.** Folha: só Engenharia é custo ("Engineering & Technology Payroll"); Produto e as demais áreas são despesa. Distrato é sempre despesa (Contract Termination), qualquer área.
- **Gerencial = P&L oficial**: P&L por fornecedor (fora do escopo: CAPEX, recompra de ações, Fintech) + painel de pessoas + a parte da linha "HR Expenses & Payroll" que não é folha (auxílio educacional, integrações).
- **Nota explicativa é SÓ a competência 2025** (exercício encerrado: fica em 2026). Pagar.me e folha não são nota.
- **Pendências da Jusfy** (não são nota, não são lançamento da Syhus): razão maior que o P&L sem prova, fornecedor fora do P&L, linha agregada sem fornecedor no razão, painel de pessoas × cadastro/ERP. O Resumo mostra a diferença antes e depois delas.
- **Mínimo de lançamentos = exato** (otimizador HiGHS), com: todo erro claro que aproxima o fornecedor do P&L (lançamento em dobro, provisão sem baixa, MDR Pagar.me) obrigatório; e nenhum lançamento pode deixar um fornecedor×mês mais longe do P&L do que estava ("nunca piorar"). Se um "erro claro" afasta do P&L, não entra: vai pra seção C de Notas pra Jusfy confirmar.
- Fornecedor sempre com o nome como está no razão (grafias diferentes do mesmo fornecedor viram uma linha só).
