// Passo 4: folha PJ por PESSOA — razão × Realizado ERP, conta certa pela área do Cadastro.
const fs = require('fs');
const path = require('path');
const RG = require('./regras.js');
const L = require('./lancamentos.json');
const { grupos, rubricas } = require('./grupos.json');
const CAD = require('../extracted/dados/real_cadastro.json');
const ERP = require('../extracted/dados/real_erp.json');

const MESES = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'];
const norm = s => String(s || '').toUpperCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/^\d{1,3}(\.\d{3}){2}\s+/, '')
  .replace(/\s\d{11}\b/g, '').replace(/[^A-Z0-9 ]/g, ' ')
  .replace(/\b(LTDA|ME|EIRELI|S A|SA|EPP|DE|DA|DO|DOS|DAS|E|SERVICOS|SERVICO|CONSULTORIA|TECNOLOGIA|INFORMACAO|DESENVOLVIMENTO|SOFTWARE|SOLUCOES|APOIO|ADMINISTRATIVO|ADMINISTRATIVOS|EM|PF)\b/g, ' ')
  .replace(/\s+/g, ' ').trim();

// índice de pessoas: tokens de nome e de razão social
const pessoas = CAD.map((p, i) => ({ id: i, nome: p.nome, razaoSocial: p.razaoSocial, area: p.area, status: p.status, dataSaida: p.dataSaida,
  tn: norm(p.nome).split(' ').filter(Boolean), tr: norm(p.razaoSocial).split(' ').filter(Boolean) }));
const contaCerta = area => (/^(Engenharia|Produto)$/.test(area) ? '6.2.1.01.001' : '4.1.6.01.007');

const PRIMEIROS = new Set(['GUILHERME','PEDRO','LUCAS','MATHEUS','JOAO','JOSE','MARIA','ANA','BRUNO','GABRIEL','GABRIELA','RAFAEL','RODRIGO','FELIPE','THIAGO','DOUGLAS','MARINA','MARIANA','JULIA','JULIANO','CARLOS','LUIZ','LUIS','DIEGO','DANIEL','VITOR','VICTOR','ALEXANDRE','MICHEL','JESSICA','LEONARDO','EDUARDO','FERNANDO','RENATO','IVAN','KAIO','KAUAN','JUAN','LUAN','DENER','SOFIA','KARINE','BIANCA','ROBERTA']);
const limparRS = s => String(s || '').replace(/CNPJ.*$/i, '').replace(/IE:.*$/i, '').replace(/[0-9][0-9.,E+\/-]{6,}/gi, ' ').replace(/\s-\s.*$/, '');
pessoas.forEach(p => { p.tr = norm(limparRS(p.razaoSocial)).split(' ').filter(Boolean); });
function acharPessoa(texto) {
  const up = String(texto || '').toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  for (const [k, v] of Object.entries(RG.VINCULO_PJ)) if (up.includes(k)) { const p = pessoas.find(x => x.nome === v.pessoa); if (p) { p.vinculo = v.evidencia; return p; } }
  const t = norm(texto).split(' ').filter(Boolean);
  if (!t.length) return null;
  // A: todas as palavras da razão social (limpa) estão no nome do razão
  let hits = pessoas.filter(p => p.tr.length && p.tr[0].length >= 4 && p.tr.every(x => t.includes(x)));
  if (hits.length === 1) return hits[0];
  // B: primeiro e último nome da pessoa
  hits = pessoas.filter(p => p.tn.length >= 2 && t.includes(p.tn[0]) && t.includes(p.tn[p.tn.length - 1]));
  if (hits.length === 1) return hits[0];
  if (hits.length > 1) { const h2 = hits.filter(p => p.tn.filter(x => t.includes(x)).length >= 3); if (h2.length === 1) return h2[0]; }
  // C: PJ com o sobrenome da pessoa (ESPEJOLAB -> Espejo, BRAYAN SOLUTIONS -> Michel Brayan)
  const COMUNS = new Set(['SILVA', 'SANTOS', 'OLIVEIRA', 'SOUZA', 'SOUSA', 'MARTINS', 'PEREIRA', 'COSTA', 'RODRIGUES', 'ALMEIDA', 'FERREIRA', 'GOMES', 'RIBEIRO', 'CARVALHO', 'ARAUJO', 'FERNANDES', 'BARBOSA', 'ROCHA', 'DIAS', 'MOREIRA', 'CARDOSO', 'MACHADO', 'MENDES', 'NASCIMENTO', 'BORGES', 'FREITAS', 'TEIXEIRA', 'MORAES', 'MORAIS']);
  hits = pessoas.filter(p => !(PRIMEIROS.has(t[0]) && t[0] !== p.tn[0]) && p.tn.some(x => x.length >= 5 && !PRIMEIROS.has(x) && !COMUNS.has(x) && t.some(y => y === x || (y.startsWith(x) && y.length <= x.length + 4))));
  if (hits.length === 1 && t.length <= 3) return hits[0];
  // D: regra por proporção (primeiro+último da razão social ou nome, >=60% das palavras)
  let melhor = null, score = 0;
  for (const p of pessoas) for (const ref of [p.tr, p.tn]) {
    if (ref.length < 2) continue;
    const iguais = ref.filter(x => t.includes(x)).length, sc = iguais / ref.length;
    if (t.includes(ref[0]) && t.includes(ref[ref.length - 1]) && sc > score && (sc >= 0.6 || iguais >= 3)) { melhor = p; score = sc; }
  }
  return melhor;
}

// lançamentos já atribuídos a fornecedores do P&L ou rubricas não entram na folha
const jaUsado = new Set();
[...grupos, ...rubricas].forEach(g => g.lancamentos.forEach(l => jaUsado.add(l.mes + '|' + l.conta + '|' + l.valor + '|' + l.historico)));
const idL = l => l.mes + '|' + l.conta + '|' + l.valor + '|' + l.historico;

const candidatos = L.filter(l => /^(4\.1|6\.2)/.test(l.conta) && !RG.naoOperacional(l) && !jaUsado.has(idL(l)));
const cachePessoa = {};
const porPessoa = {}; // id -> {razao:[lanc], erp:{mes:valor}}
const naoPessoaFolha = []; // lançamentos em conta de folha que não são pessoa do Cadastro
for (const l of candidatos) {
  if (!(l.chave in cachePessoa)) cachePessoa[l.chave] = acharPessoa(l.fornecedor) || acharPessoa(l.chave);
  const p = cachePessoa[l.chave];
  if (p) { (porPessoa[p.id] = porPessoa[p.id] || { razao: [], erp: {} }).razao.push(l); }
  else if (RG.CONTAS_FOLHA.has(l.conta) || RG.CONTAS_PASSAGEM[l.conta]) naoPessoaFolha.push(l);
}

// ERP (gerencial da folha): Salário + Bônus + Comissão por pessoa/mês (Benefício é conciliado por fornecedor: iFood, Swile...)
const erpSemPessoa = [];
ERP.filter(r => r.ano === 2026 && r.mes >= 1 && r.mes <= 6 && r.categoria !== 'Benefício').forEach(r => {
  const p = acharPessoa(r.fornecedor);
  const mes = MESES[r.mes - 1];
  if (!p) { erpSemPessoa.push(r); return; }
  const o = (porPessoa[p.id] = porPessoa[p.id] || { razao: [], erp: {} });
  o.erp[mes] = (o.erp[mes] || 0) + r.valor;
  (o.erpCat = o.erpCat || {})[r.categoria] = ((o.erpCat || {})[r.categoria] || 0) + r.valor;
});

// distratos (Contract Termination no gerencial) entram na régua da pessoa
const DIST = require('../extracted/dados/base_mari_distratos.json');
const mm = { jan: 'Jan', fev: 'Fev', mar: 'Mar', abr: 'Abr', mai: 'Mai', jun: 'Jun' };
const distratosAplicados = [];
// o painel People lança o distrato no mês do VENCIMENTO (base financeira, coluna vencimento): refaz o mês de cada distrato por ela
{
  const BR = require('../extracted/dados/base_mari_rows.json');
  const ym = s => { const n = parseFloat(s); return n ? new Date(Date.UTC(1899, 11, 30) + n * 864e5).toISOString().slice(0, 7) : ''; };
  const KS = { '2026-01': 'jan', '2026-02': 'fev', '2026-03': 'mar', '2026-04': 'abr', '2026-05': 'mai', '2026-06': 'jun', '2026-07': 'jul', '2026-08': 'ago' };
  const nn = s => String(s || '').toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Z ]/g, ' ').replace(/\s+/g, ' ').trim();
  BR.filter(r => /Distrato/i.test(r['10'] || '') && r['1'] === 'OK').forEach(r => {
    const v = Math.abs(parseFloat(String(r['11']).replace(/[^\d,]/g, '').replace(',', '.')));
    const kv = KS[ym(r['8'])], kc = KS[ym(r['14'])]; if (!kv || !kc || kv === kc) return;
    const nome = Object.keys(DIST).find(n => nn(n) === nn(r['9'])); if (!nome || Math.abs((DIST[nome][kc] || 0) - v) > 1) return;
    delete DIST[nome][kc]; DIST[nome][kv] = (DIST[nome][kv] || 0) + v;
    distratosAplicados.push({ pessoa: nome, mes: kv, valor: v, obs: 'mês do vencimento (' + kv + '), não da competência (' + kc + '): é o mês em que o P&L lança o distrato' });
  });
}
Object.entries(DIST).forEach(([nome, o]) => {
  const p = acharPessoa(nome);
  if (!p) return;
  Object.entries(o).forEach(([k, v]) => {
    const mes = mm[k]; if (!mes || !v) return;
    const reg = (porPessoa[p.id] = porPessoa[p.id] || { razao: [], erp: {} });
    const jaNoErp = ERP.some(r => r.ano === 2026 && MESES[r.mes - 1] === mes && acharPessoa(r.fornecedor) === p && Math.abs(r.valor - v) <= 1);
    if (jaNoErp) { distratosAplicados.push({ pessoa: p.nome, mes, valor: v, obs: 'já está no ERP como salário — não somar de novo' }); return; }
    reg.erp[mes] = (reg.erp[mes] || 0) + v;
    (reg.erpCat = reg.erpCat || {}).Distrato = ((reg.erpCat || {}).Distrato || 0) + v;
    distratosAplicados.push({ pessoa: p.nome, mes, valor: v, obs: 'somado à régua' });
  });
});

const resultado = Object.entries(porPessoa).map(([id, o]) => {
  const p = pessoas[id];
  const razMes = {}, erpMes = {};
  MESES.forEach(m => { razMes[m] = 0; erpMes[m] = o.erp[m] || 0; });
  o.razao.forEach(l => { razMes[l.mes] += l.valor; });
  return { pessoa: p.nome, razaoSocial: p.razaoSocial, area: p.area, status: p.status, dataSaida: p.dataSaida,
    vinculo: p.vinculo || '', contaCerta: contaCerta(p.area), razMes, erpMes, erpCat: o.erpCat || {}, lancamentos: o.razao };
});

fs.writeFileSync(path.join(__dirname, 'folha.json'), JSON.stringify({ pessoas: resultado, naoPessoaFolha, erpSemPessoa, distratosAplicados }));

const tot = o => MESES.reduce((s, m) => s + o[m], 0);
const R = resultado.reduce((s, x) => s + tot(x.razMes), 0), E = resultado.reduce((s, x) => s + tot(x.erpMes), 0);
console.log('pessoas cruzadas:', resultado.length, '| razão:', Math.round(R), '| ERP:', Math.round(E), '| dif:', Math.round(R - E));
console.log('ERP sem pessoa no Cadastro:', erpSemPessoa.length, 'R$', Math.round(erpSemPessoa.reduce((a, r) => a + r.valor, 0)), [...new Set(erpSemPessoa.map(r => r.fornecedor))].slice(0, 12).join('; '));
const np = {}; naoPessoaFolha.forEach(l => { np[l.chave] = (np[l.chave] || 0) + l.valor; });
console.log('conta de folha/passagem, não é pessoa:', naoPessoaFolha.length, 'R$', Math.round(naoPessoaFolha.reduce((a, l) => a + l.valor, 0)));
Object.entries(np).sort((a, b) => Math.abs(b[1]) - Math.abs(a[1])).slice(0, 20).forEach(([k, v]) => console.log('   ', Math.round(v), k.slice(0, 70)));
