// Passo depois do analisar.js (roda uma vez por achados.json novo):
// 1) Distrato fica em RH — Contract Termination (despesa, 4.1.6.02.007) no P&L, qualquer que seja a área da pessoa.
//    Pra quem é de Engenharia (custo), a parte do distrato sai do alvo de custo e vai pro de despesa, e a NF do distrato
//    não pode ser levada pro custo (nem ficar lá).
// 2) Pagar.me: o MDR retido na liquidação vira lançamento (não é nota explicativa) — valor do P&L menos o que já está no razão.
const fs = require('fs');
const path = require('path');
const arq = path.join(__dirname, 'achados.json');
const A = require(arq);
if ((A.ajustes || []).includes('distratos')) { console.log('achados.json já ajustado'); process.exit(0); }
const F = require('./folha.json');
const r2 = x => Math.round(x * 100) / 100;
const CONTA_DISTRATO = '4.1.6.02.007';
const custo = c => /^6\.2\./.test(c);
const norm = s => String(s || '').toUpperCase().normalize('NFD').replace(/[̀-ͯ]/g, '').split(/\s+/).slice(0, 2).join(' ');
const log = [];
const mesma = (x, y) => x.mes === y.mes && x.conta === y.conta && Math.abs(x.valor - y.valor) < 0.01 && (x.nf || '') === (y.nf || '') && x.historico === y.historico;

(F.distratosAplicados || []).filter(d => /somado/.test(d.obs)).forEach(d => {
  const m = d.mes.charAt(0).toUpperCase() + d.mes.slice(1, 3).toLowerCase();
  const c = A.casos.find(c => /^Folha/.test(c.bloco) && norm(c.nome) === norm(d.pessoa));
  if (!c || !custo(c.contaPadrao)) return; // quem já é despesa: distrato já está no grupo certo
  c.alvoDistrato = c.alvoDistrato || {};
  c.alvoDistrato[m] = r2((c.alvoDistrato[m] || 0) + d.valor);
  // a NF do distrato no razão (mesmo mês, mesmo valor; ou a NF que contém o distrato)
  const linha = c.lancamentos.find(l => l.mes === m && Math.abs(l.valor - d.valor) <= 1)
    || c.lancamentos.filter(l => l.mes === m && l.tipo === 'NF' && l.valor > d.valor).sort((a, b) => b.valor - a.valor)[0];
  if (!linha) { log.push(c.nome + ' ' + m + ': distrato ' + d.valor + ' sem NF no razão'); return; }
  const nf = linha.nf ? 'NF ' + linha.nf : 'lançamento';
  if (custo(linha.conta)) {
    c.acoes.push({ tipo: 'RECLASSIFICAR', mes: m, conta: linha.conta, contaPara: CONTA_DISTRATO, valor: r2(d.valor), lanc: [linha],
      texto: 'Distrato (rescisão) de ' + d.pessoa + ': no P&L o distrato fica em RH — Contract Termination (despesa), não no custo. Mover R$ ' + r2(d.valor).toLocaleString('pt-BR') + ' da ' + nf + ' de ' + linha.conta + ' para ' + CONTA_DISTRATO + ' (Distratos).' });
    log.push(c.nome + ' ' + m + ': +reclass distrato ' + d.valor + ' ' + linha.conta + ' -> ' + CONTA_DISTRATO);
  } else {
    // a NF do distrato está em despesa (certo): tira ela de qualquer "mover pra custo" do mesmo mês
    c.acoes.filter(a => a.tipo === 'RECLASSIFICAR' && a.mes === m && custo(a.contaPara) && (a.lanc || []).some(l => mesma(l, linha))).forEach(a => {
      a.valor = r2(a.valor - linha.valor);
      a.lanc = a.lanc.filter(l => !mesma(l, linha));
      a.texto = 'Está na conta ' + a.conta + '. Mover para ' + a.contaPara + ' só a parte de serviço (R$ ' + a.valor.toLocaleString('pt-BR') + '); a ' + nf + ' (R$ ' + r2(linha.valor).toLocaleString('pt-BR') + ') é distrato e fica em despesa.';
      log.push(c.nome + ' ' + m + ': reclass pra custo reduzido para ' + a.valor + ' (distrato fica em despesa)');
    });
    c.acoes = c.acoes.filter(a => !(a.tipo === 'RECLASSIFICAR' && Math.abs(a.valor) < 0.5));
  }
});

// Pagar.me: MDR retido na liquidação vira lançamento
A.casos.filter(c => /^Pagar\.me/.test(c.nome)).forEach(c => c.acoes.filter(a => /^NOTA/.test(a.tipo)).forEach(a => {
  a.tipo = 'LANÇAR MDR PAGAR.ME';
  delete a.semLancar;
  a.texto = 'O P&L tem a taxa cheia da Pagar.me (Payment Processing Fees) e o razão só as NFs de serviço: o MDR retido no repasse (R$ ' + Math.round(a.valor).toLocaleString('pt-BR') + ' no mês) não foi lançado. Lançar pelo extrato de liquidação da Pagar.me.';
  log.push('Pagar.me ' + a.mes + ': NOTA -> lançamento ' + Math.round(a.valor));
}));

A.ajustes = (A.ajustes || []).concat(['distratos', 'pagarme']);
fs.writeFileSync(arq, JSON.stringify(A));
log.forEach(x => console.log(x));
