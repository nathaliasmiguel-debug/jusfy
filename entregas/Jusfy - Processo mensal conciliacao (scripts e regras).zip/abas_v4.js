// Abas novas da v4: "Razão linha a linha" (toda linha do razão classificada) e "Notas explicativas".
module.exports = function ({ wb, casos, semParCasos, L, RG, MESES, nomeConta, titulo, cab, lin, F, fill, r2, soma, COR, MONEY }) {
  const idL = l => l.mes + '|' + l.conta + '|' + l.valor + '|' + l.historico;
  const fmt = v => 'R$ ' + Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  // ---------- de quem é cada linha e o que cada ação diz dela ----------
  const dono = new Map();
  casos.forEach(c => c.lancamentos.forEach(l => { if (!dono.has(idL(l))) dono.set(idL(l), c); }));
  semParCasos.forEach(s => s.lancamentos.forEach(l => { if (!dono.has(idL(l))) dono.set(idL(l), { nome: s.fornecedor, bloco: 'Sem par no gerencial', sp: s }); }));
  const marcas = new Map(); // idL -> [{a, c}]
  const marca = (l, a, c) => { const k = idL(l); if (!marcas.has(k)) marcas.set(k, []); marcas.get(k).push({ a, c }); };
  casos.forEach(c => c.acoes.forEach(a => {
    const ls = a.lanc || [];
    if (!ls.length) return;
    const todas = a.tipo === 'RECLASSIFICAR' || ['PROVISIONAR', 'BAIXAR PROVISÃO', 'REVERTER (NF adiantada)', 'COMPLEMENTAR PROVISÃO', 'REDUZIR PROVISÃO'].includes(a.tipo)
      || (a.tipo === 'COMPETÊNCIA 2025' && (/^Este fornecedor fatura/.test(a.texto) || c.jan2025));
    (todas ? ls : [ls[0]]).forEach(l => marca(l, a, c));
  }));
  const verifMes = new Map(); // entidade|mes -> texto
  casos.forEach(c => c.acoes.filter(a => a.tipo === 'VERIFICAR').forEach(a => verifMes.set(c.nome + '|' + a.mes, a.texto)));
  const notaMes = new Map();
  casos.forEach(c => c.acoes.filter(a => /^NOTA/.test(a.tipo)).forEach(a => notaMes.set(c.nome + '|' + a.mes, a.texto)));

  const ROT = {
    'RECLASSIFICAR': '❌ Conta errada', 'EXCLUIR DUPLICADO': '❌ Lançado em dobro', 'ESTORNAR PROVISÃO': '❌ Provisão sem baixa',
    'COMPETÊNCIA 2025': '❌ É de 2025', 'PROVISIONAR': '🕒 Mês errado', 'BAIXAR PROVISÃO': '🕒 Mês errado', 'REVERTER (NF adiantada)': '🕒 Mês errado',
    'COMPLEMENTAR PROVISÃO': '🕒 Provisão com valor errado', 'REDUZIR PROVISÃO': '🕒 Provisão com valor errado',
  };
  const COR_ST = s => /sem prova|Sem par|Não classificada/i.test(s) ? COR.AMARELO : /dobro|Provisão sem baixa/.test(s) ? COR.VERMELHO : /2025/.test(s) ? COR.LILAS : /Conta errada|CAPEX/.test(s) ? COR.AZUL : /Mês|Provisão com/.test(s) ? COR.LARANJA
    : false ? 0 : /Certo/.test(s) ? COR.VERDE : COR.CINZA;

  const linhas = L.filter(l => /^(4\.1|6\.2)/.test(l.conta)).map(l => {
    const k = idL(l), c = dono.get(k), ms = marcas.get(k) || [];
    let status, oque = [], contaOk = l.conta;
    if (ms.length) {
      const rot = [...new Set(ms.map(({ a }) => a.tipo === 'RECLASSIFICAR' && /^1\.2\.2/.test(a.contaPara) ? '❌ É imobilizado (CAPEX)' : ROT[a.tipo] || a.tipo))];
      status = rot.join(' + ');
      ms.forEach(({ a }) => oque.push(a.tipo + ': ' + a.texto));
      const rc = ms.find(({ a }) => a.tipo === 'RECLASSIFICAR'); if (rc) contaOk = rc.a.contaPara;
      if (ms.some(({ a }) => ['EXCLUIR DUPLICADO', 'ESTORNAR PROVISÃO', 'COMPETÊNCIA 2025'].includes(a.tipo))) contaOk = '— (sai da despesa de 2026)';
    } else if (RG.naoOperacional(l)) {
      status = 'ℹ Fora do DRE operacional'; oque.push(/^4\.1\.5/.test(l.conta) ? 'Despesa financeira (IOF, juros, tarifas): fica abaixo do EBITDA, conciliada à parte. Não mexer.' : 'Depreciação: fora da comparação operacional. Não mexer.');
    } else if (!c) {
      status = '⚠ Não classificada'; oque.push('Linha sem fornecedor identificável no histórico. Controladoria classifica.');
    } else if (c.bloco === 'Sem par no gerencial') {
      status = '⚠ Sem par no gerencial';
      const sp = c.sp;
      if (RG.CONTAS_PASSAGEM[l.conta] && sp.contaSugerida) { status = '❌ Conta errada'; contaOk = sp.contaSugerida; oque.push('Está em conta de passagem (' + RG.CONTAS_PASSAGEM[l.conta] + '); nos outros meses este fornecedor está na ' + sp.contaSugerida + ': mover para lá. Fornecedor sem linha no P&L: Controladoria confirma a classificação.'); }
      else oque.push('Fornecedor do razão que não está no P&L gerencial nem no Cadastro/ERP. Controladoria diz em que linha do P&L ele fica (ou se não é despesa da Jusfy). Não ajustar antes.');
    } else if (verifMes.has(c.nome + '|' + l.mes)) {
      status = '⚠ Mês com valor a mais sem prova'; oque.push('A linha em si pode estar certa: no mês, ' + c.nome + ' tem no razão mais do que no gerencial e não se sabe qual NF sobra. ' + verifMes.get(c.nome + '|' + l.mes));
    } else if (notaMes.has(c.nome + '|' + l.mes)) {
      status = 'ℹ Certo — diferença conhecida'; oque.push(notaMes.get(c.nome + '|' + l.mes));
    } else {
      status = '✅ Certo'; oque.push(c.bloco === 'Folha PJ (por pessoa)' || /^Folha/.test(c.bloco) ? 'Bate com o ERP (folha).' : 'Bate com o gerencial.');
    }
    const casou = !c ? '' : c.bloco === 'Sem par no gerencial' ? '(sem par)' : c.nome + (c.sublinhas && c.sublinhas.length ? ' — ' + c.sublinhas.join(', ') : '');
    return { l, status, oque: [...new Set(oque)].join('\n').slice(0, 900), contaOk, casou };
  });

  const ws = wb.addWorksheet('Razão linha a linha');
  ws.columns = [{ width: 7 }, { width: 14 }, { width: 30 }, { width: 34 }, { width: 12 }, { width: 10 }, { width: 60 }, { width: 14 }, { width: 38 }, { width: 26 }, { width: 80 }, { width: 22 }];
  titulo(ws, 'Razão linha a linha — Jan a Jun/2026', 'Todas as linhas das contas de resultado (4.1 e 6.2) do razão, cada uma com o status e o que fazer. ✅ certa · ❌ precisa corrigir · 🕒 mês errado (provisão/baixa) · ⚠ precisa de informação da Jusfy antes · ℹ fora da comparação. Use o filtro da coluna Status.', 12);
  // resumo por status
  const porSt = {};
  linhas.forEach(x => { const s = x.status.split(' + ')[0]; porSt[s] = porSt[s] || { n: 0, v: 0 }; porSt[s].n++; porSt[s].v += x.l.valor; });
  let r = 4;
  cab(ws, r, ['', 'Status', '', 'Linhas', '', '', 'Valor no razão']); r++;
  Object.entries(porSt).sort((a, b) => b[1].n - a[1].n).forEach(([s, o]) => {
    lin(ws, r, ['', s, '', o.n, '', '', r2(o.v)], { money: [6], fill: { 1: COR_ST(s) } }); r++;
  });
  lin(ws, r, ['', 'TOTAL', '', linhas.length, '', '', r2(soma(linhas, x => x.l.valor))], { money: [6], bold: true, fillAll: COR.CINZA }); r += 1;
  const vq = r2(soma(casos.flatMap(c => c.acoes.filter(a => a.tipo === 'VERIFICAR')), a => -a.valor));
  ws.getCell(r, 2).value = 'Nos meses ⚠, o valor em dúvida é ' + fmt(vq) + ' (aba 6), não o total das linhas: as demais linhas desses meses estão certas.'; ws.getCell(r, 2).font = F({ italic: true, color: { argb: COR.MUTED } }); r += 2;
  const h = r;
  cab(ws, h, ['Mês', 'Conta', 'Nome da conta', 'Fornecedor (razão)', 'NF', 'Tipo', 'Histórico', 'Valor', 'Casou com (P&L / pessoa)', 'Status', 'O que fazer', 'Conta certa']);
  ws.views = [{ state: 'frozen', ySplit: h }];
  const ord = (a, b) => MESES.indexOf(a.l.mes) - MESES.indexOf(b.l.mes) || a.l.conta.localeCompare(b.l.conta) || (a.l.fornecedor || '').localeCompare(b.l.fornecedor || '');
  linhas.sort(ord).forEach((x, i) => {
    const row = ws.getRow(h + 1 + i);
    row.values = [x.l.mes, x.l.conta, nomeConta[x.l.conta] || x.l.contaNome || '', x.l.fornecedor || x.l.chave, x.l.nf || '', x.l.tipo, String(x.l.historico).replace(/\s+/g, ' ').slice(0, 200), x.l.valor, x.casou, x.status, x.oque, x.contaOk];
    row.font = F({ size: 9 });
    row.getCell(8).numFmt = MONEY;
    row.getCell(10).fill = fill(COR_ST(x.status));
  });
  ws.autoFilter = { from: { row: h, column: 1 }, to: { row: h + linhas.length, column: 12 } };

  // ---------- Notas explicativas ----------
  const nt = wb.addWorksheet('Notas explicativas');
  nt.columns = [{ width: 5 }, { width: 38 }, { width: 110 }, { width: 18 }];
  titulo(nt, 'Notas explicativas e pontos a confirmar', 'O que continua diferente entre o contábil e o P&L depois dos ajustes, e por quê. Cada nota tem os números do razão e do gerencial. "Confirmar" = a Controladoria precisa responder antes de lançar.', 4);
  const caso = re => casos.find(c => re.test(c.nome));
  const porMes = (c, campo) => c ? MESES.map(m => m + ' ' + fmt(c[campo][m] || 0)).join(' | ') : '';
  const pm = caso(/^Pagar\.me/), ga = caso(/^Google Ads/), li = caso(/^LinkedIn Ads/), se = caso(/^Selki/), jo = caso(/^JOINVIX/), sy = caso(/^Syhus/);
  const sp = re => semParCasos.filter(s => re.test(s.chave));
  const totSp = re => r2(soma(sp(re), s => s.total));
  const F2 = require('./folha.json');
  const distJun = F2.distratosAplicados.filter(d => d.mes === 'Jun' && /somado/.test(d.obs));
  const troc = F2.distratosAplicados.filter(d => /trocado/.test(d.obs));
  const notas = [
    ['Nota', 'Pagar.me — taxa de transação', 'O P&L tem a taxa total da Pagar.me (MDR). O razão de despesa só tem as NFs de serviço da Pagar.me (conta 6.2.1.01.003); o restante da taxa é descontado direto do recebimento e não passa por despesa. Gerencial: ' + porMes(pm, 'alvoMes') + '. Razão: ' + porMes(pm, 'razMes') + '. Para fechar, a Syhus precisa reconhecer a receita bruta e a taxa como despesa (extrato de taxas da Pagar.me).', 'Confirmar'],
    ['Nota', 'Distratos de junho fora do P&L', 'A base de distratos tem ' + distJun.length + ' distratos em jun (' + distJun.map(d => d.pessoa + ' ' + fmt(d.valor)).join('; ') + '). O razão tem todas essas NFs em jun (ex.: Bianca NF 8 = salário + distrato). O painel People de jun tem só R$ 3.000 de Contract Termination. A diferença é do P&L, não do contábil.', 'Ajustar o P&L'],
    ['Nota', 'Distratos com mês trocado conforme o P&L', troc.map(d => d.pessoa + ' ' + fmt(d.valor) + ': ' + d.obs).join('\n'), 'Informativo'],
    ['Confirmar', 'Google Ads — NF × gerencial', 'Nos meses com diferença, o gerencial é menor que as NFs do mês (em fev e mai o gerencial é igual à soma exata das 2 NFs). Gerencial: ' + porMes(ga, 'alvoMes') + '. Razão (NFs): ' + porMes(ga, 'razMes') + '. Confirmar se o gerencial usou o gasto da plataforma em vez da NF.', 'Confirmar'],
    ['Confirmar', 'LinkedIn — assinatura mensal sem linha no P&L', 'O razão tem cobrança mensal do LinkedIn (~R$ 5 mil, parcelas "PARC x/025") em SaaS e Ads; o P&L só tem LinkedIn Ads em jun. Razão: ' + porMes(li, 'razMes') + '. Definir em que linha do P&L entra a assinatura.', 'Confirmar'],
    ['Confirmar', 'Selki e JOINVIX — NF todo mês, gerencial agrupado', 'Selki emite NF mensal (19, 23, 27, 31, 35); o P&L não tem fev e mar. Selki razão: ' + porMes(se, 'razMes') + ' | P&L: ' + porMes(se, 'alvoMes') + '. JOINVIX: NF de R$ 5.000 todo mês; o P&L soma R$ 50.000 em meses alternados (' + porMes(jo, 'alvoMes') + ').', 'Confirmar'],
    ['Confirmar', 'Syhus — NF de janeiro em dobro de valor', 'NF 31339 (jan) ' + fmt(sy ? sy.razMes.Jan : 0) + ' contra ~R$ 10.309 nos outros meses; P&L jan ' + fmt(sy ? sy.alvoMes.Jan : 0) + '. Pedir à Syhus a composição da NF (13º honorário de 2025?).', 'Pedir à Syhus'],
    ['Confirmar', 'Treinamentos e cursos (4.1.6.02.001) sem linha no P&L', 'Lucas Marchese Winfield ' + fmt(totSp(/LUCAS MARCHESE/)) + ', CSP Treinamento ' + fmt(totSp(/CSP TREINAMENTO/)) + ', provisão "Cursos e Treinamentos" ' + fmt(totSp(/CURSOS TREINAMENTOS/)) + '. Definir a linha do P&L.', 'Confirmar'],
    ['Confirmar', 'Bolsa-auxílio de estágio (4.1.1.01.003) sem pessoa no painel', 'FOPAG "DIAS BOLSA AUXILIO" R$ 1.300–1.500/mês (' + fmt(totSp(/FOPAG DIAS BOLSA/)) + ' no semestre). Não está no Cadastro/ERP nem no painel People.', 'Confirmar'],
    ['Confirmar', 'Fornecedor trocado (de-para por valor)', 'ROLE FILMES (P&L mai R$ 34.850) não tem lançamento no razão; a NF 10 da ZEE Films (mai) de R$ 74.800 = ZEE jun R$ 39.780 + ROLE R$ 34.850 (dif. R$ 170). Junqueira e Candia Advocacia (P&L R$ 2.500–5.000/mês) não tem NF no razão; a Capi Candia emite NFs de R$ 2.500 fora da série de R$ 25.000. Tratados como o mesmo fornecedor.', 'Confirmar'],
    ['Confirmar', 'Vínculos PJ (empresa ≠ nome da pessoa)', Object.entries(RG.VINCULO_PJ).map(([k, v]) => k + ' = ' + v.pessoa).join('; ') + '. Provados por valor idêntico ao ERP.', 'Confirmar'],
    ['Nota', 'Equipamentos (CAPEX)', 'Compras de equipamento/mobiliário (Dell, LG, Kabum, Chypps, Stark, AliExpress, Comfy, Emesul, Braulio Kisner…) lançadas como despesa. No P&L são CAPEX: reclassificar para o imobilizado (1.2.2.01.x). Estão na aba 1.', 'Aba 1'],
  ];
  let q = 4;
  cab(nt, q, ['', 'Assunto', 'Explicação (com os números)', 'Ação']); q++;
  notas.forEach(n => { lin(nt, q, ['', n[1], n[2], n[3]], { fill: { 0: n[0] === 'Nota' ? COR.CINZA : COR.AMARELO } }); nt.getCell(q, 2).font = F({ bold: true }); nt.getRow(q).height = Math.min(160, 16 * Math.ceil(n[2].length / 105) + 6); q++; });
  return { linhas };
};
