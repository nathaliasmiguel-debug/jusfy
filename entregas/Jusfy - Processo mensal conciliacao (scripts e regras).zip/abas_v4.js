// Abas novas da v4: "Razão linha a linha" (toda linha do razão classificada) e "Notas explicativas".
module.exports = function ({ wb, casos, semParCasos, L, RG, MESES, nomeConta, titulo, cab, lin, F, fill, r2, soma, COR, MONEY }) {
  const idL = l => l.mes + '|' + l.conta + '|' + l.valor + '|' + l.historico;
  const fmt = v => 'R$ ' + Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  // ---------- de quem é cada linha e o que cada ação diz dela ----------
  const dono = new Map();
  casos.forEach(c => c.lancamentos.forEach(l => { if (!dono.has(idL(l))) dono.set(idL(l), c); }));
  semParCasos.forEach(s => s.lancamentos.forEach(l => { if (!dono.has(idL(l))) dono.set(idL(l), { nome: s.fornecedor, bloco: 'Sem par no gerencial', sp: s }); }));
  const marcas = new Map(); // idL -> [{a, c}]
  const marca = (l, a, c) => { const k = idL(l); if (!marcas.has(k)) marcas.set(k, []); marcas.get(k).push({ a, c }); };
  casos.forEach(c => c.acoes.forEach(a => {
    const ls = a.lanc || [];
    if (!ls.length) return;
    const todas = a.tipo === 'RECLASSIFICAR' || ['PROVISIONAR', 'BAIXAR PROVISÃO', 'REVERTER (NF adiantada)', 'COMPLEMENTAR PROVISÃO', 'REDUZIR PROVISÃO'].includes(a.tipo)
      || (a.tipo === 'COMPETÊNCIA 2025' && (/^Este fornecedor fatura/.test(a.texto) || c.jan2025));
    (todas ? ls : [ls[0]]).forEach(l => marca(l, a, c));
  }));
  const verifMes = new Map(); // entidade|mes -> texto
  casos.forEach(c => c.acoes.filter(a => a.tipo === 'VERIFICAR').forEach(a => verifMes.set(c.nome + '|' + a.mes, a.texto)));
  const notaMes = new Map();
  casos.forEach(c => c.acoes.filter(a => /^NOTA/.test(a.tipo)).forEach(a => notaMes.set(c.nome + '|' + a.mes, a.texto)));

  const ROT = {
    'RECLASSIFICAR': '❌ Conta errada', 'EXCLUIR DUPLICADO': '❌ Lançado em dobro', 'ESTORNAR PROVISÃO': '❌ Provisão sem baixa',
    'COMPETÊNCIA 2025': '❌ É de 2025', 'PROVISIONAR': '🕒 Mês errado', 'BAIXAR PROVISÃO': '🕒 Mês errado', 'REVERTER (NF adiantada)': '🕒 Mês errado',
    'COMPLEMENTAR PROVISÃO': '🕒 Provisão com valor errado', 'REDUZIR PROVISÃO': '🕒 Provisão com valor errado',
  };
  const COR_ST = s => /sem prova|Sem par|Não classificada/i.test(s) ? COR.AMARELO : /dobro|Provisão sem baixa/.test(s) ? COR.VERMELHO : /2025/.test(s) ? COR.LILAS : /Conta errada|CAPEX/.test(s) ? COR.AZUL : /Mês|Provisão com/.test(s) ? COR.LARANJA
    : false ? 0 : /Certo/.test(s) ? COR.VERDE : COR.CINZA;

  const linhas = L.filter(l => /^(4\.1|6\.2)/.test(l.conta)).map(l => {
    const k = idL(l), c = dono.get(k), ms = marcas.get(k) || [];
    let status, oque = [], contaOk = l.conta;
    if (ms.length) {
      const rot = [...new Set(ms.map(({ a }) => a.tipo === 'RECLASSIFICAR' && /^1\.2\.2/.test(a.contaPara) ? '❌ É imobilizado (CAPEX)' : ROT[a.tipo] || a.tipo))];
      status = rot.join(' + ');
      ms.forEach(({ a }) => oque.push(a.tipo + ': ' + a.texto));
      const rc = ms.find(({ a }) => a.tipo === 'RECLASSIFICAR'); if (rc) contaOk = rc.a.contaPara;
      if (ms.some(({ a }) => ['EXCLUIR DUPLICADO', 'ESTORNAR PROVISÃO', 'COMPETÊNCIA 2025'].includes(a.tipo))) contaOk = '— (sai da despesa de 2026)';
    } else if (RG.naoOperacional(l)) {
      status = 'ℹ Fora do DRE operacional'; oque.push(/^4\.1\.5/.test(l.conta) ? 'Despesa financeira (IOF, juros, tarifas): fica abaixo do EBITDA, conciliada à parte. Não mexer.' : 'Depreciação: fora da comparação operacional. Não mexer.');
    } else if (!c) {
      status = '⚠ Não classificada'; oque.push('Linha sem fornecedor identificável no histórico. Controladoria classifica.');
    } else if (c.bloco === 'Sem par no gerencial') {
      status = '⚠ Sem par no gerencial';
      const sp = c.sp;
      if (RG.CONTAS_PASSAGEM[l.conta] && sp.contaSugerida) { status = '❌ Conta errada'; contaOk = sp.contaSugerida; oque.push('Está em conta de passagem (' + RG.CONTAS_PASSAGEM[l.conta] + '); nos outros meses este fornecedor está na ' + sp.contaSugerida + ': mover para lá. Fornecedor sem linha no P&L: Controladoria confirma a classificação.'); }
      else oque.push('Fornecedor do razão que não está no P&L gerencial nem no Cadastro/ERP. Controladoria diz em que linha do P&L ele fica (ou se não é despesa da Jusfy). Não ajustar antes.');
    } else if (verifMes.has(c.nome + '|' + l.mes)) {
      status = '⚠ Mês com valor a mais sem prova'; oque.push('A linha em si pode estar certa: no mês, ' + c.nome + ' tem no razão mais do que no gerencial e não se sabe qual NF sobra. ' + verifMes.get(c.nome + '|' + l.mes));
    } else if (notaMes.has(c.nome + '|' + l.mes)) {
      status = 'ℹ Certo — diferença conhecida'; oque.push(notaMes.get(c.nome + '|' + l.mes));
    } else {
      status = '✅ Certo'; oque.push(c.bloco === 'Folha PJ (por pessoa)' || /^Folha/.test(c.bloco) ? 'Bate com o ERP (folha).' : 'Bate com o gerencial.');
    }
    const casou = !c ? '' : c.bloco === 'Sem par no gerencial' ? '(sem par)' : c.nome + (c.sublinhas && c.sublinhas.length ? ' — ' + c.sublinhas.join(', ') : '');
    return { l, status, oque: [...new Set(oque)].join('\n').slice(0, 900), contaOk, casou };
  });

  const ws = wb.addWorksheet('Razão linha a linha');
  ws.columns = [{ width: 7 }, { width: 14 }, { width: 30 }, { width: 34 }, { width: 12 }, { width: 10 }, { width: 60 }, { width: 14 }, { width: 38 }, { width: 26 }, { width: 80 }, { width: 22 }];
  titulo(ws, 'Razão linha a linha — Jan a Jun/2026', 'Todas as linhas das contas de resultado (4.1 e 6.2) do razão, cada uma com o status e o que fazer. ✅ certa · ❌ precisa corrigir · 🕒 mês errado (provisão/baixa) · ⚠ precisa de informação da Jusfy antes · ℹ fora da comparação. Use o filtro da coluna Status.', 12);
  // resumo por status
  const porSt = {};
  linhas.forEach(x => { const s = x.status.split(' + ')[0]; porSt[s] = porSt[s] || { n: 0, v: 0 }; porSt[s].n++; porSt[s].v += x.l.valor; });
  let r = 4;
  cab(ws, r, ['', 'Status', '', 'Linhas', '', '', 'Valor no razão']); r++;
  Object.entries(porSt).sort((a, b) => b[1].n - a[1].n).forEach(([s, o]) => {
    lin(ws, r, ['', s, '', o.n, '', '', r2(o.v)], { money: [6], fill: { 1: COR_ST(s) } }); r++;
  });
  lin(ws, r, ['', 'TOTAL', '', linhas.length, '', '', r2(soma(linhas, x => x.l.valor))], { money: [6], bold: true, fillAll: COR.CINZA }); r += 1;
  const vq = r2(soma(casos.flatMap(c => c.acoes.filter(a => a.tipo === 'VERIFICAR')), a => -a.valor));
  ws.getCell(r, 2).value = 'Nos meses ⚠, o valor em dúvida é ' + fmt(vq) + ' (aba 6), não o total das linhas: as demais linhas desses meses estão certas.'; ws.getCell(r, 2).font = F({ italic: true, color: { argb: COR.MUTED } }); r += 2;
  const h = r;
  cab(ws, h, ['Mês', 'Conta', 'Nome da conta', 'Fornecedor (razão)', 'NF', 'Tipo', 'Histórico', 'Valor', 'Casou com (P&L / pessoa)', 'Status', 'O que fazer', 'Conta certa']);
  ws.views = [{ state: 'frozen', ySplit: h }];
  const ord = (a, b) => MESES.indexOf(a.l.mes) - MESES.indexOf(b.l.mes) || a.l.conta.localeCompare(b.l.conta) || (a.l.fornecedor || '').localeCompare(b.l.fornecedor || '');
  linhas.sort(ord).forEach((x, i) => {
    const row = ws.getRow(h + 1 + i);
    row.values = [x.l.mes, x.l.conta, nomeConta[x.l.conta] || x.l.contaNome || '', x.l.fornecedor || x.l.chave, x.l.nf || '', x.l.tipo, String(x.l.historico).replace(/\s+/g, ' ').slice(0, 200), x.l.valor, x.casou, x.status, x.oque, x.contaOk];
    row.font = F({ size: 9 });
    row.getCell(8).numFmt = MONEY;
    row.getCell(10).fill = fill(COR_ST(x.status));
  });
  ws.autoFilter = { from: { row: h, column: 1 }, to: { row: h + linhas.length, column: 12 } };

  // ---------- Sem par × ERP (base financeira que alimenta o P&L) ----------
  const X = require('./cruza_sempar_erp.js');
  const cls = x => { const h = x.hit; if (!h) return ['Não está no ERP', 'Não há pagamento deste fornecedor na base financeira (ERP) de out/25 a ago/26. Pedir à Jusfy: é despesa da Jusfy? Se for, entra no ERP e no P&L; se não for, sai do razão.'];
    if (/identificar/i.test(h.classe)) return ['No ERP sem linha do P&L', 'Está no ERP (' + h.comp + ', ' + fmt(h.v) + ') marcado \'identificar\': a Controladoria ainda não classificou, por isso não entrou no P&L.'];
    if (/^8\.|^1\.2\.2/.test(h.classe + ' ' + h.conta)) return ['CAPEX no ERP', 'No ERP é compra de ativo (' + h.classe + ', ' + h.comp + '): tirar da despesa e lançar no imobilizado.'];
    if (h.comp < '2026-01') return ['Competência 2025 no ERP', 'No ERP é de ' + h.comp + ' (' + fmt(h.v) + '): sai da despesa de 2026.'];
    const mm = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago'][+h.comp.slice(5) - 1];
    return [mm === x.l.mes ? 'No ERP no mesmo mês, sem linha no P&L' : 'No ERP em outro mês, sem linha no P&L', 'No ERP: ' + h.nomeOrig + ', ' + h.classe + ', competência ' + h.comp + ', ' + fmt(h.v) + '. O P&L gerencial não tem este fornecedor (' + h.classe + '). Controladoria: incluir no P&L ou dizer onde está.'];
  };
  const sx = wb.addWorksheet('Sem par × ERP');
  sx.columns = [{ width: 7 }, { width: 36 }, { width: 14 }, { width: 14 }, { width: 30 }, { width: 34 }, { width: 90 }];
  titulo(sx, 'Razão sem par no P&L × base financeira (ERP)', 'Cada linha do razão que não casou com um fornecedor do P&L, procurada na base financeira que alimenta o P&L (mesmo fornecedor, valor até 1% e competência). Os que o ERP provou já foram casados e saíram desta lista (Salvy, Claude, GoDaddy, Mobbin, RR, estornos a clientes, Processos Judiciais, hotéis, táxi, telefonia, suprimentos, Olada, Endeavor, reembolso de equipamento do Rafael Candia, CAPEX de LG/Mercado Livre/Eletro para Você/Belmirico/Renato).', 7);
  let q0 = 4; cab(sx, q0, ['Mês', 'Fornecedor (razão)', 'Valor', 'Conta', 'Resultado', 'No ERP', 'O que fazer']); q0++;
  const tot0 = {};
  X.slice().sort((a, b) => Math.abs(b.l.valor) - Math.abs(a.l.valor)).forEach(x => { const [st, tx] = cls(x); tot0[st] = (tot0[st] || 0) + x.l.valor;
    lin(sx, q0, [x.l.mes, x.ch, x.l.valor, x.l.conta, st, x.hit ? x.hit.comp + ' ' + x.hit.nomeOrig.slice(0, 24) : '—', tx], { money: [2], fill: { 4: /Não está/.test(st) ? COR.VERMELHO : COR.AMARELO } }); q0++; });
  q0++; Object.entries(tot0).forEach(([k, v]) => { lin(sx, q0, ['', 'TOTAL — ' + k, r2(v)], { money: [2], bold: true, fillAll: COR.CINZA }); q0++; });

  // ---------- Notas explicativas ----------
  const nt = wb.addWorksheet('Notas explicativas');
  nt.columns = [{ width: 5 }, { width: 38 }, { width: 110 }, { width: 18 }];
  titulo(nt, 'Notas explicativas e pontos a confirmar', 'O que ainda fica diferente depois dos ajustes das abas 1 a 5, e por quê. Cinza = já sabemos o motivo, nada a fazer agora. Amarelo = precisa que a Jusfy confirme antes de mexer.', 4);
  const caso = re => casos.find(c => re.test(c.nome));
  const porMes = (c, campo) => c ? MESES.map(m => m + ' ' + fmt(c[campo][m] || 0)).join(' | ') : '';
  const pm = caso(/^Pagar\.me/), ga = caso(/^Google Ads/), li = caso(/^LinkedIn Ads/), se = caso(/^Selki/), jo = caso(/^JOINVIX/), sy = caso(/^Syhus/);
  const sp = re => semParCasos.filter(s => re.test(s.chave));
  const totSp = re => r2(soma(sp(re), s => s.total));
  const F2 = require('./folha.json');
  const distJun = F2.distratosAplicados.filter(d => d.mes === 'Jun' && /somado/.test(d.obs));
  const troc = F2.distratosAplicados.filter(d => /vencimento/.test(d.obs));
  const notas = [
    ['Nota', 'Taxa da Pagar.me', 'O P&L tem a taxa cheia que a Pagar.me cobra. No razão só entram as notas fiscais de serviço da Pagar.me; o resto da taxa é descontado direto do dinheiro que cai na conta, sem passar pelo razão como despesa. Gerencial: ' + porMes(pm, 'alvoMes') + '. Razão: ' + porMes(pm, 'razMes') + '.', 'Pedir para a Syhus lançar a taxa cheia (tem o extrato da Pagar.me).'],
    ['Nota', 'Distratos de junho', 'Os ' + distJun.length + ' distratos de junho (' + distJun.map(d => d.pessoa + ' ' + fmt(d.valor)).join(', ') + ') já estão certos, pessoa por pessoa, na aba 4.', 'Nada a fazer.'],
    ['Nota', 'Cursos e treinamentos (Lucas Marchese, Endeavor)', 'R$ 28.600 no razão (Lucas Marchese R$ 19.800 + provisão de cursos R$ 9.040) não têm onde entrar no P&L: essa categoria (cursos/treinamento como benefício) não existe hoje no P&L.', 'Perguntar: essa despesa existe? Se sim, criar a linha no P&L.'],
    ['Nota', 'Bolsa de estágio e provisão de férias', 'R$ 9.100 de bolsa-estágio (Catarina, estagiária) e R$ 750 de provisão de férias no razão. Catarina não está cadastrada no painel de pessoas.', 'Perguntar: incluir a Catarina no Cadastro/painel?'],
    ['Confirmar', 'Magazine Luiza em junho', 'Em abril, 10 notas da Magazine Luiza estão certas (conta de brindes). Em junho aparecem mais 5 (R$ 2.268) citando os mesmos números de nota de abril, só que com valor um pouco diferente, numa conta errada (custo de software).', 'Perguntar para a Syhus: é lançamento repetido? Se for, excluir.'],
    ['Confirmar', 'CSP Treinamento', 'R$ 9.800 (jan a abr) do fornecedor CSP Treinamento não aparecem em nenhuma base da empresa.', 'Perguntar: essa despesa existe?'],
    ['Confirmar', 'Google Ads: gerencial menor que a nota', 'Em alguns meses o P&L é menor que as notas fiscais do Google Ads (em fev e mai o P&L bate exato com a soma de 2 notas). Gerencial: ' + porMes(ga, 'alvoMes') + '. Notas: ' + porMes(ga, 'razMes') + '.', 'Perguntar: o P&L usou o gasto da plataforma em vez da nota fiscal?'],
    ['Confirmar', 'Assinatura do LinkedIn', 'O razão tem uma cobrança mensal do LinkedIn (~R$ 5 mil) que o P&L não tem, exceto em junho. Razão: ' + porMes(li, 'razMes') + '.', 'Perguntar: em que linha do P&L entra essa assinatura?'],
    ['Confirmar', 'Selki e JOINVIX', 'Selki manda nota todo mês; o P&L não tem fev nem mar. JOINVIX manda nota de R$ 5.000 todo mês; o P&L soma R$ 50.000 só em alguns meses.', 'Perguntar como o P&L trata esses dois fornecedores.'],
    ['Confirmar', 'Nota da Syhus em dobro em janeiro', 'A nota de janeiro da própria Syhus (' + fmt(sy ? sy.razMes.Jan : 0) + ') veio quase o dobro das outras (~R$ 10.309); o P&L de janeiro é ' + fmt(sy ? sy.alvoMes.Jan : 0) + '.', 'Pedir para a Syhus explicar essa nota (pode ser 13º).'],
    ['Confirmar', 'Fornecedor com nome trocado', 'A nota da ZEE Films de maio (R$ 74.800) parece juntar duas coisas que o P&L separa: ZEE Films de junho + Role Filmes de maio. E as notas de R$ 2.500 da Capi Candia parecem ser da Junqueira e Candia Advocacia, que não tem nota própria no razão.', 'Confirmar se são o mesmo fornecedor.'],
    ['Confirmar', 'Pessoa jurídica com nome de empresa diferente', Object.entries(RG.VINCULO_PJ).map(([k, v]) => k + ' = ' + v.pessoa).join('; ') + '. Provado porque o valor bate exato com o Realizado.', 'Confirmar esses vínculos.'],
    ['Nota', 'Compra de equipamento lançada como despesa', 'Compras de computador/móveis (Dell, LG, Kabum, entre outros) foram lançadas como despesa. No P&L são investimento (imobilizado).', 'Já está na aba 1: mover para o imobilizado.'],
  ];
    let q = 4;
  cab(nt, q, ['', 'Assunto', 'O que está acontecendo', 'O que fazer']); q++;
  notas.forEach(n => { lin(nt, q, ['', n[1], n[2], n[3]], { fill: { 0: n[0] === 'Nota' ? COR.CINZA : COR.AMARELO } }); nt.getCell(q, 2).font = F({ bold: true }); nt.getRow(q).height = Math.min(160, 16 * Math.ceil(n[2].length / 105) + 6); q++; });
  return { linhas };
};
