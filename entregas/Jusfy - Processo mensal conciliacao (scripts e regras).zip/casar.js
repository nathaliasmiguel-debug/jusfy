// Passo 3: casa cada fornecedor do P&L gerencial com os fornecedores do razão.
const fs = require('fs');
const path = require('path');
const RG = require('./regras.js');
const L = require('./lancamentos.json');
const G0 = require('../extracted/dados/gerencial_fornecedor.json');

const MESES = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'];
const SUFIXOS = /\b(LTDA|LTD|S\/?A|SA|EIRELI|ME|EPP|INC|LLC|CORP|CORPORATION|SOCIEDADE INDIVIDUAL DE ADVOCACIA|SERVICOS|SERVICO|DO BRASIL|BRASIL|DE|DA|DO|E|EM|PF)\b/g;
function chave(nome) {
  let s = String(nome).replace(/\([^)]*\)/g, ' ').toUpperCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  s = s.replace(/^\d{1,3}(\.\d{3}){2}\s+/, '').replace(/\s\d{11}\b/g, '').replace(/[^A-Z0-9 ]/g, ' ').replace(SUFIXOS, ' ').replace(/\s+/g, ' ').trim();
  return s;
}
const STOP = new Set(['TECNOLOGIA', 'INFORMACAO', 'INFORMATICA', 'SISTEMAS', 'SOLUCOES', 'CONSULTORIA', 'COMERCIO', 'INTERNET', 'DIGITAL', 'DIGITAIS',
  'SOFTWARE', 'PAGAMENTOS', 'PAGAMENTO', 'FATURA', 'GRUPO', 'GROUP', 'COMPANY', 'ONLINE', 'SAO', 'PAULO', 'REPRESENTACOES', 'PESQUISA', 'BANCO', 'DADOS',
  'ADVOGADOS', 'ASSOCIADOS', 'ASSESSORIA', 'IMPRENSA', 'CONTABILIDADE', 'TREINAMENTOS', 'MENTORIAS', 'ADMINISTRATIVOS', 'OTHER', 'OTHERS',
  'EXPENSES', 'SUPPLIERS', 'THE', 'AND', 'FOR', 'TEAM', 'PLUS', 'PRO', 'ALUGUEL', 'NUMEROS', 'TELEFONE', 'SEDE', 'NOVA', 'SUBSCRIPTION', 'COMMUNITY', 'CPUS', 'YEAR', 'CURSOS', 'JURIDICOS', 'INSTITUTO', 'ESTUDOS', 'ERP', 'NACIONAL', 'DIREITO', 'VIAGENS', 'PACOTE', 'MENSALIDADE']);
const AMBIGUO = new Set(['GOOGLE', 'AMAZON', 'MICROSOFT', 'FACEBOOK', 'META', 'APPLE', 'PAYPAL']);

// ---- universo do razão (sem depreciação) ----
const RAZ = L.filter(l => /^(4\.1|6\.2)/.test(l.conta) && !RG.naoOperacional(l));
const porChave = {};
RAZ.forEach(l => { (porChave[l.chave] = porChave[l.chave] || []).push(l); });
const chavesRazao = Object.keys(porChave);
const tokensDe = {}; chavesRazao.forEach(k => tokensDe[k] = new Set(k.split(' ')));
const contasDe = {}; chavesRazao.forEach(k => contasDe[k] = new Set(porChave[k].map(l => l.conta)));
const soFolha = k => [...contasDe[k]].every(c => RG.CONTAS_FOLHA.has(c));

// ---- universo do gerencial ----
const fora = r => RG.FORA_ESCOPO_SUBLINHA.has(r.sublinha) || RG.FORA_ESCOPO_FORNECEDOR.has(r.fornecedor.trim());
const G = G0.filter(r => !fora(r));
const foraEscopo = G0.filter(fora);
const ehRubrica = r => RG.RUBRICAS[r.fornecedor.trim()] || r.fornecedor.trim() === r.sublinha || /^(Others?|Outros)$/i.test(r.fornecedor.trim());
const nomesGer = {}; // nome -> {sublinhas:Set}
G.filter(r => !ehRubrica(r)).forEach(r => { const n = r.fornecedor.trim(); (nomesGer[n] = nomesGer[n] || { sublinhas: new Set() }).sublinhas.add(r.sublinha); });

function contasPermitidas(nomeGer, sublinhas) {
  const s = new Set();
  if (RG.ADS[nomeGer]) s.add(RG.ADS[nomeGer]);
  sublinhas.forEach(sb => (RG.CONTAS_DA_SUBLINHA[sb] || []).forEach(c => s.add(c)));
  return s;
}

const casamento = {}; // nomeGer -> {chaves:[], metodo}
for (const [nome, info] of Object.entries(nomesGer)) {
  const permit = contasPermitidas(nome, info.sublinhas);
  let chaves = [], metodo = '';
  if (RG.ADS[nome]) {
    chaves = chavesRazao.filter(k => contasDe[k].has(RG.ADS[nome]));
    metodo = 'conta da plataforma ' + RG.ADS[nome];
  }
  const temAlias = Object.prototype.hasOwnProperty.call(RG.ALIAS, nome);
  if (temAlias) { chaves = [...new Set([...chaves, ...RG.ALIAS[nome].flatMap(a => chavesRazao.filter(k => k === a || k.startsWith(a + ' ')))])]; metodo = metodo ? metodo + ' + de-para confirmado' : 'de-para confirmado'; }
  if (!chaves.length && !temAlias) {
    const gk = chave(nome);
    const toks = gk.split(' ').filter(t => t.length >= 3 && !STOP.has(t));
    if (toks.length) {
      let cand = chavesRazao.filter(k => tokensDe[k].has(toks[0]) && !soFolha(k));
      if (!cand.length) cand = chavesRazao.filter(k => tokensDe[k].has(toks[0]));
      if (!cand.length && toks[0].length >= 4) cand = chavesRazao.filter(k => [...tokensDe[k]].some(t => t.startsWith(toks[0])));
      for (let i = 1; !cand.length && i < toks.length; i++) if (toks[i].length >= 5) cand = chavesRazao.filter(k => tokensDe[k].has(toks[i]));
      // pelo menos metade das palavras do nome gerencial tem que estar no nome do razão
      if (toks.length >= 2) cand = cand.filter(k => toks.filter(t => [...tokensDe[k]].some(x => x === t || (t.length >= 4 && x.startsWith(t)))).length / toks.length >= 0.5);
      if (cand.length > 1 && toks[1]) { const c2 = cand.filter(k => tokensDe[k].has(toks[1])); if (c2.length) cand = c2; }
      if (cand.length > 1 && permit.size) { const c3 = cand.filter(k => [...contasDe[k]].some(c => permit.has(c))); if (c3.length) cand = c3; }
      if (cand.length === 1 || (cand.length > 1 && toks[0].length >= 5 && !AMBIGUO.has(toks[0]))) { chaves = cand; metodo = 'nome (' + toks[0] + ')'; }
      else if (cand.length > 1) { chaves = cand; metodo = 'AMBÍGUO (' + toks[0] + ')'; }
    }
  }
  casamento[nome] = { chaves, metodo: chaves.length ? metodo : 'sem par no razão', sublinhas: [...info.sublinhas], permitidas: [...permit] };
}

const CONTAS_RUBRICA = new Set(Object.values(RG.RUBRICAS).flat());
// ---- grupos = componentes conexos nome gerencial <-> chave do razão ----
const pai = {};
const find = x => (pai[x] === undefined ? (pai[x] = x) : pai[x] === x ? x : (pai[x] = find(pai[x])));
const unir = (a, b) => { pai[find(a)] = find(b); };
Object.entries(casamento).forEach(([n, c]) => { find('G:' + n); c.chaves.forEach(k => unir('G:' + n, 'R:' + k)); });
const comp = {};
Object.keys(pai).forEach(x => { const r = find(x); (comp[r] = comp[r] || []).push(x); });

const grupos = Object.values(comp).map(membros => {
  const nomes = membros.filter(m => m.startsWith('G:')).map(m => m.slice(2));
  const chaves = membros.filter(m => m.startsWith('R:')).map(m => m.slice(2));
  const sublinhas = [...new Set(nomes.flatMap(n => casamento[n].sublinhas))];
  const permitidas = [...new Set(nomes.flatMap(n => casamento[n].permitidas))];
  const gerMes = {}, gerSub = {};
  MESES.forEach(m => { gerMes[m] = 0; });
  G.filter(r => nomes.includes(r.fornecedor.trim())).forEach(r => { gerMes[r.mes] += r.valor; gerSub[r.sublinha] = (gerSub[r.sublinha] || 0) + r.valor; });
  const lanc = chaves.flatMap(k => porChave[k]).filter(l => permitidas.includes(l.conta) || !CONTAS_RUBRICA.has(l.conta));
  const razMes = {}; MESES.forEach(m => { razMes[m] = 0; });
  lanc.forEach(l => { razMes[l.mes] += l.valor; l._dono = 'G'; });
  const subPrincipal = Object.entries(gerSub).sort((a, b) => b[1] - a[1])[0];
  const contaPadrao = (nomes.map(n => RG.ADS[n]).find(Boolean)) || (subPrincipal && (RG.CONTAS_DA_SUBLINHA[subPrincipal[0]] || [])[0]) || '';
  return { tipo: 'fornecedor', nomesGer: nomes, chaves, metodo: [...new Set(nomes.map(n => casamento[n].metodo))].join(' | '),
    sublinhas, permitidas, contaPadrao, gerMes, razMes, lancamentos: lanc };
});

// ---- rubricas agregadas: casam pelo que sobra nas contas delas ----
const chavesUsadas = new Set(grupos.flatMap(g => g.chaves));
const rubricas = Object.entries(RG.RUBRICAS).map(([nome, contas]) => {
  const gerMes = {}; MESES.forEach(m => { gerMes[m] = 0; });
  const linhasG = G.filter(r => r.fornecedor.trim() === nome);
  linhasG.forEach(r => { gerMes[r.mes] += r.valor; });
  const lanc = RAZ.filter(l => contas.includes(l.conta) && !l._dono);
  lanc.forEach(l => { l._dono = 'R'; });
  const razMes = {}; MESES.forEach(m => { razMes[m] = 0; });
  lanc.forEach(l => { razMes[l.mes] += l.valor; });
  return { tipo: 'rubrica', nomesGer: [nome], chaves: [...new Set(lanc.map(l => l.chave))], metodo: 'rubrica agregada (conta ' + contas.join(', ') + ')',
    sublinhas: [...new Set(linhasG.map(r => r.sublinha))], permitidas: contas, contaPadrao: contas[0], gerMes, razMes, lancamentos: lanc };
});
rubricas.forEach(r => r.chaves.forEach(k => chavesUsadas.add(k)));

// ---- sobras: fornecedores do razão sem par no gerencial (fora das contas de folha) ----
const semPar = chavesRazao.map(k => {
  const lanc = porChave[k].filter(l => !l._dono && !RG.CONTAS_FOLHA.has(l.conta));
  const razMes = {}; MESES.forEach(m => { razMes[m] = 0; });
  lanc.forEach(l => { razMes[l.mes] += l.valor; });
  return { chave: k, lancamentos: lanc, razMes, total: lanc.reduce((a, l) => a + l.valor, 0) };
}).filter(x => x.lancamentos.length);

fs.writeFileSync(path.join(__dirname, 'grupos.json'), JSON.stringify({ grupos, rubricas, semPar, foraEscopo, casamento }));

const tot = a => MESES.reduce((s, m) => s + a[m], 0);
const nG = Object.keys(casamento).length, nSem = Object.values(casamento).filter(c => !c.chaves.length).length;
const amb = Object.entries(casamento).filter(([, c]) => /AMBÍGUO/.test(c.metodo));
console.log('fornecedores gerenciais:', nG, '| casados:', nG - nSem, '| sem par no razão:', nSem, '| ambíguos:', amb.length);
console.log('grupos:', grupos.length, '| rubricas:', rubricas.length, '| fornecedores do razão sem par:', semPar.length, 'R$', Math.round(semPar.reduce((a, s) => a + s.total, 0)));
console.log('GER total no escopo Jan-Jun:', Math.round(G.reduce((a, r) => a + r.valor, 0)), '| GER casado:', Math.round(grupos.filter(g => g.chaves.length).reduce((a, g) => a + tot(g.gerMes), 0) + rubricas.reduce((a, r) => a + tot(r.gerMes), 0)));
