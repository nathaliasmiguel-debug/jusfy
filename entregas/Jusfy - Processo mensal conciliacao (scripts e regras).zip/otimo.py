# Mínimo exato de lançamentos (HiGHS via scipy.milp): total, custo e despesa dentro da tolerância em todo mês e,
# por fornecedor × mês × grupo, nenhum lançamento deixa a linha mais longe do P&L do que estava ("nunca piorar").
import json, sys, numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix
d = json.load(open('milp_in.json'))
n, M = d['n'], 6
c = np.array(d['peso'], dtype=float)
nrows = 3 * M + len(d['pior'])
A = lil_matrix((nrows, n)); lo = np.zeros(nrows); hi = np.zeros(nrows); r = 0
for i in range(M):
    for g in ('C', 'O'):
        for k in range(n):
            v = d['ef'][k][g][i]
            if v: A[r, k] = v
        lo[r] = -d['lim'][g][i] - d['base'][g][i]; hi[r] = d['lim'][g][i] - d['base'][g][i]; r += 1
    for k in range(n):
        v = d['ef'][k]['C'][i] + d['ef'][k]['O'][i]
        if v: A[r, k] = v
    b = d['base']['C'][i] + d['base']['O'][i]
    lo[r] = -d['lim']['T'][i] - b; hi[r] = d['lim']['T'][i] - b; r += 1
for p in d['pior']:
    for k, v in p['efs'].items(): A[r, int(k)] = v
    a0 = abs(p['r0']) + 1
    lo[r] = -a0 - p['r0']; hi[r] = a0 - p['r0']; r += 1
lb = np.zeros(n)
for k in d.get('forcados', []): lb[k] = 1
res = milp(c, constraints=LinearConstraint(A.tocsr(), lo, hi), integrality=np.ones(n), bounds=Bounds(lb, 1),
           options={'time_limit': 300, 'mip_rel_gap': 0})
if res.x is None:
    print('SEM SOLUÇÃO:', res.message); json.dump({'status': res.status, 'msg': res.message, 'escolhidos': None}, open('milp_out.json', 'w')); sys.exit(1)
x = [k for k in range(n) if res.x[k] > 0.5]
json.dump({'escolhidos': x, 'lancamentos': int(sum(d['peso'][k] for k in x)), 'status': res.status, 'msg': res.message}, open('milp_out.json', 'w'))
print('status:', res.message, '| movimentos:', len(x), '| lançamentos:', int(sum(d['peso'][k] for k in x)))
