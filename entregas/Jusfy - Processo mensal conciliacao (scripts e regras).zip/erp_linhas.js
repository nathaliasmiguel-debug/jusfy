// Casamento linha a linha razão × ERP (base da Mari), um pra um: cada nota do ERP só pode explicar uma linha do razão.
// Por fornecedor (primeiro nome significativo) e valor (até 1%). O ERP às vezes quebra uma nota em várias linhas por
// centro de custo: então também vale a soma das linhas do ERP do mesmo fornecedor, mesma competência e mesma data.
// 1ª passada: mesmo mês. 2ª: mês mais perto, de 2 meses antes até 1 depois. Sem par = a nota não está no ERP.
const A = require('./achados.json'); const R = require('../extracted/dados/base_mari_rows.json');
const ymi = s => { const n = parseFloat(s); if (!n) return null; const d = new Date(Date.UTC(1899, 11, 30) + n * 864e5); return (d.getUTCFullYear() - 2026) * 12 + d.getUTCMonth(); };
const val = s => -(parseFloat(String(s).replace(/[^\d,-]/g, '').replace(',', '.')) || 0);
const norm = s => String(s || '').toUpperCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
const GEN = new Set(['PIX', 'ENVIADO', 'PARA', 'PAGAMENTO', 'NF', 'BOLETO', 'PARC', 'DEBITO', 'CARTAO', 'FATURA', 'COMPRA', 'CONFORME', 'PROVISAO', 'LTDA', 'DOS', 'DAS', 'THE']);
const chave = s => norm(s).split(' ').filter(t => t.length >= 3 && !GEN.has(t) && !/^\d+$/.test(t))[0] || '';
const M = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'];
const nomeMes = i => (i >= 0 && i < 6 ? M[i] : i < 0 ? ['Nov/25', 'Dez/25'][i + 2] : 'Jul');
const erp = [];
R.forEach((r, id) => { const i = ymi(r['14']); if (r['1'] === 'OK' && i !== null && i >= -3 && i <= 7) erp.push({ id, nome: norm(r['9'] + ' ' + (r['17'] || '')), i, v: val(r['11']), data: r['8'] || r['2'], classe: String(r['5']), fornecedor: r['9'], conta: r['10'], cc: r['13'] }); });
// grupos (mesmo fornecedor + competência + data): nota quebrada por centro de custo
const grupos = {};
erp.forEach(e => { const k = e.fornecedor + '|' + e.i + '|' + e.data; (grupos[k] = grupos[k] || { ids: [], v: 0, i: e.i, nome: e.nome, fornecedor: e.fornecedor, classe: e.classe }).ids.push(e.id); grupos[k].v += e.v; });
const cands = erp.map(e => ({ ids: [e.id], v: e.v, i: e.i, nome: e.nome, fornecedor: e.fornecedor, classe: e.classe }))
  .concat(Object.values(grupos).filter(g => g.ids.length > 1));
const perto = (a, b) => Math.abs(Math.abs(a) - Math.abs(b)) <= Math.max(1, Math.abs(a) * 0.01);

const porLinha = new Map(); // linha do razão -> { i (competência no ERP), cand }
const usado = new Set();
const livre = c => c.ids.every(id => !usado.has(id));
A.casos.forEach(c => {
  const ls = c.lancamentos.filter(l => l.valor > 0);
  const ch = l => chave(l.fornecedor || l.chave || c.nome);
  const tenta = (l, ok) => {
    const k = ch(l); if (!k) return;
    const i = M.indexOf(l.mes);
    const hit = cands.filter(x => livre(x) && x.nome.split(' ').includes(k) && perto(l.valor, x.v) && ok(x.i, i))
      .sort((x, y) => Math.abs(x.i - i) - Math.abs(y.i - i) || x.ids.length - y.ids.length || Math.abs(Math.abs(x.v) - l.valor) - Math.abs(Math.abs(y.v) - l.valor))[0];
    if (hit) { hit.ids.forEach(id => usado.add(id)); porLinha.set(l, hit); }
  };
  ls.forEach(l => tenta(l, (xi, i) => xi === i));
  ls.filter(l => !porLinha.has(l)).forEach(l => tenta(l, (xi, i) => xi >= i - 2 && xi <= i + 1 && xi !== i));
});
module.exports = { porLinha, chave, nomeMes, M, R };
