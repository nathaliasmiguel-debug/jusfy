// Passo 6: gera o arquivo para a Syhus (formato da v2: uma aba por mês + consolidado + abas de ação).
const ExcelJS = require('exceljs');
const path = require('path');
const fs = require('fs');
const RG = require('./regras.js');
const { casos, semParCasos, foraEscopo } = require('./achados.json');
const L = require('./lancamentos.json');
const A2 = require('./ajustes_antigos.json');

const MESES = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'];
const MESNOME = { Jan: 'Janeiro', Fev: 'Fevereiro', Mar: 'Março', Abr: 'Abril', Mai: 'Maio', Jun: 'Junho' };
const r2 = x => Math.round(x * 100) / 100;
const soma = (a, f) => a.reduce((s, x) => s + f(x), 0);
const nomeConta = {}; L.forEach(l => { nomeConta[l.conta] = l.contaNome; });
Object.assign(nomeConta, { '6.2.1.03.004': 'Custo de Inteligência Artificial', '4.1.3.01.009': 'Twitter Ads' });
const ehCOGS = c => /^6\.2\./.test(c);

// ---------- aplica as ações (as que são para lançar) conta a conta ----------
const LANCAVEL = a => !a.semLancar && a.tipo !== 'VERIFICAR' && !/^NOTA/.test(a.tipo);
const linhas = {}; // mes|conta|entidade -> {conta, entidade, bloco, esta, ajuste, textos:Set, tipos:Set}
const chaveL = (m, c, e) => m + '|' + c + '|' + e;
function linha(m, c, e, bloco) { const k = chaveL(m, c, e); return (linhas[k] = linhas[k] || { mes: m, conta: c, entidade: e, bloco, esta: 0, ajuste: 0, textos: [], tipos: new Set() }); }
function contaDaAcao(c, a) {
  if (a.tipo === 'RECLASSIFICAR') return a.conta;
  return (c.permitidas || []).includes(a.conta) ? a.conta : c.contaPadrao;
}
casos.forEach(c => {
  c.lancamentos.forEach(l => { linha(l.mes, l.conta, c.nome, c.bloco).esta += l.valor; });
  c.acoes.forEach(a => {
    if (!LANCAVEL(a)) { const ln = linha(a.mes, c.contaPadrao || a.conta, c.nome, c.bloco); ln.textos.push('⚠ ' + a.tipo + ': ' + a.texto); ln.tipos.add(a.tipo); return; }
    if (a.tipo === 'RECLASSIFICAR') {
      const de = linha(a.mes, a.conta, c.nome, c.bloco), para = linha(a.mes, a.contaPara, c.nome, c.bloco);
      de.ajuste -= a.valor; para.ajuste += a.valor;
      de.textos.push('Reclassificar: ' + a.texto); de.tipos.add(a.tipo);
      para.textos.push('Recebe R$ ' + Math.round(a.valor).toLocaleString('pt-BR') + ' vindos da conta ' + a.conta + '.'); para.tipos.add(a.tipo);
      return;
    }
    const ln = linha(a.mes, contaDaAcao(c, a), c.nome, c.bloco);
    ln.ajuste += a.valor; ln.textos.push(a.tipo + ': ' + a.texto); ln.tipos.add(a.tipo);
  });
});
semParCasos.forEach(s => {
  s.lancamentos.forEach(l => { const ln = linha(l.mes, l.conta, s.fornecedor, 'Sem par no gerencial'); ln.esta += l.valor; });
  MESES.forEach(m => {
    const ls = s.lancamentos.filter(l => l.mes === m);
    const contas = [...new Set(ls.map(l => l.conta))];
    contas.forEach(ct => {
      const ln = linha(m, ct, s.fornecedor, 'Sem par no gerencial');
      if (RG.CONTAS_PASSAGEM[ct] && s.contaSugerida) {
        const v = r2(soma(ls.filter(l => l.conta === ct), l => l.valor));
        ln.ajuste -= v; ln.textos.push('Reclassificar: está na conta ' + ct + ' (' + RG.CONTAS_PASSAGEM[ct] + ', conta de passagem). Nos outros meses este fornecedor está na conta ' + s.contaSugerida + ': mover para lá.'); ln.tipos.add('RECLASSIFICAR');
        const p = linha(m, s.contaSugerida, s.fornecedor, 'Sem par no gerencial'); p.ajuste += v; p.textos.push('Recebe R$ ' + Math.round(v).toLocaleString('pt-BR') + ' vindos da conta ' + ct + '.'); p.tipos.add('RECLASSIFICAR');
      } else if (!ln.textos.length) {
        ln.textos.push(RG.CONTAS_PASSAGEM[ct] ? '⚠ Conta de passagem (' + RG.CONTAS_PASSAGEM[ct] + ') e fornecedor sem par no P&L: Controladoria define a conta.' : '⚠ Sem par no gerencial: Controladoria classifica antes de ajustar.');
        ln.tipos.add('SEM PAR');
      }
    });
  });
});
const TODAS = Object.values(linhas).map(x => ({ ...x, esta: r2(x.esta), ajuste: r2(x.ajuste), deve: r2(x.esta + x.ajuste) }));

fs.writeFileSync(path.join(__dirname, 'todas.json'), JSON.stringify(TODAS));
// ---------- visual ----------
const NAVY = 'FF12395E', INK = 'FF1F2933', MUTED = 'FF6B7A88', LINE = 'FFDDE4EA', CINZA = 'FFEEF1F4';
const VERDE = 'FFE3F1E8', AMARELO = 'FFFFF4CC', LARANJA = 'FFFDE7D6', VERMELHO = 'FFF8DEDE', AZUL = 'FFE3EEF8', LILAS = 'FFEDE7F6';
const F = (o = {}) => Object.assign({ name: 'Poppins', size: 10, color: { argb: INK } }, o);
const fill = c => ({ type: 'pattern', pattern: 'solid', fgColor: { argb: c } });
const MONEY = '#,##0.00;[Red]-#,##0.00;"-"';
const COR_TIPO = { 'RECLASSIFICAR': AZUL, 'EXCLUIR DUPLICADO': VERMELHO, 'ESTORNAR PROVISÃO': VERMELHO, 'COMPETÊNCIA 2025': LILAS, 'PROVISIONAR': LARANJA,
  'BAIXAR PROVISÃO': LARANJA, 'COMPLEMENTAR PROVISÃO': LARANJA, 'REDUZIR PROVISÃO': LARANJA, 'REVERTER (NF adiantada)': LARANJA, 'FALTA LANÇAR': AMARELO,
  'VERIFICAR': CINZA, 'SEM PAR': CINZA, 'NOTA (diferença conhecida)': CINZA };
function titulo(ws, t, s, n) {
  ws.mergeCells(1, 1, 1, n); const a = ws.getCell(1, 1); a.value = t; a.font = F({ size: 15, bold: true, color: { argb: NAVY } });
  ws.mergeCells(2, 1, 2, n); const b = ws.getCell(2, 1); b.value = s; b.font = F({ size: 10, italic: true, color: { argb: MUTED } }); b.alignment = { wrapText: true, vertical: 'top' };
  ws.getRow(1).height = 26; ws.getRow(2).height = Math.max(30, Math.ceil(s.length / 150) * 15);
}
function cab(ws, l, cols) {
  cols.forEach((h, i) => { const c = ws.getCell(l, i + 1); c.value = h; c.font = F({ bold: true, color: { argb: 'FFFFFFFF' } }); c.fill = fill(NAVY); c.alignment = { vertical: 'middle', wrapText: true }; });
  ws.getRow(l).height = 30; ws.views = [{ state: 'frozen', ySplit: l }];
}
function lin(ws, l, vals, o = {}) {
  vals.forEach((v, i) => {
    const c = ws.getCell(l, i + 1); c.value = v; c.font = F(o.bold ? { bold: true } : {});
    c.alignment = { wrapText: true, vertical: 'top' }; c.border = { bottom: { style: 'thin', color: { argb: LINE } } };
    if ((o.money || []).includes(i)) c.numFmt = MONEY;
    if ((o.pct || []).includes(i)) c.numFmt = '0.00%';
    if (o.fillAll) c.fill = fill(o.fillAll);
    if (o.fill && o.fill[i]) c.fill = fill(o.fill[i]);
  });
}
const corDe = tipos => { for (const t of ['EXCLUIR DUPLICADO', 'ESTORNAR PROVISÃO', 'COMPETÊNCIA 2025', 'RECLASSIFICAR', 'FALTA LANÇAR', 'COMPLEMENTAR PROVISÃO', 'REDUZIR PROVISÃO', 'PROVISIONAR', 'BAIXAR PROVISÃO', 'REVERTER (NF adiantada)', 'VERIFICAR', 'SEM PAR']) if (tipos.has(t)) return COR_TIPO[t]; return null; };

const wb = new ExcelJS.Workbook(); wb.creator = 'Jusfy - Controladoria';

// ================= LEIA-ME =================
const lm = wb.addWorksheet('LEIA-ME');
lm.columns = [{ width: 6 }, { width: 34 }, { width: 100 }];
titulo(lm, 'Ajustes no razão — Jan a Jun/2026 (v6)', 'Este arquivo diz, linha por linha, o que precisa mudar no razão para o DRE contábil ficar igual ao P&L gerencial. Cada ajuste tem o fornecedor, o mês, o valor e o motivo com a prova (número da NF, reversão ou valor idêntico). Nada aqui é estimativa.', 3);
let r = 4;
lm.getCell(r, 1).value = 'PRAZO CURTO: só a aba "0. FAZER PRIMEIRO"'; lm.getCell(r, 1).font = F({ size: 12, bold: true, color: { argb: NAVY } }); r += 1;
lin(lm, r, ['', '', 'São 32 lançamentos (não 1.339). Fazendo só esses, os 6 meses já ficam dentro de 0,5% de diferença do gerencial. É a prioridade agora; o resto (abas 1 a 9) pode esperar a próxima rodada.'], { fillAll: LILAS }); lm.getRow(r).height = 34; r += 2;
lm.getCell(r, 1).value = 'Depois, com mais tempo, faça nesta ordem:'; lm.getCell(r, 1).font = F({ size: 12, bold: true, color: { argb: NAVY } }); r += 1;
const passos = [
  ['1', 'Trocar de conta (azul)', 'Aba "1. Trocar de conta". O valor está certo, só está na conta errada. Tirar de uma conta e colocar na outra, mesmo mês, mesmo valor.'],
  ['2', 'Excluir (vermelho)', 'Aba "2. Excluir". Lançamentos que estão em dobro (mesma NF duas vezes, NF que repete pagamento de cartão, adiantamento lançado como despesa) e provisões que nunca foram revertidas. Excluir ou estornar a linha indicada.'],
  ['3', 'Tirar de 2026 (lilás)', 'Aba "3. Competência 2025". NFs, bônus, baixas de adiantamento e estornos de 2025 que entraram na despesa de 2026 (prova: valor de dez/2025 no ERP, data de 2025 no histórico ou NF de número anterior). Lançar contra a provisão/resultado de 2025.'],
  ['4', 'Provisionar e baixar (laranja)', 'Aba "4. Provisões e baixas". Quando a NF chega depois do mês dela: provisionar no mês certo e baixar no mês em que a NF entrou. Cada linha diz o mês da provisão, o mês da baixa e a NF.'],
  ['5', 'Lançar o que falta (amarelo)', 'Aba "5. Falta lançar". Fornecedor que está no P&L e não tem nenhum lançamento no razão.'],
  ['6', 'NÃO lançar ainda (cinza)', 'Abas "6. Pedir NF" e "7. Sem par no gerencial". Diferenças sem prova suficiente. Não ajustar: primeiro a Jusfy manda a NF ou a classificação.'],
  ['7', 'Conferir linha a linha', 'Aba "Razão linha a linha": cada uma das linhas do razão (jan a jun) com o status — certa, conta errada, em dobro, de 2025, mês errado, sem prova ou sem par — e o que fazer com ela. Use o filtro da coluna Status.'],
  ['8', 'Notas explicativas', 'Aba "Notas explicativas": diferenças que ficam entre o contábil e o P&L e por quê (não são erro de escrituração), e os pontos que a Controladoria confirma.'],
];
passos.forEach(p => { lin(lm, r, p, { fill: { 1: { '1': AZUL, '2': VERMELHO, '3': LILAS, '4': LARANJA, '5': AMARELO, '6': CINZA, '7': VERDE, '8': VERDE }[p[0]] } }); lm.getCell(r, 2).font = F({ bold: true }); lm.getRow(r).height = 34; r += 1; });
r += 1;
lm.getCell(r, 1).value = 'Como ler as abas de mês (Jan a Jun):'; lm.getCell(r, 1).font = F({ size: 12, bold: true, color: { argb: NAVY } }); r += 1;
[['', 'Conta', 'A linha do DRE contábil (a soma).'], ['', 'Fornecedor', 'O recheio: quem compõe aquela conta no razão.'], ['', 'Como está', 'O que o razão tem hoje.'],
 ['', 'Como deve ficar', 'O que o razão tem que ter depois dos ajustes (bate com o P&L gerencial).'], ['', 'Ajuste', 'A diferença a lançar (+ aumenta a despesa, − diminui).'], ['', 'O que fazer', 'A instrução e a prova.']]
  .forEach(p => { lin(lm, r, p); lm.getCell(r, 2).font = F({ bold: true }); r += 1; });
r += 1;
lm.getCell(r, 1).value = 'De onde vêm os números:'; lm.getCell(r, 1).font = F({ size: 12, bold: true, color: { argb: NAVY } }); r += 1;
[['', 'Razão', 'Razão01 a Razão06 da Syhus (jan a jun/2026), lido linha a linha. Conferido: a soma de cada conta bate com o "Total do mês" do próprio arquivo.'],
 ['', 'Gerencial', 'P&L por fornecedor (soma exatamente o P&L oficial nas 46 sublinhas). Folha: Realizado ERP por pessoa + base de distratos.'],
 ['', 'Conta certa', 'Árvore oficial do DRE (sublinha do P&L → conta contábil). Folha: área do Cadastro (Engenharia e Produto = custo 6.2.1.01.001; demais = despesa 4.1.6.01.007).']]
  .forEach(p => { lin(lm, r, p); lm.getCell(r, 2).font = F({ bold: true }); lm.getRow(r).height = 30; r += 1; });

// ================= RESUMO =================
const rs = wb.addWorksheet('Resumo');
rs.columns = [{ width: 30 }, ...MESES.map(() => ({ width: 15 })), { width: 16 }];
titulo(rs, 'Resumo — DRE contábil × P&L gerencial', 'Antes = razão como está hoje. Depois = razão com os ajustes das abas 1 a 5. Itens "pedir NF" e "sem par" não entram no depois (não são lançados sem prova).', 8);
const alvoCOGS = {}, alvoOPEX = {};
MESES.forEach(m => { alvoCOGS[m] = 0; alvoOPEX[m] = 0; });
casos.forEach(c => MESES.forEach(m => { if (ehCOGS(c.contaPadrao)) alvoCOGS[m] += c.alvoMes[m]; else alvoOPEX[m] += c.alvoMes[m]; }));
const somaT = (f, m) => r2(soma(TODAS.filter(x => x.mes === m && f(x)), x => x));
const antes = (f, m) => r2(soma(TODAS.filter(x => x.mes === m && f(x)), x => x.esta));
const depois = (f, m) => r2(soma(TODAS.filter(x => x.mes === m && f(x)), x => x.deve));
const fC = x => ehCOGS(x.conta) && x.bloco !== 'Sem par no gerencial', fO = x => !ehCOGS(x.conta) && x.bloco !== 'Sem par no gerencial', fS = x => x.bloco === 'Sem par no gerencial';
r = 4; cab(rs, r, ['', ...MESES, 'Total']); r += 1;
const Q = require('./quadro_dados.js');
const tot = v => r2(v.reduce((x, y) => x + y, 0));
const M7 = [1, 2, 3, 4, 5, 6, 7];
rs.getCell(r, 1).value = 'DRE operacional inteiro (custo + despesa)'; rs.getCell(r, 1).font = F({ bold: true, size: 11, color: { argb: NAVY } }); r += 1;
lin(rs, r, ['P&L gerencial (fornecedores + folha do painel People)', ...Q.ger, tot(Q.ger)], { money: M7 }); r += 1;
lin(rs, r, ['Contábil ANTES (razão como está)', ...Q.antes, tot(Q.antes)], { money: M7 }); r += 1;
lin(rs, r, ['Diferença ANTES', ...Q.antes.map((x, i) => r2(x - Q.ger[i])), r2(tot(Q.antes) - tot(Q.ger))], { money: M7, fillAll: AMARELO }); r += 1;
lin(rs, r, ['% ANTES', ...Q.antes.map((x, i) => (x - Q.ger[i]) / Q.ger[i]), (tot(Q.antes) - tot(Q.ger)) / tot(Q.ger)], { pct: M7, fillAll: AMARELO }); r += 1;
lin(rs, r, ['Contábil DEPOIS (com os ajustes das abas 1 a 5)', ...Q.depois, tot(Q.depois)], { money: M7, bold: true }); r += 1;
lin(rs, r, ['Diferença DEPOIS', ...Q.depois.map((x, i) => r2(x - Q.ger[i])), r2(tot(Q.depois) - tot(Q.ger))], { money: M7, fillAll: VERDE, bold: true }); r += 1;
lin(rs, r, ['% DEPOIS', ...Q.depois.map((x, i) => (x - Q.ger[i]) / Q.ger[i]), (tot(Q.depois) - tot(Q.ger)) / tot(Q.ger)], { pct: M7, fillAll: VERDE, bold: true }); r += 2;
rs.getCell(r, 1).value = 'De onde vem a diferença que sobra DEPOIS'; rs.getCell(r, 1).font = F({ bold: true, size: 11, color: { argb: NAVY } }); r += 1;
Q.composicao.forEach(([nome, v, cor]) => { lin(rs, r, [nome, ...v, tot(v)], { money: M7, fillAll: cor === 'nota' ? CINZA : cor === 'pend' ? AMARELO : undefined }); r += 1; });
lin(rs, r, ['= Diferença DEPOIS', ...Q.depois.map((x, i) => r2(x - Q.ger[i])), r2(tot(Q.depois) - tot(Q.ger))], { money: M7, bold: true, fillAll: VERDE }); r += 1;
const semNotas = Q.depois.map((x, i) => r2(x - Q.ger[i] - Q.composicao.filter(c => c[2] === 'nota').reduce((s, c) => s + c[1][i], 0)));
lin(rs, r, ['Diferença sem as notas explicativas', ...semNotas, tot(semNotas)], { money: M7, bold: true }); r += 1;
lin(rs, r, ['% sem as notas explicativas', ...semNotas.map((x, i) => x / Q.ger[i]), tot(semNotas) / tot(Q.ger)], { pct: M7, bold: true }); r += 2;
rs.getCell(r, 1).value = 'Detalhe por bloco (régua fornecedor a fornecedor e pessoa a pessoa)'; rs.getCell(r, 1).font = F({ bold: true, size: 11, color: { argb: NAVY } }); r += 1;
const blocoRes = (nome, f, alvo) => {
  const a = MESES.map(m => antes(f, m)), d = MESES.map(m => depois(f, m)), g = MESES.map(m => r2(alvo[m]));
  rs.getCell(r, 1).value = nome; rs.getCell(r, 1).font = F({ bold: true, size: 11, color: { argb: NAVY } }); r += 1;
  lin(rs, r, ['Gerencial (P&L / ERP)', ...g, tot(g)], { money: [1, 2, 3, 4, 5, 6, 7] }); r += 1;
  lin(rs, r, ['Contábil ANTES', ...a, tot(a)], { money: [1, 2, 3, 4, 5, 6, 7] }); r += 1;
  lin(rs, r, ['Diferença ANTES', ...a.map((x, i) => r2(x - g[i])), r2(tot(a) - tot(g))], { money: [1, 2, 3, 4, 5, 6, 7], fillAll: AMARELO }); r += 1;
  lin(rs, r, ['% ANTES', ...a.map((x, i) => g[i] ? (x - g[i]) / g[i] : 0), tot(g) ? (tot(a) - tot(g)) / tot(g) : 0], { pct: [1, 2, 3, 4, 5, 6, 7], fillAll: AMARELO }); r += 1;
  lin(rs, r, ['Contábil DEPOIS', ...d, tot(d)], { money: [1, 2, 3, 4, 5, 6, 7], bold: true }); r += 1;
  lin(rs, r, ['Diferença DEPOIS', ...d.map((x, i) => r2(x - g[i])), r2(tot(d) - tot(g))], { money: [1, 2, 3, 4, 5, 6, 7], fillAll: VERDE, bold: true }); r += 1;
  lin(rs, r, ['% DEPOIS', ...d.map((x, i) => g[i] ? (x - g[i]) / g[i] : 0), tot(g) ? (tot(d) - tot(g)) / tot(g) : 0], { pct: [1, 2, 3, 4, 5, 6, 7], fillAll: VERDE, bold: true }); r += 2;
};
blocoRes('CUSTO (COGS) — contas 6.2.1', fC, alvoCOGS);
blocoRes('DESPESA (OPEX) — contas 4.1', fO, alvoOPEX);
const semParMes = MESES.map(m => antes(fS, m));
rs.getCell(r, 1).value = 'Fora da comparação'; rs.getCell(r, 1).font = F({ bold: true, size: 11, color: { argb: NAVY } }); r += 1;
lin(rs, r, ['Razão sem par no gerencial (aba 7)', ...semParMes, r2(semParMes.reduce((a, b) => a + b, 0))], { money: [1, 2, 3, 4, 5, 6, 7], fillAll: CINZA }); r += 1;
const pendV = MESES.map(m => r2(soma(casos.flatMap(c => c.acoes.filter(a => a.mes === m && a.tipo === 'VERIFICAR')), a => -a.valor)));
lin(rs, r, ['A mais no razão sem prova (aba 6)', ...pendV, r2(pendV.reduce((a, b) => a + b, 0))], { money: [1, 2, 3, 4, 5, 6, 7], fillAll: CINZA }); r += 1;
const fe = MESES.map(m => r2(soma(foraEscopo.filter(x => x.mes === m), x => x.valor)));
lin(rs, r, ['P&L fora do razão de resultado (CAPEX, Stock Buyback, POCs)', ...fe, r2(fe.reduce((a, b) => a + b, 0))], { money: [1, 2, 3, 4, 5, 6, 7], fillAll: CINZA }); r += 2;
rs.getCell(r, 1).value = 'Quantidade de ajustes por tipo'; rs.getCell(r, 1).font = F({ bold: true, size: 11, color: { argb: NAVY } }); r += 1;
const qt = {}; casos.forEach(c => c.acoes.forEach(a => { qt[a.tipo] = qt[a.tipo] || { n: 0, v: 0 }; qt[a.tipo].n++; qt[a.tipo].v += Math.abs(a.valor); }));
Object.entries(qt).sort((a, b) => b[1].v - a[1].v).forEach(([t, o]) => { lin(rs, r, [t, o.n, r2(o.v)], { money: [2], fill: { 0: COR_TIPO[t] } }); r += 1; });

// ================= DRE CONSOLIDADO =================
const dc = wb.addWorksheet('DRE Consolidado');
dc.columns = [{ width: 14 }, { width: 40 }, ...MESES.flatMap(() => [{ width: 14 }, { width: 14 }]), { width: 15 }, { width: 15 }];
titulo(dc, 'DRE contábil consolidado — por conta, antes e depois dos ajustes', 'Cada conta é a soma das abas de mês. "Hoje" = razão como está. "Corrigido" = depois dos ajustes a lançar.', 16);
cab(dc, 4, ['Conta', 'Descrição', ...MESES.flatMap(m => [m + ' hoje', m + ' corrigido']), 'Total hoje', 'Total corrigido']);
const contas = [...new Set(TODAS.map(x => x.conta))].sort((a, b) => (ehCOGS(b) - ehCOGS(a)) || a.localeCompare(b));
r = 5;
let grupoAtual = '';
contas.forEach(ct => {
  const g = ehCOGS(ct) ? 'CUSTO (COGS)' : 'DESPESA (OPEX)';
  if (g !== grupoAtual) { dc.getCell(r, 1).value = g; dc.getCell(r, 1).font = F({ bold: true, color: { argb: NAVY } }); r += 1; grupoAtual = g; }
  const h = MESES.map(m => r2(soma(TODAS.filter(x => x.conta === ct && x.mes === m), x => x.esta)));
  const c = MESES.map(m => r2(soma(TODAS.filter(x => x.conta === ct && x.mes === m), x => x.deve)));
  const th = r2(h.reduce((a, b) => a + b, 0)), tc = r2(c.reduce((a, b) => a + b, 0));
  if (!th && !tc) return;
  lin(dc, r, [ct, nomeConta[ct] || '', ...MESES.flatMap((m, i) => [h[i], c[i]]), th, tc], { money: [...Array(14).keys()].map(i => i + 2), fill: Math.abs(th - tc) > 1 ? { 15: AMARELO } : {} }); r += 1;
});

// ================= ABAS DE MÊS =================
MESES.forEach(m => {
  const ws = wb.addWorksheet(m);
  ws.columns = [{ width: 13 }, { width: 30 }, { width: 44 }, { width: 15 }, { width: 15 }, { width: 14 }, { width: 90 }];
  titulo(ws, MESNOME[m] + '/2026 — conta por conta, fornecedor por fornecedor', 'Só aparecem os fornecedores com ajuste ou pendência. Os demais estão somados em "demais fornecedores sem ajuste". Cor = tipo de ajuste (ver LEIA-ME).', 7);
  cab(ws, 4, ['Conta', 'Descrição da conta', 'Fornecedor', 'Como está', 'Como deve ficar', 'Ajuste', 'O que fazer (e a prova)']);
  let l = 5;
  const doMes = TODAS.filter(x => x.mes === m);
  const cts = [...new Set(doMes.map(x => x.conta))].sort((a, b) => (ehCOGS(b) - ehCOGS(a)) || a.localeCompare(b));
  cts.forEach(ct => {
    const itens = doMes.filter(x => x.conta === ct);
    const e = r2(soma(itens, x => x.esta)), d = r2(soma(itens, x => x.deve));
    lin(ws, l, [ct, nomeConta[ct] || '', 'TOTAL DA CONTA', e, d, r2(d - e), ''], { money: [3, 4, 5], bold: true, fillAll: CINZA }); l += 1;
    const comAcao = itens.filter(x => Math.abs(x.ajuste) >= 0.5 || x.textos.length).sort((a, b) => Math.abs(b.ajuste) - Math.abs(a.ajuste) || Math.abs(b.esta) - Math.abs(a.esta));
    comAcao.forEach(x => {
      const cor = corDe(x.tipos);
      lin(ws, l, ['', '', x.entidade, x.esta, x.deve, x.ajuste, [...new Set(x.textos)].join('\n')], { money: [3, 4, 5], fill: cor ? { 5: cor, 6: cor } : {} });
      if (Math.abs(x.ajuste) >= 20000) ws.getCell(l, 6).font = F({ bold: true });
      ws.getRow(l).height = Math.min(120, 16 * Math.max(1, Math.ceil([...new Set(x.textos)].join(' ').length / 110)));
      l += 1;
    });
    const resto = itens.filter(x => !comAcao.includes(x));
    if (resto.length) { lin(ws, l, ['', '', 'demais fornecedores sem ajuste (' + resto.length + ')', r2(soma(resto, x => x.esta)), r2(soma(resto, x => x.deve)), 0, 'Bate com o gerencial ou não precisa de ajuste.'], { money: [3, 4, 5] }); ws.getCell(l, 3).font = F({ italic: true, color: { argb: MUTED } }); l += 1; }
  });
  const E = r2(soma(doMes, x => x.esta)), D = r2(soma(doMes, x => x.deve));
  lin(ws, l + 1, ['', '', 'TOTAL DO MÊS', E, D, r2(D - E), ''], { money: [3, 4, 5], bold: true, fillAll: VERDE });
});

// ================= ABAS DE AÇÃO =================
const acoes = [];
casos.forEach(c => c.acoes.forEach(a => acoes.push({ ...a, entidade: c.nome, bloco: c.bloco, contaPadrao: c.contaPadrao, contaUsada: contaDaAcao(c, a) })));
const lista = (nome, sub, cols, widths, rows, cor) => {
  const ws = wb.addWorksheet(nome);
  ws.columns = widths.map(w => ({ width: w }));
  titulo(ws, nome, sub, cols.length);
  cab(ws, 4, cols);
  rows.forEach((v, i) => { lin(ws, 5 + i, v.vals, { money: v.money, fill: cor ? { [v.money[0]]: cor } : {} }); ws.getRow(5 + i).height = Math.min(90, 16 * Math.max(1, Math.ceil(String(v.vals[v.vals.length - 1]).length / 100))); });
  if (rows.length) { const idx = rows[0].money[0]; lin(ws, 6 + rows.length, [...Array(idx).fill(''), r2(soma(rows, x => x.vals[idx])), ...Array(cols.length - idx - 1).fill('')].map((x, i) => i === 0 ? 'TOTAL (' + rows.length + ' linhas)' : x), { money: [idx], bold: true, fillAll: CINZA }); }
  return ws;
};
const ordM = (a, b) => MESES.indexOf(a.mes) - MESES.indexOf(b.mes);
const nfsDe = a => (a.lanc || []).map(l => l.nf).filter(Boolean).join(', ');

lista('1. Trocar de conta', 'O valor está certo, só está na conta errada. Tirar da conta "Sai de" e lançar na conta "Entra em", no mesmo mês.',
  ['Fornecedor', 'Mês', 'Valor', 'Sai de', 'Entra em', 'NF(s)', 'Por quê'], [44, 8, 15, 30, 30, 18, 70],
  acoes.filter(a => a.tipo === 'RECLASSIFICAR').sort((a, b) => a.entidade.localeCompare(b.entidade) || ordM(a, b)).map(a => ({ money: [2],
    vals: [a.entidade, a.mes, a.valor, a.conta + ' ' + (nomeConta[a.conta] || ''), a.contaPara + ' ' + (nomeConta[a.contaPara] || ''), nfsDe(a),
      (a.bloco === 'Folha PJ (por pessoa)' ? 'Pessoa da área ' + (casos.find(c => c.nome === a.entidade) || {}).area + ' no Cadastro. ' : 'No P&L este fornecedor é ' + ((casos.find(c => c.nome === a.entidade) || {}).sublinhas || []).join(', ') + '. ') + a.texto] })), AZUL);

lista('2. Excluir', 'Lançamentos em dobro e provisões que nunca foram revertidas. Excluir/estornar a linha indicada.',
  ['Fornecedor', 'Mês', 'Valor a tirar', 'Conta', 'Tipo', 'NF(s)', 'Por quê (prova)'], [40, 8, 15, 30, 20, 26, 80],
  acoes.filter(a => a.tipo === 'EXCLUIR DUPLICADO' || a.tipo === 'ESTORNAR PROVISÃO').sort((a, b) => a.valor - b.valor).map(a => ({ money: [2],
    vals: [a.entidade, a.mes, a.valor, a.contaUsada + ' ' + (nomeConta[a.contaUsada] || ''), a.tipo, nfsDe(a), a.texto] })), VERMELHO);

lista('3. Competência 2025', 'Despesas de dezembro/2025 que entraram como despesa de janeiro/2026. Tirar da despesa de 2026 e lançar contra a provisão de 2025.',
  ['Fornecedor / pessoa', 'Mês', 'Valor a tirar', 'Conta', 'NF(s)', 'Por quê (prova)'], [44, 8, 15, 30, 18, 90],
  acoes.filter(a => a.tipo === 'COMPETÊNCIA 2025').sort((a, b) => a.valor - b.valor).map(a => ({ money: [2],
    vals: [a.entidade, a.mes, a.valor, a.contaUsada + ' ' + (nomeConta[a.contaUsada] || ''), nfsDe(a), a.texto] })), LILAS);

lista('4. Provisões e baixas', 'Por fornecedor. Provisionar no mês da competência e baixar no mês em que a NF entrou. Sinal: + provisiona (aumenta a despesa do mês), − baixa (diminui).',
  ['Fornecedor', 'Mês', 'Valor', 'Conta', 'Tipo', 'NF(s)', 'Por quê (prova)'], [40, 8, 15, 30, 22, 22, 80],
  acoes.filter(a => ['PROVISIONAR', 'BAIXAR PROVISÃO', 'COMPLEMENTAR PROVISÃO', 'REDUZIR PROVISÃO', 'REVERTER (NF adiantada)'].includes(a.tipo)).sort((a, b) => a.entidade.localeCompare(b.entidade) || ordM(a, b))
    .map(a => ({ money: [2], vals: [a.entidade, a.mes, a.valor, a.contaUsada + ' ' + (nomeConta[a.contaUsada] || ''), a.tipo, nfsDe(a), a.texto] })), LARANJA);

lista('5. Falta lançar', 'Fornecedores do P&L sem nenhum lançamento no razão no semestre. Lançar a NF (ou provisionar) no mês indicado.',
  ['Fornecedor', 'Mês', 'Valor', 'Conta', 'Linha do P&L', 'Por quê'], [40, 8, 15, 30, 32, 70],
  acoes.filter(a => a.tipo === 'FALTA LANÇAR').sort((a, b) => a.entidade.localeCompare(b.entidade) || ordM(a, b))
    .map(a => ({ money: [2], vals: [a.entidade, a.mes, a.valor, a.contaUsada + ' ' + (nomeConta[a.contaUsada] || ''), ((casos.find(c => c.nome === a.entidade) || {}).sublinhas || []).join(', '), a.texto] })), AMARELO);

lista('6. Pedir NF', 'NÃO LANÇAR. O razão tem mais do que o gerencial e não há duplicidade, provisão sem baixa nem NF de outro mês que explique. A Jusfy envia a NF / o detalhe antes de qualquer ajuste.',
  ['Fornecedor / pessoa', 'Mês', 'A mais no razão', 'Conta', 'Bloco', 'O que falta saber'], [40, 8, 15, 30, 22, 80],
  acoes.filter(a => a.tipo === 'VERIFICAR' || /^NOTA/.test(a.tipo)).sort((a, b) => a.valor - b.valor)
    .map(a => ({ money: [2], vals: [a.entidade, a.mes, -a.valor, a.contaUsada + ' ' + (nomeConta[a.contaUsada] || ''), a.bloco, a.texto] })), CINZA);

lista('7. Sem par no gerencial', 'Fornecedores do razão que não aparecem no P&L gerencial nem no Cadastro/ERP. A Controladoria classifica (em qual linha do P&L ficam) antes de ajustar. Os que estão em conta de passagem e aparecem em outra conta nos outros meses já estão na aba 1.',
  ['Fornecedor (razão)', 'Total Jan-Jun', ...MESES, 'Contas onde está'], [46, 15, ...MESES.map(() => 13), 50],
  semParCasos.filter(s => Math.abs(s.total) >= 1).sort((a, b) => Math.abs(b.total) - Math.abs(a.total)).map(s => ({ money: [1, 2, 3, 4, 5, 6, 7],
    vals: [s.fornecedor, s.total, ...MESES.map(m => s.razMes[m]), s.contas.map(c => c + ' ' + (nomeConta[c] || '')).join(' | ')] })), CINZA);

// Folha por pessoa
const fp = wb.addWorksheet('8. Folha por pessoa');
fp.columns = [{ width: 36 }, { width: 18 }, { width: 14 }, ...MESES.flatMap(() => [{ width: 12 }, { width: 12 }]), { width: 14 }, { width: 50 }];
titulo(fp, 'Folha PJ — razão × Realizado ERP, pessoa por pessoa', 'Régua = Realizado ERP (salário + bônus + comissão) + distrato da base de distratos. Conta certa pela área do Cadastro. Vínculos de PJ com nome de empresa diferente foram provados por valor idêntico ao ERP.', 18);
cab(fp, 4, ['Pessoa', 'Área', 'Conta certa', ...MESES.flatMap(m => [m + ' razão', m + ' ERP']), 'Dif. total', 'Vínculo / observação']);
r = 5;
casos.filter(c => c.bloco === 'Folha PJ (por pessoa)').sort((a, b) => a.nome.localeCompare(b.nome)).forEach(c => {
  const dif = r2(soma(MESES, m => c.razMes[m] - c.alvoMes[m]));
  lin(fp, r, [c.nome, c.area, c.contaPadrao, ...MESES.flatMap(m => [r2(c.razMes[m]), r2(c.alvoMes[m])]), dif, c.vinculo || ''], { money: [...Array(13).keys()].map(i => i + 3), fill: Math.abs(dif) > 50 ? { 15: AMARELO } : {} });
  r += 1;
});

// Status v2 não aplicado
const v2 = require('./v2_nao_aplicado.json');
lista('9. v2 marcado OK e não feito', 'Itens da v2 que a Syhus marcou como "Ok, ajustado", mas que no razão atual continuam na conta antiga. Os valores são do razão de hoje.',
  ['Fornecedor', 'Mês', 'Valor ainda na conta antiga', 'Conta antiga', 'Conta pedida na v2'], [44, 8, 18, 22, 22],
  v2.filter(x => !/^BRASIL SERVICOS/.test(x[0])).map(x => ({ money: [2], vals: [x[0], x[1], x[5], x[2] + ' ' + (nomeConta[x[2]] || ''), x[4] + ' ' + (nomeConta[x[4]] || '')] })), AZUL);

// Regras
const rg = wb.addWorksheet('Regras do processo');
rg.columns = [{ width: 34 }, { width: 110 }];
titulo(rg, 'Regras usadas (as mesmas todo mês)', 'O processo é rodado pelos scripts parse_razao → normalizar → casar → folha → analisar → gerar. Abaixo, o que cada regra faz.', 2);
r = 4;
[['Leitura do razão', 'Bloco por conta; Débito na coluna I, Crédito na J. Exclui "Encerramento do exercício / zeramento". Confere cada conta contra o "Total do mês" do próprio arquivo.'],
 ['Fornecedor da linha', '"nota fiscal nº X do fornecedor NOME"; senão a contrapartida "NNN - NOME" (quando não é banco/cartão/provisão); senão os formatos de cartão e boleto ("PAGAMENTO NOME NF…", "PARC a/b NOME", "Débito em Conta Corrente NOME").'],
 ['Tipo da linha', 'PROVISÃO = contrapartida 930; REVERSÃO = "Reversão prov."; ESTORNO; CARTÃO; BANCO; NF.'],
 ['Casamento com o P&L', 'Por nome (palavras significativas, pelo menos metade batendo). Plataformas de mídia por conta (Google 4.1.3.01.002, Facebook .003, TikTok .004, Microsoft .006, Reddit .007, LinkedIn .008). Linhas agregadas do P&L (Hotels, Taxi, Supplies…) pela conta. De-paras confirmados: Treble = Messaging & Live Chat; Capi Candia = Rafael Candia; Timework = Timework + WeWork; Microsoft do Brasil = Microsoft Ads; GCP = Google Cloud; CDL = Sede Nova.'],
 ['Conta certa', 'Sublinha do P&L → conta pela árvore oficial do DRE. Folha: Engenharia/Produto = 6.2.1.01.001; demais áreas = 4.1.6.01.007.'],
 ['Competência da NF', 'Atribuição ótima NF × mês: cada NF vai para o mês do gerencial (ou do ERP, na folha) de valor idêntico (até R$ 2 de arredondamento), com até 4 meses de atraso ou 1 de adiantamento; valor só aproximado (±0,5%) vale apenas no próprio mês. Folha: dez/2025 e jul/2026 do ERP também são meses possíveis. Sem valor idêntico: a reversão que cita a NF. Senão o mês do lançamento.'],
 ['Data de 2025 no histórico', 'Linha de 2026 com data de 2025 (baixa de adiantamento, estorno de NF de 2025, ajuste de exercício anterior): sai de 2026 quando o gerencial do mês não tem esse valor. Fornecedor sem par no P&L: sai sempre.'],
 ['NF repetida', 'Duas NFs do mesmo valor no mesmo mês e o gerencial/ERP com uma só: a de número maior é excluída; em jan (ou fornecedor que fatura com atraso) a de número menor é de 2025. Pagamento (cartão/banco) que cita o número de uma NF já lançada = despesa em dobro.'],
 ['Distrato', 'Mês do P&L (painel People, Contract Termination) quando a soma do mês só fecha com a troca (Arthur jan→fev; Vitor mai→jun).'],
 ['Duplicidade', 'Mesma NF duas vezes; mesmo valor por NF e por cartão no mesmo mês; NF formal igual à soma de 1 a 3 cobranças já lançadas (padrão Treble); baixa de adiantamento lançada como despesa junto com a NF.'],
 ['Provisão sem baixa', 'Provisão (930) sem reversão do mesmo valor depois dela.'],
 ['Competência 2025', 'NF ou bônus de valor idêntico ao de dez/2025 no ERP (quando em 2026 o valor é outro); NF de valor pago em 2025; em jan, NF que não é de nenhum mês de 2026 (±1%).'],
 ['Tolerância', 'R$ 50 por fornecedor/mês (arredondamento). Acima disso vira ajuste ou pendência.'],
 ['O que NÃO é ajustado', 'Diferença sem prova (aba 6), fornecedor sem par (aba 7), diferença estrutural conhecida (Pagar.me). Viram pendência ou nota — nunca número forçado.']]
  .forEach(p => { lin(rg, r, p); rg.getCell(r, 1).font = F({ bold: true }); rg.getRow(r).height = 34; r += 1; });

require('./aba_prioridade.js')({ wb, titulo, cab, lin, F, fill, r2, COR: { NAVY, INK, MUTED, LINE, CINZA, VERDE, AMARELO, LARANJA, VERMELHO, AZUL, LILAS }, MONEY, nomeConta });
require('./abas_v4.js')({ wb, casos, semParCasos, L, RG, MESES, nomeConta, titulo, cab, lin, F, fill, r2, soma, COR: { NAVY, INK, MUTED, LINE, CINZA, VERDE, AMARELO, LARANJA, VERMELHO, AZUL, LILAS }, MONEY });
// ordem das abas: LEIA-ME, Resumo, DRE, meses, ações
const ordem = ['LEIA-ME', '0. FAZER PRIMEIRO', 'Resumo', 'DRE Consolidado', ...MESES, '1. Trocar de conta', '2. Excluir', '3. Competência 2025', '4. Provisões e baixas', '5. Falta lançar', '6. Pedir NF', '7. Sem par no gerencial', '8. Folha por pessoa', '9. v2 marcado OK e não feito', 'Razão linha a linha', 'Sem par × ERP', 'Notas explicativas', 'Regras do processo'];
wb._worksheets = [undefined, ...ordem.map(n => wb.getWorksheet(n))].map((w, i) => { if (w) w.orderNo = i; return w; });

const out = path.join(__dirname, 'Jusfy - DRE Contabil Jan-Jun 2026 - Ajustes para Syhus - v6.xlsx');
wb.xlsx.writeFile(out).then(() => {
  console.log('OK', out);
  const t = (f, g) => r2(soma(TODAS.filter(f), g));
  ['C', 'O'].forEach(k => {
    const f = k === 'C' ? fC : fO, alvo = k === 'C' ? alvoCOGS : alvoOPEX;
    const G = r2(soma(MESES, m => alvo[m])), A = t(f, x => x.esta), D = t(f, x => x.deve);
    console.log(k === 'C' ? 'COGS' : 'OPEX', '| ger', G.toLocaleString('pt-BR'), '| antes', A.toLocaleString('pt-BR'), ((A - G) / G * 100).toFixed(2) + '%', '| depois', D.toLocaleString('pt-BR'), ((D - G) / G * 100).toFixed(2) + '%');
  });
});
