// Régua por mês e por grupo (C = custo 6.2, O = despesa 4.1): gerencial, razão hoje e notas aceitas
// (diferenças explicadas que não se fecham com lançamento). Tudo vem dos dados — nada estimado.
const RG = require('./regras.js');
const L = require('./lancamentos.json');
const A = require('./achados.json');
const G0 = require('../extracted/dados/gerencial_fornecedor.json');
const D = require('../extracted/dados/payroll_area_dashboard.json');

const M = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'], m3 = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun'];
const r2 = x => Math.round(x * 100) / 100;
const zero = () => M.map(() => 0);
const grupoConta = c => (/^6\.2\./.test(c) ? 'C' : /^4\.1\./.test(c) ? 'O' : null);
const fora = r => RG.FORA_ESCOPO_SUBLINHA.has(r.sublinha) || RG.FORA_ESCOPO_FORNECEDOR.has(r.fornecedor.trim());
const dre = c => /^(4\.1|6\.2)/.test(c) && !RG.CONTAS_NAO_OPERACIONAIS.test(c);
const grupoSublinha = s => {
  if (s === 'Digital Advertising') return 'O'; // mídia: contas 4.1.3.x por plataforma
  const cs = RG.CONTAS_DA_SUBLINHA[s];
  if (!cs) throw new Error('sublinha sem conta no mapa: ' + s);
  return grupoConta(cs[0]);
};
const AREA_CUSTO = 'Engineering & Technology'; // P&L: "Engineering & Technology Payroll" é custo; o resto da folha é despesa

const ger = { C: zero(), O: zero() };
G0.filter(g => !fora(g)).forEach(g => { ger[grupoSublinha(g.sublinha)][M.indexOf(g.mes)] += g.valor; });
const painelG = { C: zero(), O: zero() };
Object.keys(D.SALARIES).forEach(area => m3.forEach((m, i) => {
  const v = ['SALARIES', 'BONUSES', 'BENEFITS'].reduce((s, c) => s + (((D[c][area] || {}).monthly || {})[m] || 0), 0);
  painelG[area === AREA_CUSTO ? 'C' : 'O'][i] += v;
}));
['C', 'O'].forEach(k => M.forEach((m, i) => { ger[k][i] = r2(ger[k][i] + painelG[k][i]); }));
// RH que não é folha (auxílio educacional, integrações...): está na linha "HR Expenses & Payroll" do P&L oficial, mas não
// no painel de pessoas nem no P&L por fornecedor. Entra pelo valor oficial: linha de RH − painel das áreas de despesa.
const PL = require('../extracted/dados/dre_comparativo.json').gerencial;
const rhNaoFolha = M.map((m, i) => r2(PL.opexLinhas['HR Expenses & Payroll'][i] - painelG.O[i]));
M.forEach((m, i) => { ger.O[i] = r2(ger.O[i] + rhNaoFolha[i]); });

const raz = L.filter(l => dre(l.conta) && !RG.naoOperacional(l));
const antes = { C: zero(), O: zero() };
raz.forEach(l => { antes[grupoConta(l.conta)][M.indexOf(l.mes)] += l.valor; });
['C', 'O'].forEach(k => { antes[k] = antes[k].map(r2); });

const contaDaAcao = (c, a) => (a.tipo === 'RECLASSIFICAR' ? a.conta : (c.permitidas || []).includes(a.conta) ? a.conta : c.contaPadrao);

// Notas aceitas (não viram lançamento): competência 2025 (exercício encerrado), taxa Pagar.me (P&L tem a taxa cheia),
// folha (diferença entre o painel People e o Realizado por pessoa, já reconciliada pessoa a pessoa).
const nota = { comp2025: { C: zero(), O: zero() }, pagarme: { C: zero(), O: zero() }, folha: { C: zero(), O: zero() } };
A.casos.forEach(c => c.acoes.forEach(a => {
  const k = a.tipo === 'COMPETÊNCIA 2025' ? 'comp2025' : /^NOTA/.test(a.tipo) ? 'pagarme' : null;
  if (!k) return;
  const g = grupoConta(contaDaAcao(c, a));
  if (g) nota[k][g][M.indexOf(a.mes)] -= a.valor;
}));
const alvoFolha = { C: zero(), O: zero() };
A.casos.filter(c => /^Folha/.test(c.bloco)).forEach(c => { const g = grupoConta(c.contaPadrao); M.forEach((m, i) => { const d = (c.alvoDistrato || {})[m] || 0; alvoFolha[g][i] += (c.alvoMes[m] || 0) - d; alvoFolha.O[i] += d; }); });
['C', 'O'].forEach(k => M.forEach((m, i) => { nota.folha[k][i] = r2(alvoFolha[k][i] - painelG[k][i]); }));
Object.values(nota).forEach(n => ['C', 'O'].forEach(k => { n[k] = n[k].map(r2); }));
// Nota explicativa é SÓ a competência 2025 (exercício encerrado). Folha e Pagar.me não são nota: ou têm lançamento, ou ficam
// como diferença a explicar dentro da meta.
const notasG = { C: nota.comp2025.C.slice(), O: nota.comp2025.O.slice() };

// Pendências da Jusfy (não são nota explicativa e não viram lançamento da Syhus sem resposta da Jusfy): cada uma com dono e valor.
//  verif: razão maior que o P&L no fornecedor/mês, sem prova de qual NF sobra;
//  semPar: fornecedor do razão fora do P&L (menos os que já estão no P&L pela linha de RH — auxílio educacional);
//  agregadas: linha agregada do P&L (Hotels, Taxi…) com diferença e sem fornecedor provado no razão;
//  folha: painel de pessoas × cadastro/ERP (área custo/despesa e distratos de junho fora do painel).
const { explodir } = require('./explode_fornecedor.js');
const SEMPAR = require('./sempar_classif.json');
const LANC = a => !a.semLancar && a.tipo !== 'VERIFICAR' && !/^NOTA/.test(a.tipo) && a.tipo !== 'COMPETÊNCIA 2025';
const pend = { verif: { C: zero(), O: zero() }, semPar: { C: zero(), O: zero() }, agregadas: { C: zero(), O: zero() }, folha: nota.folha };
A.casos.forEach(c => {
  c.acoes.filter(a => a.tipo === 'VERIFICAR').forEach(a => { const g = grupoConta(contaDaAcao(c, a)); if (g) pend.verif[g][M.indexOf(a.mes)] -= a.valor; });
  const brutas = c.acoes.filter(LANC).map(a => ({ ...a, entidade: c.nome, contaUsada: contaDaAcao(c, a) }));
  explodir(c.bloco, brutas).semFornecedor.forEach(a => {
    const i = M.indexOf(a.mes);
    if (a.tipo === 'RECLASSIFICAR') { const de = grupoConta(a.conta), para = grupoConta(a.contaPara); if (de) pend.agregadas[de][i] -= a.valor; if (para) pend.agregadas[para][i] += a.valor; return; }
    const g = grupoConta(a.contaUsada); if (g) pend.agregadas[g][i] += a.valor;
  });
});
// sinal: pendência = quanto o razão fica acima do P&L por causa dela (agregadas é o ajuste que faltaria, então entra com sinal trocado)
['C', 'O'].forEach(g => { pend.agregadas[g] = pend.agregadas[g].map(v => -v); });
SEMPAR.filter(s => !/^Está no P&L/.test(s.categoria)).forEach(s => { const g = grupoConta(s.conta); if (g) pend.semPar[g][M.indexOf(s.mes)] += s.valor; });
Object.values(pend).forEach(p => ['C', 'O'].forEach(g => { p[g] = p[g].map(r2); }));
const pendG = { C: M.map((m, i) => r2(Object.values(pend).reduce((s, p) => s + p.C[i], 0))), O: M.map((m, i) => r2(Object.values(pend).reduce((s, p) => s + p.O[i], 0))) };

module.exports = { M, r2, grupoConta, contaDaAcao, ger, antes, nota, notasG, painelG, pend, pendG, rhNaoFolha };

if (require.main === module) {
  const f = x => String(Math.round(x)).padStart(11);
  for (const k of ['C', 'O']) {
    console.log(k === 'C' ? 'CUSTO' : 'DESPESA');
    console.log('  gerencial   ', ger[k].map(f).join(''));
    console.log('  razão hoje  ', antes[k].map(f).join(''));
    console.log('  nota 2025   ', nota.comp2025[k].map(f).join(''));
    console.log('  nota Pagarme', nota.pagarme[k].map(f).join(''));
    console.log('  nota folha  ', nota.folha[k].map(f).join(''));
    console.log('  gap - notas ', M.map((m, i) => f(antes[k][i] - ger[k][i] - notasG[k][i])).join(''));
  }
}
