// Passo 5: aplica as regras de achado a cada fornecedor e pessoa. Tudo sai de lançamento real ou do gerencial.
const fs = require('fs');
const path = require('path');
const RG = require('./regras.js');
const { grupos, rubricas, semPar, foraEscopo } = require('./grupos.json');
const { pessoas, naoPessoaFolha } = require('./folha.json');
const ERP = require('../extracted/dados/real_erp.json');
// equipamento sai das linhas agregadas antes do cálculo (no gerencial é CAPEX)
const RE_EQUIP = /^(DELL|LG ELECTRONICS|KABUM|CHYPPS|STARK|ALIEXPRESS|COMFY|EMESUL|EBAZAR|PILOTO|BRAULIO KISNER)/;
const equipDasRubricas = [];
rubricas.forEach(r => { r.lancamentos = r.lancamentos.filter(l => { if (RE_EQUIP.test(l.chave)) { equipDasRubricas.push(l); return false; } return true; }); });

const MESES = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'];
const TOL = RG.TOLERANCIA;
const r2 = x => Math.round(x * 100) / 100;
const soma = (arr, f) => arr.reduce((s, x) => s + f(x), 0);
const competencia = h => { const m = String(h).match(/compet[eê]ncia\s*-?\s*(\d{2})\/(\d{4})/i); return m ? { mes: MESES[+m[1] - 1], ano: +m[2] } : null; };
const idL = l => l.mes + '|' + l.conta + '|' + l.valor + '|' + l.historico;

const data2025 = l => (String(l.historico).match(/\d{2}\/\d{2}\/2025/) || ['exercício anterior'])[0];
// ---------- detectores ----------
function provisoesSemBaixa(lanc) {
  const prov = lanc.filter(l => l.tipo === 'PROVISAO' && l.valor > 0);
  const rev = lanc.filter(l => (l.tipo === 'REVERSAO' || l.tipo === 'ESTORNO') && l.valor < 0);
  const usados = new Set();
  const out = [];
  for (const p of prov) {
    const i = rev.findIndex((r, k) => !usados.has(k) && Math.abs(Math.abs(r.valor) - p.valor) <= 1 && MESES.indexOf(r.mes) >= MESES.indexOf(p.mes));
    if (i >= 0) { usados.add(i); continue; }
    // NF real do mesmo valor lançada depois (ou no mesmo mês) sem estornar a provisão
    const nf = lanc.find(l => l !== p && l.tipo !== 'PROVISAO' && l.valor > 0 && Math.abs(l.valor - p.valor) <= 1 && MESES.indexOf(l.mes) >= MESES.indexOf(p.mes));
    out.push({ l: p, nf });
  }
  return out;
}

function duplicidades(lanc) {
  // mesmo valor, positivo, mesma conta, lançado 2x no mesmo mês por origens diferentes (NF + cartão/banco) ou mesma NF repetida
  const out = [];
  const pos = lanc.filter(l => l.valor > 0 && l.tipo !== 'PROVISAO' && !l._dup);
  const vistos = new Set();
  for (let i = 0; i < pos.length; i++) for (let j = i + 1; j < pos.length; j++) {
    const a = pos[i], b = pos[j];
    if (vistos.has(j) || vistos.has(i)) continue;
    const bancoNF = (a.tipo === 'BANCO' && b.tipo === 'NF') || (a.tipo === 'NF' && b.tipo === 'BANCO');
    if (a.mes !== b.mes || (a.conta !== b.conta && !bancoNF) || Math.abs(a.valor - b.valor) > 1 || a.valor < 100) continue;
    const parc = x => (String(x.historico).match(/PARC\s*(\d+)\s*\/\s*(\d+)/i) || String(x.historico).match(/-\s*(\d{3})\/(\d{3})\s*-/) || []).slice(1).join('/');
    if (parc(a) && parc(b) && parc(a) !== parc(b)) continue;
    const nfOk = x => x.nf && !/^FATURA$/i.test(x.nf);
    const mesmaNF = nfOk(a) && nfOk(b) && a.nf === b.nf;
    const origens = a.tipo !== b.tipo;
    if (mesmaNF || origens) {
      // não é duplicidade se houver estorno/reversão do mesmo valor no mesmo mês ou no seguinte
      const anulado = lanc.some(l => l.valor < 0 && Math.abs(Math.abs(l.valor) - a.valor) <= 1 && MESES.indexOf(l.mes) - MESES.indexOf(a.mes) <= 1 && MESES.indexOf(l.mes) >= MESES.indexOf(a.mes));
      if (!anulado) { const [manter, excluir] = a.tipo !== 'NF' && b.tipo === 'NF' ? [b, a] : [a, b]; excluir._dup = true;
        const oque = excluir.tipo === 'CARTAO' ? 'pagamento no cartão' : excluir.tipo === 'BANCO' ? 'pagamento pelo banco' : /Adiantamento/i.test(excluir.contrapartida) ? 'baixa de adiantamento' : excluir.tipo.toLowerCase();
        out.push({ manter, excluir, motivo: mesmaNF ? 'mesma NF ' + a.nf + ' lançada duas vezes' : 'a NF' + (manter.nf ? ' ' + manter.nf : '') + ' já está lançada e o ' + oque + ' do mesmo valor também foi lançado como despesa' }); vistos.add(pos.indexOf(excluir)); }
    }
  }
  return out;
}

// atribuição ótima (húngaro): linhas = NFs, colunas = vagas (mês do gerencial ou componente do ERP)
function hungaro(C) { // C: n x m (n <= m), devolve col de cada linha
  const n = C.length, m = C[0].length, INF = 1e15;
  const u = new Array(n + 1).fill(0), v = new Array(m + 1).fill(0), p = new Array(m + 1).fill(0), way = new Array(m + 1).fill(0);
  for (let i = 1; i <= n; i++) {
    p[0] = i; let j0 = 0; const minv = new Array(m + 1).fill(INF), used = new Array(m + 1).fill(false);
    do { used[j0] = true; const i0 = p[j0]; let d = INF, j1 = 0;
      for (let j = 1; j <= m; j++) if (!used[j]) { const cur = C[i0 - 1][j - 1] - u[i0] - v[j]; if (cur < minv[j]) { minv[j] = cur; way[j] = j0; } if (minv[j] < d) { d = minv[j]; j1 = j; } }
      for (let j = 0; j <= m; j++) if (used[j]) { u[p[j]] += d; v[j] -= d; } else minv[j] -= d;
      j0 = j1; } while (p[j0] !== 0);
    do { const j1 = way[j0]; p[j0] = p[j1]; j0 = j1; } while (j0);
  }
  const res = new Array(n).fill(-1); for (let j = 1; j <= m; j++) if (p[j]) res[p[j] - 1] = j - 1; return res;
}
function vagas(ent) {
  const out = [];
  MESES.forEach(m => { if (ent.alvoMes[m] > 0) out.push({ m, v: ent.alvoMes[m], rot: 'gerencial de ' + m }); });
  (ent.comp || []).forEach(c => { if (!out.some(o => o.m === c.m && Math.abs(o.v - c.v) <= 1)) out.push(c); });
  return out;
}

function textoData2025(l) {
  const d = data2025(l);
  if (/Adiantamento/i.test(l.contrapartida)) return 'Baixa de adiantamento de ' + d + ' (compra de 2025) lançada como despesa em ' + l.mes + '/2026. A despesa é de 2025: baixar o adiantamento contra o resultado de 2025 (ajuste de exercício anterior), não contra despesa de 2026.';
  if (l.valor < 0) return 'Estorno/cancelamento de NF de ' + d + ' (2025) lançado em ' + l.mes + '/2026, reduzindo a despesa de 2026. É de 2025: lançar contra o resultado de 2025, não contra a despesa de 2026.';
  if (/exerc/i.test(d)) return 'Ajuste de exercício anterior lançado em despesa de ' + l.mes + '/2026. Não é despesa de 2026: lançar contra lucros/prejuízos acumulados.';
  return 'NF de ' + d + ' (2025) lançada em ' + l.mes + '/2026. É competência 2025: sai da despesa de 2026 (contra a provisão de 2025).';
}

// ---------- monta um "caso" por fornecedor/pessoa/rubrica ----------
function montar(ent) {
  const { lancamentos: lanc, alvoMes, permitidas, contaPadrao } = ent;
  const razMes = {}; MESES.forEach(m => { razMes[m] = r2(soma(lanc.filter(l => l.mes === m), l => l.valor)); });
  const acoes = []; // {tipo, mes, conta, contaPara, valor, texto, lanc}
  // 1) conta errada
  if (permitidas && permitidas.length) {
    const errados = lanc.filter(l => !permitidas.includes(l.conta));
    const porMesConta = {};
    errados.forEach(l => { const k = l.mes + '|' + l.conta; (porMesConta[k] = porMesConta[k] || []).push(l); });
    Object.entries(porMesConta).forEach(([k, ls]) => {
      const [mes, conta] = k.split('|');
      const v = r2(soma(ls, l => l.valor));
      if (Math.abs(v) < 1) return;
      const passagem = RG.CONTAS_PASSAGEM[conta];
      acoes.push({ tipo: 'RECLASSIFICAR', mes, conta, contaPara: contaPadrao, valor: v, lanc: ls,
        texto: 'Está na conta ' + conta + (passagem ? ' (' + passagem + ', conta de passagem)' : '') + '. Mover para ' + contaPadrao + '.' });
    });
  }
  // 2) provisão sem baixa
  provisoesSemBaixa(lanc).forEach(({ l, nf }) => acoes.push({ tipo: 'ESTORNAR PROVISÃO', mes: nf ? nf.mes : l.mes, conta: l.conta, valor: -l.valor, lanc: [l],
    texto: 'Provisão de ' + l.mes + ' (R$ ' + l.valor.toLocaleString('pt-BR') + ') nunca foi revertida' + (nf ? ' e a NF' + (nf.nf ? ' ' + nf.nf : '') + ' do mesmo valor entrou em ' + nf.mes + '. Estornar a provisão em ' + nf.mes + '.' : '. Reverter quando a NF entrar.'), provisaoSemNF: !nf }));
  // 0) ajustes confirmados pela Controladoria
  (RG.CONFIRMADOS || []).forEach(cf => {
    const l = lanc.find(x => cf.re.test(x.chave) && x.mes === cf.mes && Math.abs(Math.abs(x.valor) - cf.valorLinha) <= 1 && !x._conf);
    if (!l) return;
    l._conf = true; if (cf.tipo === 'EXCLUIR DUPLICADO') l._dup = true;
    acoes.push({ tipo: cf.tipo, mes: cf.mes, conta: l.conta, valor: cf.valor, lanc: [l], texto: cf.texto });
  });
  // 3b) duplicidade composta (padrão Treble: NF formal repete faturas já pagas no cartão)
  {
    const rev = lanc.filter(l => l.valor < 0 && l.tipo === 'ESTORNO');
    const revertido = x => rev.some(r => Math.abs(Math.abs(r.valor) - x.valor) <= 1 && String(r.historico).includes(x.nf || '§§'));
    const cobr = lanc.filter(l => l.valor >= 1000 && l.tipo !== 'PROVISAO' && l.tipo !== 'NF');
    const formais = lanc.filter(l => l.tipo === 'NF' && l.nf && l.valor >= 1000);
    const usados = new Set();
    for (const f of formais) {
      const antes = cobr.filter(c => !usados.has(c) && MESES.indexOf(c.mes) <= MESES.indexOf(f.mes) && !revertido(c));
      let achou = null;
      for (let i = 0; i < antes.length && !achou; i++) {
        if (Math.abs(antes[i].valor - f.valor) <= 1) { achou = [antes[i]]; break; }
        for (let j = i + 1; j < antes.length && !achou; j++) {
          if (Math.abs(antes[i].valor + antes[j].valor - f.valor) <= 1) { achou = [antes[i], antes[j]]; break; }
          for (let k = j + 1; k < antes.length; k++) if (Math.abs(antes[i].valor + antes[j].valor + antes[k].valor - f.valor) <= 1) { achou = [antes[i], antes[j], antes[k]]; break; }
        }
      }
      if (achou && ent.comp) continue;
      if (achou && achou.length === 1 && /Adiantamento/i.test(achou[0].contrapartida) && formais.filter(x => Math.abs(x.valor - f.valor) <= 1).length > 1) continue;
      if (achou && achou.length === 1 && /Adiantamento/i.test(achou[0].contrapartida)) {
        const ad = achou[0]; usados.add(ad); ad._dup = true;
        acoes.push({ tipo: 'EXCLUIR DUPLICADO', mes: ad.mes, conta: ad.conta, valor: -ad.valor, lanc: [ad, f],
          texto: 'Baixa de adiantamento (R$ ' + ad.valor.toLocaleString('pt-BR') + ') foi lançada como despesa em ' + ad.mes + ', e a NF ' + f.nf + ' do mesmo valor também. O adiantamento deve ser baixado contra o fornecedor (NF ' + f.nf + '), não contra despesa: excluir a linha do adiantamento.' });
        continue;
      }
      if (achou) {
        achou.forEach(c => usados.add(c)); f._dup = true;
        acoes.push({ tipo: 'EXCLUIR DUPLICADO', mes: f.mes, conta: f.conta, valor: -f.valor, lanc: [f, ...achou],
          texto: 'NF ' + f.nf + ' (' + 'R$ ' + f.valor.toLocaleString('pt-BR') + ') lançada em ' + f.mes + ' repete ' + (achou.length > 1 ? 'a soma de ' + achou.length + ' cobranças' : 'uma cobrança') + ' já lançadas: ' +
            achou.map(c => c.mes + ' R$ ' + c.valor.toLocaleString('pt-BR') + (c.nf ? ' (' + c.nf + ')' : '')).join(' + ') + '. Excluir a NF ' + f.nf + '.' });
      }
    }
  }
  // 3) duplicidade
  duplicidades(lanc).forEach(d => acoes.push({ tipo: 'EXCLUIR DUPLICADO', mes: d.excluir.mes, conta: d.excluir.conta, valor: -d.excluir.valor, lanc: [d.excluir],
    texto: 'Mesmo valor (R$ ' + d.excluir.valor.toLocaleString('pt-BR') + ') lançado duas vezes em ' + d.excluir.mes + ': ' + d.motivo + '. Excluir ' + (d.excluir.tipo === 'NF' ? 'a repetida' : 'o ' + (d.excluir.tipo === 'CARTAO' ? 'lançamento do cartão' : d.excluir.tipo === 'BANCO' ? 'lançamento do banco' : 'lançamento sem NF')) + '.' }));
  // 3c) pagamento (cartão/banco) que cita o número de uma NF já lançada deste fornecedor = a despesa entrou duas vezes
  {
    const nfsN = lanc.filter(l => l.tipo === 'NF' && l.nf && /^\d{3,}$/.test(l.nf) && !l._dup);
    lanc.filter(l => (l.tipo === 'CARTAO' || l.tipo === 'BANCO') && l.valor > 0 && !l._dup).forEach(p => {
      const nf = nfsN.find(n => new RegExp('\\b' + n.nf + '\\b').test(String(p.historico)) && Math.abs(n.valor - p.valor) <= Math.max(1, 0.01 * n.valor));
      if (!nf) return; p._dup = true;
      acoes.push({ tipo: 'EXCLUIR DUPLICADO', mes: p.mes, conta: p.conta, valor: -p.valor, lanc: [p, nf], texto: 'O pagamento de ' + p.mes + ' (' + (p.tipo === 'CARTAO' ? 'cartão' : 'banco') + ', R$ ' + p.valor.toLocaleString('pt-BR') + ') cita a NF ' + nf.nf + ', que já está lançada como despesa em ' + nf.mes + '. Pagamento não é despesa: excluir a linha do pagamento (baixar contra fornecedores).' });
    });
  }
  // 4) competência 2025 (folha): excesso de jan igual ao bônus/salário de dez/2025 no ERP
  if (ent.dez2025 && !ent.comp) {
    const exc = razMes.Jan - alvoMes.Jan;
    const cands = [ent.dez2025.bonus, ent.dez2025.salario, ent.dez2025.bonus + ent.dez2025.salario].filter(x => x > 0);
    const hit = cands.find(c => Math.abs(exc - c) <= 1);
    if (exc > TOL && hit) acoes.push({ tipo: 'COMPETÊNCIA 2025', mes: 'Jan', conta: ent.contaPadrao, valor: -r2(hit), lanc: [],
      texto: 'R$ ' + r2(hit).toLocaleString('pt-BR') + ' em jan/2026 = valor de dez/2025 no ERP (bônus/salário de dezembro). É competência 2025: sai da despesa de 2026 (contra provisão de 2025).' });
  }
  if (ent.jan2025) {
    const exc = r2(razMes.Jan - alvoMes.Jan);
    const ls = lanc.filter(l => l.mes === 'Jan' && l.valor >= 1000).sort((a, b) => b.valor - a.valor);
    if (exc > TOL) acoes.push({ tipo: 'COMPETÊNCIA 2025', mes: 'Jan', conta: ls[0] ? ls[0].conta : ent.contaPadrao, valor: -exc, lanc: ls, texto: ent.jan2025 });
  }
  // 5) o que sobra, mês a mês, depois das ações acima
  const efeito = {}; MESES.forEach(m => { efeito[m] = 0; });
  acoes.filter(a => a.tipo !== 'RECLASSIFICAR' && !a.provisaoSemNF).forEach(a => { efeito[a.mes] += a.valor; });
  acoes.filter(a => a.provisaoSemNF).forEach(a => { efeito[a.mes] += a.valor; a.provisaoSemNF = false; a.texto = a.texto.replace('Reverter quando a NF entrar.', 'Não há NF desse valor no semestre: estornar.'); });
  const sobra = {}; MESES.forEach(m => { sobra[m] = r2(razMes[m] + efeito[m] - alvoMes[m]); });
  const alvoTot = soma(MESES, m => alvoMes[m]);
  // 0a) linha com data de 2025 no histórico e o gerencial do mês não tem esse valor -> competência 2025
  lanc.filter(l => RG.eCompetencia2025(l) && !l._2025 && !l._dup).sort((a, b) => Math.abs(b.valor) - Math.abs(a.valor)).forEach(l => {
    if (!(Math.sign(l.valor) * sobra[l.mes] >= Math.abs(l.valor) - TOL)) return;
    l._2025 = true; l._dup = true;
    acoes.push({ tipo: 'COMPETÊNCIA 2025', mes: l.mes, conta: l.conta, valor: -l.valor, lanc: [l], texto: textoData2025(l) + ' O gerencial de ' + l.mes + ' não tem esse valor.' });
    sobra[l.mes] = r2(sobra[l.mes] - l.valor);
  });
  const nfs = lanc.filter(l => l.valor > 0 && l.tipo !== 'PROVISAO' && !l._dup);
  const fmt = v => 'R$ ' + Math.round(Math.abs(v)).toLocaleString('pt-BR');
  // (a) competência de cada NF, com prova: reversão que cita a NF > valor igual ao gerencial de um mês > mês do lançamento
  const compDaNF = {};
  lanc.filter(l => l.tipo === 'REVERSAO' || l.tipo === 'ESTORNO').forEach(r => { const c = competencia(r.historico); const n = (String(r.historico).match(/NF\s*([A-Z0-9]{3,})/i) || [])[1]; if (c && n && c.ano === 2026) compDaNF[n] = c.mes; });
  const provDoMes = {}; lanc.filter(l => l.tipo === 'PROVISAO' && l.valor > 0).forEach(p => { (provDoMes[p.mes] = provDoMes[p.mes] || []).push(p); });
  const revCitando = {}; lanc.filter(l => (l.tipo === 'REVERSAO' || l.tipo === 'ESTORNO') && l.valor < 0).forEach(r => { const c = competencia(r.historico); if (c && c.ano === 2026) (revCitando[c.mes] = revCitando[c.mes] || []).push(r); });
  const usadosMes = new Set();
  const atribuidas = new Set(); let lag = false;
  const nfsOrd = nfs.filter(l => !l._dup && (l.tipo === 'NF' || l.nf || l.valor >= 1000)).sort((x, y) => MESES.indexOf(x.mes) - MESES.indexOf(y.mes) || (parseInt(x.nf) || 0) - (parseInt(y.nf) || 0));
  const IDX = m => m === 'Dez25' ? -1 : m === 'Jul' ? 6 : MESES.indexOf(m);
  // provisão do mês c que já foi revertida (qualquer texto de reversão, mesmo valor, mês >= c)
  const revs = lanc.filter(l => (l.tipo === 'REVERSAO' || l.tipo === 'ESTORNO') && l.valor < 0);
  const provRevertida = c => (provDoMes[c] || []).filter(p => revs.some(r => Math.abs(Math.abs(r.valor) - p.valor) <= 1 && MESES.indexOf(r.mes) >= MESES.indexOf(c)) || (revCitando[c] || []).some(r => Math.abs(Math.abs(r.valor) - p.valor) <= 1));
  const atribuicao = new Map();
  if (nfsOrd.length && nfsOrd.length <= 80) {
    const V = vagas(ent);
    if (V.length) {
      const C = nfsOrd.map(nf => {
        const bi = MESES.indexOf(nf.mes);
        return [...V.map(vg => { const d = Math.abs(nf.valor - vg.v); const q = d <= Math.max(2, 0.0001 * vg.v) ? 0 : d <= 0.005 * vg.v ? 1 : null; if (q === null) return 1e6;
          const sh = bi - IDX(vg.m); if (vg.m === 'Dez25' ? sh < 1 : vg.m === 'Jul' ? sh !== -1 : (sh < -1 || sh > 4)) return 1e6; if (q > 0 && sh !== 0) return 1e6; return 10 * q + Math.abs(sh) + (vg.comp ? 0.5 : 0) + (vg.ambiguo ? 0.5 : 0); }),
          ...nfsOrd.map(() => 100)];
      });
      hungaro(C).forEach((j, i) => { if (j >= 0 && j < V.length && C[i][j] < 1e6) atribuicao.set(nfsOrd[i], V[j]); });
      const totUsado = new Set([...atribuicao.values()].filter(v => !v.comp).map(v => v.m));
      for (const [nf, v] of [...atribuicao]) if (v.comp && totUsado.has(v.m)) atribuicao.delete(nf);
      ent._vagasUsadas = [...atribuicao].map(([nf, v]) => ({ nf, v }));
    }
  }
  for (const nf of nfsOrd) {
    const vg = atribuicao.get(nf);
    let c = vg ? vg.m : null, prova = vg ? 'valor igual ao ' + vg.rot : '';
    if (!c && nf.nf && compDaNF[nf.nf] && ![...atribuicao.values()].some(x => x.m === compDaNF[nf.nf] && !x.comp)) { c = compDaNF[nf.nf]; prova = 'reversão cita a NF'; }
    if (!c) continue;
    usadosMes.add(c); atribuidas.add(nf);
    if (c === nf.mes) continue;
    if (c === 'Dez25') {
      lag = true; nf._2025 = true;
      acoes.push({ tipo: 'COMPETÊNCIA 2025', mes: nf.mes, conta: nf.conta, valor: -nf.valor, lanc: [nf], texto: 'NF' + (nf.nf ? ' ' + nf.nf : '') + ' de ' + fmt(nf.valor) + ' lançada em ' + nf.mes + ' tem o valor de dez/2025 no ERP (' + vg.rot + ')' + (vg.ambiguo ? ' e o mês de ' + nf.mes + ' já tem a NF dele' : '; em 2026 o valor é outro') + '. É competência 2025: sai da despesa de 2026 (contra a provisão de 2025).' });
      sobra[nf.mes] = r2(sobra[nf.mes] - nf.valor); continue;
    }
    if (c === 'Jul') { // NF de jul/2026 lançada em jun
      acoes.push({ tipo: 'REVERTER (NF adiantada)', mes: nf.mes, conta: contaPadrao, valor: -nf.valor, lanc: [nf], texto: 'A NF' + (nf.nf ? ' ' + nf.nf : '') + ' de ' + fmt(nf.valor) + ' foi lançada em ' + nf.mes + ', mas é de jul/2026 (' + prova + '; ' + nf.mes + ' já tem a sua NF). Reverter em ' + nf.mes + ' e reconhecer em jul.' });
      sobra[nf.mes] = r2(sobra[nf.mes] - nf.valor); continue;
    }
    if (MESES.indexOf(c) > MESES.indexOf(nf.mes)) { // NF lançada antes do mês de competência
      acoes.push({ tipo: 'REVERTER (NF adiantada)', mes: nf.mes, conta: contaPadrao, valor: -nf.valor, lanc: [nf], texto: 'A NF' + (nf.nf ? ' ' + nf.nf : '') + ' de ' + fmt(nf.valor) + ' foi lançada em ' + nf.mes + ', mas é de ' + c + ' (' + prova + '). Reverter em ' + nf.mes + '.' });
      acoes.push({ tipo: 'PROVISIONAR', mes: c, conta: contaPadrao, valor: nf.valor, lanc: [nf], texto: 'Reconhecer em ' + c + ' a NF' + (nf.nf ? ' ' + nf.nf : '') + ' (' + fmt(nf.valor) + ') revertida de ' + nf.mes + '.' });
      sobra[nf.mes] = r2(sobra[nf.mes] - nf.valor); sobra[c] = r2(sobra[c] + nf.valor); continue;
    }
    lag = true;
    const provC = provRevertida(c);
    const provV = soma(provC, p => p.valor);
    if (provC.length) {
      const e = r2(nf.valor - provV);
      const gerUsaNF = Math.abs(alvoMes[c] - nf.valor) < Math.abs(alvoMes[c] - provV);
      if (Math.abs(e) > TOL && gerUsaNF) {
        acoes.push({ tipo: e > 0 ? 'COMPLEMENTAR PROVISÃO' : 'REDUZIR PROVISÃO', mes: c, conta: contaPadrao, valor: e, lanc: [nf, ...provC], texto: 'Provisão de ' + c + ' foi ' + fmt(provV) + ', mas a NF' + (nf.nf ? ' ' + nf.nf : '') + ' de ' + c + ' veio ' + fmt(nf.valor) + ' (' + prova + '). ' + (e > 0 ? 'Complementar ' : 'Reduzir ') + fmt(e) + ' em ' + c + '.' });
        acoes.push({ tipo: 'BAIXAR PROVISÃO', mes: nf.mes, conta: contaPadrao, valor: -e, lanc: [nf], texto: 'Baixa do ajuste da provisão de ' + c + ' (' + fmt(e) + ') em ' + nf.mes + ', mês em que a NF' + (nf.nf ? ' ' + nf.nf : '') + ' entrou.' });
        sobra[c] = r2(sobra[c] + e); sobra[nf.mes] = r2(sobra[nf.mes] - e);
      }
    } else {
      acoes.push({ tipo: 'PROVISIONAR', mes: c, conta: contaPadrao, valor: nf.valor, lanc: [nf], texto: 'A NF' + (nf.nf ? ' ' + nf.nf : '') + ' de ' + fmt(nf.valor) + ' é de ' + c + ' (' + prova + ') mas só entrou em ' + nf.mes + ', e ' + c + ' ficou sem provisão. Provisionar em ' + c + '.' });
      acoes.push({ tipo: 'BAIXAR PROVISÃO', mes: nf.mes, conta: contaPadrao, valor: -nf.valor, lanc: [nf], texto: 'Baixar em ' + nf.mes + ' a provisão de ' + c + ' contra a NF' + (nf.nf ? ' ' + nf.nf : '') + '.' });
      sobra[c] = r2(sobra[c] + nf.valor); sobra[nf.mes] = r2(sobra[nf.mes] - nf.valor);
    }
  }
  {
    const soltas = nfsOrd.filter(l => !atribuidas.has(l) && !l._dup && l.valor >= 100);
    soltas.forEach(nf => {
      if (!(sobra[nf.mes] >= 0.5 * nf.valor)) return;
      if (ent.comp && sobra[nf.mes] >= nf.valor - TOL && (ent.comp.v2025 || []).some(v => Math.abs(v - nf.valor) <= 1)) {
        nf._2025 = true; atribuidas.add(nf);
        acoes.push({ tipo: 'COMPETÊNCIA 2025', mes: nf.mes, conta: nf.conta, valor: -nf.valor, lanc: [nf], texto: 'NF' + (nf.nf ? ' ' + nf.nf : '') + ' de ' + fmt(nf.valor) + ' lançada em ' + nf.mes + ' tem o valor pago em 2025 (ERP 2025); em 2026 o valor desta pessoa é outro e todos os meses de 2026 já têm a sua NF. É competência 2025: sai da despesa de 2026.' });
        sobra[nf.mes] = r2(sobra[nf.mes] - nf.valor); return;
      }
      const usadas = ent._vagasUsadas || [];
      const coberta = usadas.filter(u => u.nf !== nf && Math.abs(u.nf.valor - nf.valor) <= 1).sort((x, y) => (y.nf.mes === nf.mes) - (x.nf.mes === nf.mes))[0];
      const livre = vagas(ent).some(v => Math.abs(v.v - nf.valor) <= 1 && !usadas.some(u => u.v.m === v.m && Math.abs(u.v.v - v.v) <= 1));
      if (coberta && coberta.nf.mes === nf.mes && !livre && sobra[nf.mes] >= nf.valor - TOL && nf.mes === 'Jan' && (lag || !(ent.comp && ent.comp.some(v => v.m === 'Dez25' && !v.ambiguo)))) {
        nf._2025 = true; atribuidas.add(nf);
        acoes.push({ tipo: 'COMPETÊNCIA 2025', mes: nf.mes, conta: nf.conta, valor: -nf.valor, lanc: [nf, coberta.nf], texto: 'Jan tem mais de uma NF de ' + fmt(nf.valor) + ' (' + (nf.nf || 's/nº') + ' e ' + (coberta.nf.nf || 's/nº') + '); o gerencial de jan tem uma só' + (lag ? ' e este fornecedor fatura depois do mês de uso' : '') + '. A NF ' + (nf.nf || 's/nº') + ' é de mês de 2025 faturado em jan: sai da despesa de 2026 (contra a provisão de 2025).' });
        sobra[nf.mes] = r2(sobra[nf.mes] - nf.valor); return;
      }
      const unicoERP = ent.comp && ent.comp.filter(v => v.m !== 'Dez25' && Math.abs(v.v - nf.valor) <= 1).length === 1 && Math.round(nf.valor) !== nf.valor;
      if (coberta && (coberta.nf.mes === nf.mes || unicoERP) && !livre && sobra[nf.mes] >= nf.valor - TOL) {
        nf._dup = true; atribuidas.add(nf);
        acoes.push({ tipo: 'EXCLUIR DUPLICADO', mes: nf.mes, conta: nf.conta, valor: -nf.valor, lanc: [nf, coberta.nf], texto: 'NF ' + (nf.nf || 's/nº') + ' (' + fmt(nf.valor) + ', ' + nf.mes + ') repete o valor da NF ' + (coberta.nf.nf || 's/nº') + ' (' + coberta.nf.mes + '), que já cobre o ' + coberta.v.rot + '. ' + (ent.comp ? 'O ERP não tem outro pagamento desse valor' : 'O gerencial não tem outro mês com esse valor') + ': excluir a NF ' + (nf.nf || 's/nº') + ' (lançada em dobro).' });
        sobra[nf.mes] = r2(sobra[nf.mes] - nf.valor); return;
      }
      const parcN = x => (String(x.historico).match(/PARC\s*(\d+)\s*\/\s*(\d+)/i) || String(x.historico).match(/-\s*(\d{3})\/(\d{3})\s*-/) || []).slice(1).join('/');
      const irma = [...atribuidas, ...nfsOrd].find(x => x !== nf && !x._dup && x.mes === nf.mes && Math.abs(x.valor - nf.valor) <= 1 && !(parcN(x) && parcN(nf) && parcN(x) !== parcN(nf)) && !/^FATURA$/i.test(nf.nf || '') && MESES.every(m => m === nf.mes || lanc.filter(y => y.mes === m && Math.abs(y.valor - nf.valor) <= 1 && y.valor > 0 && y.tipo !== 'PROVISAO').length === 1 || !(alvoMes[m] > 0)));
      const semVaga = !MESES.some(m => Math.abs(sobra[m] + nf.valor) <= Math.max(1, 0.005 * nf.valor));
      if (irma && semVaga) {
        nf._dup = true; atribuidas.add(nf);
        acoes.push({ tipo: 'EXCLUIR DUPLICADO', mes: nf.mes, conta: nf.conta, valor: -nf.valor, lanc: [nf, irma], texto: 'Duas NFs de ' + fmt(nf.valor) + ' em ' + nf.mes + ' (' + (irma.nf || 's/nº') + ' e ' + (nf.nf || 's/nº') + '). ' + (ent.comp ? 'O ERP tem um só pagamento desse valor no mês' : 'O fornecedor cobra uma NF de ' + fmt(nf.valor) + ' por mês') + ' e nenhum outro mês de 2026 está sem a sua NF. Excluir a NF ' + (nf.nf || 's/nº') + ' (lançada em dobro).' });
        sobra[nf.mes] = r2(sobra[nf.mes] - nf.valor);
      }
    });
  }
  // (b2) jan: soma de 1 a 3 linhas de jan (não atribuídas a mês de 2026) = excesso, e o fornecedor fatura com atraso -> competência dez/2025
  if (sobra.Jan > TOL && lag) {
    const cj = nfs.filter(l => l.mes === 'Jan' && !l._dup && !atribuidas.has(l) && l.valor >= 100);
    let hit = null;
    for (let i = 0; i < cj.length && !hit; i++) {
      if (Math.abs(cj[i].valor - sobra.Jan) <= Math.max(1, 0.005 * sobra.Jan)) { hit = [cj[i]]; break; }
      for (let j = i + 1; j < cj.length && !hit; j++) {
        if (Math.abs(cj[i].valor + cj[j].valor - sobra.Jan) <= Math.max(1, 0.005 * sobra.Jan)) { hit = [cj[i], cj[j]]; break; }
        for (let k = j + 1; k < cj.length; k++) if (Math.abs(cj[i].valor + cj[j].valor + cj[k].valor - sobra.Jan) <= Math.max(1, 0.005 * sobra.Jan)) { hit = [cj[i], cj[j], cj[k]]; break; }
      }
    }
    if (hit) { const v = r2(soma(hit, l => l.valor)); hit.forEach(l => { l._2025 = true; });
      acoes.push({ tipo: 'COMPETÊNCIA 2025', mes: 'Jan', conta: hit[0].conta, valor: -v, lanc: hit, texto: 'Este fornecedor fatura depois do mês de uso (nos outros meses a NF de um mês entra no seguinte). ' + (hit.length > 1 ? 'As NFs ' : 'A NF ') + hit.map(l => (l.nf || 's/nº') + ' (' + fmt(l.valor) + ')').join(' + ') + ' lançada(s) em jan não correspondem a nenhum mês de 2026: são de dez/2025. Sair da despesa de 2026.' });
      sobra.Jan = r2(sobra.Jan - v); }
  }
  // (b) jan: NF lançada em jan que não é de nenhum mês de 2026 e tem o valor exato do excesso -> competência dez/2025
  if (sobra.Jan > TOL) {
    const nf = nfs.find(l => l.mes === 'Jan' && !l._dup && !atribuidas.has(l) && Math.abs(l.valor - sobra.Jan) <= Math.max(1, 0.01 * l.valor));
    if (nf) { acoes.push({ tipo: 'COMPETÊNCIA 2025', mes: 'Jan', conta: nf.conta, valor: -nf.valor, lanc: [nf], texto: 'NF' + (nf.nf ? ' ' + nf.nf : '') + ' de ' + fmt(nf.valor) + ' entrou em jan, mas o gerencial de jan é outra nota. É competência dez/2025: sai da despesa de 2026 (contra a provisão de 2025).' }); sobra.Jan = r2(sobra.Jan - nf.valor); }
  }
  // (e) estorno de uma NF feito em mês diferente do lançamento dela -> o estorno pertence ao mês da NF
  lanc.filter(l => l.valor < 0 && l.nf).forEach(es => {
    const orig = lanc.find(l => l.valor > 0 && l.nf === es.nf && l.mes !== es.mes && Math.abs(l.valor + es.valor) <= 1 && MESES.indexOf(l.mes) < MESES.indexOf(es.mes));
    if (!orig || !(sobra[orig.mes] > TOL) || !(sobra[es.mes] < -TOL)) return;
    const v = r2(-es.valor);
    acoes.push({ tipo: 'REVERTER (NF adiantada)', mes: orig.mes, conta: contaPadrao, valor: -v, lanc: [orig, es], texto: 'A NF ' + es.nf + ' (' + fmt(v) + ') foi lançada em dobro em ' + orig.mes + ' e estornada só em ' + es.mes + '. O estorno pertence a ' + orig.mes + ': estornar em ' + orig.mes + '.' });
    acoes.push({ tipo: 'PROVISIONAR', mes: es.mes, conta: contaPadrao, valor: v, lanc: [es], texto: 'Desfazer em ' + es.mes + ' o estorno da NF ' + es.nf + ' (ele passa para ' + orig.mes + ').' });
    sobra[orig.mes] = r2(sobra[orig.mes] - v); sobra[es.mes] = r2(sobra[es.mes] + v);
  });
  // (f) valor exato: a sobra de um mês é igual à falta de outro (não vizinho) -> NF lançada no mês errado
  for (const a of MESES) for (const b of MESES) {
    if (a === b || !(sobra[a] > TOL) || !(sobra[b] < -TOL)) continue;
    const l = nfs.find(x => x.mes === a && !x._dup && Math.abs(x.valor + sobra[b]) <= Math.max(1, 0.005 * x.valor) && x.valor <= sobra[a] + TOL);
    const v = l ? r2(l.valor) : (Math.abs(sobra[a] + sobra[b]) <= 1 ? r2(sobra[a]) : 0);
    if (!v) continue;
    const ref = l ? ' (NF ' + (l.nf || 's/nº') + ', ' + fmt(v) + ')' : '';
    if (MESES.indexOf(b) < MESES.indexOf(a)) {
      acoes.push({ tipo: 'PROVISIONAR', mes: b, conta: contaPadrao, valor: v, lanc: l ? [l] : [], texto: 'O valor de ' + b + ref + ' foi lançado em ' + a + '. Provisionar em ' + b + '.' });
      acoes.push({ tipo: 'BAIXAR PROVISÃO', mes: a, conta: contaPadrao, valor: -v, lanc: l ? [l] : [], texto: 'Baixar em ' + a + ' a provisão de ' + b + ref + '.' });
    } else {
      acoes.push({ tipo: 'REVERTER (NF adiantada)', mes: a, conta: contaPadrao, valor: -v, lanc: l ? [l] : [], texto: 'O valor lançado em ' + a + ref + ' é de ' + b + '. Reverter em ' + a + '.' });
      acoes.push({ tipo: 'PROVISIONAR', mes: b, conta: contaPadrao, valor: v, lanc: l ? [l] : [], texto: 'Reconhecer em ' + b + ref + '.' });
    }
    sobra[a] = r2(sobra[a] - v); sobra[b] = r2(sobra[b] + v);
  }
  // (d) pares de meses vizinhos sem NF que explique (cartão, boleto sem número)
  for (let i = 1; i < MESES.length; i++) {
    const a = MESES[i - 1], b = MESES[i];
    if (sobra[a] < -TOL && sobra[b] > TOL) {
      const v = r2(Math.min(-sobra[a], sobra[b]));
      acoes.push({ tipo: 'PROVISIONAR', mes: a, conta: contaPadrao, valor: v, lanc: [], texto: fmt(v) + ' de ' + a + ' foram lançados em ' + b + '. Provisionar em ' + a + '.' });
      acoes.push({ tipo: 'BAIXAR PROVISÃO', mes: b, conta: contaPadrao, valor: -v, lanc: [], texto: 'Baixar em ' + b + ' a provisão de ' + a + ' (' + fmt(v) + ').' });
      sobra[a] = r2(sobra[a] + v); sobra[b] = r2(sobra[b] - v);
    } else if (sobra[a] > TOL && sobra[b] < -TOL) {
      const v = r2(Math.min(sobra[a], -sobra[b]));
      acoes.push({ tipo: 'REVERTER (NF adiantada)', mes: a, conta: contaPadrao, valor: -v, lanc: [], texto: fmt(v) + ' lançados em ' + a + ' são de ' + b + ' (lançado antes da competência). Reverter em ' + a + '.' });
      acoes.push({ tipo: 'PROVISIONAR', mes: b, conta: contaPadrao, valor: v, lanc: [], texto: 'Reconhecer em ' + b + ' os ' + fmt(v) + ' revertidos de ' + a + '.' });
      sobra[a] = r2(sobra[a] - v); sobra[b] = r2(sobra[b] + v);
    }
  }
  // (c) último mês sem NF ainda: provisionar o gerencial (a NF entra no mês seguinte)
  const ult = MESES[MESES.length - 1];
  if (sobra[ult] < -TOL && !lanc.some(l => l.mes === ult && l.valor > 0)) {
    acoes.push({ tipo: 'PROVISIONAR', mes: ult, conta: contaPadrao, valor: -sobra[ult], lanc: [], texto: 'NF de ' + ult + ' ainda não entrou. Provisionar ' + fmt(sobra[ult]) + ' em ' + ult + ' (baixa no mês em que a NF entrar).' });
    sobra[ult] = 0;
  }
  const sobraTot = r2(soma(MESES, m => sobra[m]));
  const timing = Math.abs(sobraTot) <= Math.max(TOL, 0.01 * Math.abs(alvoTot));
  // (c) o que ainda sobra
  MESES.forEach(m => {
    const sv = sobra[m];
    if (Math.abs(sv) <= TOL) return;
    if (ent.gapConhecido) { acoes.push({ tipo: 'NOTA (diferença conhecida)', mes: m, conta: contaPadrao, valor: -sv, lanc: [], texto: ent.gapConhecido, semLancar: true }); return; }
    const nadaNoRazao = soma(MESES, x => Math.abs(razMes[x])) === 0;
    if (sv < 0) acoes.push({ tipo: nadaNoRazao ? 'FALTA LANÇAR' : 'PROVISIONAR', mes: m, conta: contaPadrao, valor: -sv, lanc: [],
      texto: nadaNoRazao ? 'Gerencial tem ' + fmt(sv) + ' em ' + m + ' e o razão não tem nenhum lançamento deste fornecedor no semestre. Lançar a NF (ou provisionar) em ' + m + '.'
        : 'Razão tem ' + fmt(sv) + ' a menos que o gerencial em ' + m + '. Provisionar a diferença em ' + m + '.' });
    else acoes.push({ tipo: 'VERIFICAR', mes: m, conta: contaPadrao, valor: -sv, lanc: [], semLancar: true,
      texto: (ent.nome === 'Various Equipment' ? 'Compras de equipamento (Chypps, Kabum, Stark, AliExpress) lançadas como despesa na 4.1.2.01.002; no P&L equipamento de TI é CAPEX (IT Equipment & Computers). ' : '') + 'Razão tem ' + fmt(sv) + ' a mais que o gerencial em ' + m + ' e não há duplicidade, provisão sem baixa nem NF de outro mês que explique. ' + (ent.nome === 'Various Equipment' ? 'Confirmar quais itens vão para o imobilizado (1.2.2.01.x).' : 'Pedir a NF antes de ajustar.') });
  });
  return { ...ent, razMes, sobra, sobraTot, timing, acoes };
}

// ---------- entidades ----------
const casos = [];
const MESMO = {}; MESES.forEach(m => { MESMO[m] = 0; });
grupos.filter(g => g.chaves.length || MESES.some(m => g.gerMes[m])).forEach(g => {
  const nome = g.nomesGer.join(' + ');
  const gap = Object.entries(RG.GAP_CONHECIDO).find(([k]) => g.nomesGer.includes(k));
  casos.push(montar({ bloco: 'Fornecedores (P&L)', nome, chaves: g.chaves, sublinhas: g.sublinhas, metodo: g.metodo,
    lancamentos: g.lancamentos, alvoMes: g.gerMes, permitidas: g.permitidas, contaPadrao: g.contaPadrao, gapConhecido: gap && gap[1] }));
});
rubricas.forEach(r => casos.push(montar({ bloco: 'Linhas agregadas do P&L', nome: r.nomesGer[0], chaves: r.chaves, sublinhas: r.sublinhas, metodo: r.metodo,
  lancamentos: r.lancamentos, alvoMes: r.gerMes, permitidas: r.permitidas, contaPadrao: r.contaPadrao })));

const norm = s => String(s || '').toUpperCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Z ]/g, ' ').replace(/\s+/g, ' ').trim();
const dez = {}; ERP.filter(r => r.ano === 2025 && r.mes === 12).forEach(r => { const k = norm(r.fornecedor); dez[k] = dez[k] || { bonus: 0, salario: 0 }; if (r.categoria === 'Bônus') dez[k].bonus += r.valor; if (r.categoria === 'Salário') dez[k].salario += r.valor; });
const MIDX = { 1: 'Jan', 2: 'Fev', 3: 'Mar', 4: 'Abr', 5: 'Mai', 6: 'Jun', 7: 'Jul' };
const { distratosAplicados } = require('./folha.json');
function componentes(p) {
  const rows = ERP.filter(r => norm(r.fornecedor) === norm(p.pessoa));
  const out = [];
  const por = {}; rows.forEach(r => { const m = r.ano === 2025 && r.mes === 12 ? 'Dez25' : r.ano === 2026 ? MIDX[r.mes] : null; if (!m) return; (por[m] = por[m] || []).push(r); });
  (distratosAplicados || []).filter(d => d.pessoa === p.pessoa && /somado/.test(d.obs)).forEach(d => (por[d.mes] = por[d.mes] || []).push({ categoria: 'Distrato', valor: d.valor }));
  const v2026 = [];
  Object.entries(por).forEach(([m, rs]) => {
    const add = (v, rot, combo) => { if (v > 0 && !(combo && out.some(o => o.m === m && Math.abs(o.v - v) <= 1))) out.push({ m, v: r2(v), rot, comp: true }); };
    const cat = c => r2(soma(rs.filter(r => r.categoria === c), r => r.valor));
    const S = cat('Salário'), Cm = cat('Comissão'), B = cat('Bônus'), D = cat('Distrato'), T = r2(soma(rs, r => r.valor));
    const tag = m === 'Dez25' ? 'dez/2025' : m;
    add(S, 'ERP ' + tag + ' salário'); add(Cm, 'ERP ' + tag + ' comissão'); add(B, 'ERP ' + tag + ' bônus'); add(D, 'distrato ' + tag);
    if (S > 0 && Cm > 0) add(S + Cm, 'ERP ' + tag + ' salário + comissão', 1); if (S > 0 && B > 0) add(S + B, 'ERP ' + tag + ' salário + bônus', 1); if ([S, Cm, B, D].filter(x => x > 0).length > 1) add(T, 'ERP ' + tag + ' total', 1);
    if (m !== 'Dez25' && m !== 'Jul') [T, S, Cm, B, D, S + Cm].forEach(v => v > 0 && v2026.push(v));
  });
  // dez/2025 só vale como prova se o valor não existe em 2026 (senão é ambíguo)
  out.forEach(o => { if (o.m === 'Dez25' && v2026.some(v => Math.abs(v - o.v) <= 1)) o.ambiguo = true; });
  const v2025 = rows.filter(r => r.ano === 2025).map(r => r.valor);
  out.v2025 = v2025.filter(v => !v2026.some(x => Math.abs(x - v) <= 1)); out.v2026 = v2026;
  return out;
}
pessoas.forEach(p => casos.push(montar({ comp: componentes(p), bloco: 'Folha PJ (por pessoa)', nome: p.pessoa, area: p.area, vinculo: p.vinculo, chaves: [...new Set(p.lancamentos.map(l => l.chave))],
  sublinhas: [p.area], metodo: p.vinculo ? 'vínculo por valor: ' + p.vinculo : 'Cadastro', lancamentos: p.lancamentos, alvoMes: p.erpMes,
  permitidas: [p.contaCerta], contaPadrao: p.contaCerta, dez2025: dez[norm(p.pessoa)] || { bonus: 0, salario: 0 } })));

// ---------- folha sem pessoa (régua = ERP) e equipamentos (CAPEX no gerencial) ----------
const GER = require('../extracted/dados/gerencial_fornecedor.json');
const todosSemDono = [...semPar.flatMap(s => s.lancamentos), ...naoPessoaFolha];
const naFolha0 = new Set(pessoas.flatMap(p => p.lancamentos).map(idL));
const pegos = new Set();
function especial(nome, re, erpFiltro, conta, permitidas, extra) {
  const lanc = []; const vis = new Set();
  todosSemDono.forEach(l => { const id = idL(l); if (vis.has(id) || naFolha0.has(id) || pegos.has(id)) return; if (re.test(l.chave)) { vis.add(id); pegos.add(id); lanc.push(l); } });
  const alvo = {}; MESES.forEach((m, i) => { alvo[m] = erpFiltro ? r2(soma(ERP.filter(r => r.ano === 2026 && r.mes === i + 1 && erpFiltro(r)), r => r.valor)) : 0; });
  return montar(Object.assign({ bloco: 'Folha — sem pessoa (ERP)', nome, chaves: [...new Set(lanc.map(l => l.chave))], sublinhas: ['Folha (painel People)'], metodo: 'Realizado ERP',
    lancamentos: lanc, alvoMes: alvo, permitidas, contaPadrao: conta }, extra || {}));
}
const swile = especial('Swile (bônus e benefício)', /SWILE/, r => /SWILE/i.test(r.fornecedor), '4.1.6.02.004', ['4.1.6.02.004', '4.1.6.01.007', '6.2.1.01.001'],
  { jan2025: 'Bônus de líderes de dez/2025 pago via Swile em jan (NF 1762064). A Controladoria confirmou na rodada anterior que o excesso de jan é bônus, e no gerencial ele está em dez/2025.' });
const ifood = especial('iFood (benefício)', /IFOOD/, r => r.categoria === 'Benefício' && /IFOOD/i.test(r.fornecedor), '4.1.6.02.002', ['4.1.6.02.002']);
const guia = especial('Guia da Alma (benefício psicológico)', /GUIA ALMA/, r => r.categoria === 'Benefício' && /Guia/i.test(r.fornecedor), '4.1.6.02.006', ['4.1.6.02.006']);
casos.push(swile, ifood, guia);
// equipamento: no P&L gerencial é CAPEX (IT Equipment & Computers / Furniture & Fixtures) -> sai da despesa
{
  const re = /^(DELL|LG ELECTRONICS|KABUM|CHYPPS|STARK|ALIEXPRESS|COMFY|EMESUL|EBAZAR|PILOTO|BRAULIO KISNER)/;
  const lanc = []; const vis = new Set();
  [...todosSemDono, ...equipDasRubricas].forEach(l => { const id = idL(l); if (vis.has(id) || naFolha0.has(id)) return; if (re.test(l.chave)) { vis.add(id); pegos.add(id); lanc.push(l); } });
  const capexGer = {}; MESES.forEach(m => { capexGer[m] = r2(soma(GER.filter(r => r.mes === m && /IT Equipment|Furniture/.test(r.sublinha)), r => r.valor)); });
  const razM = {}; MESES.forEach(m => { razM[m] = r2(soma(lanc.filter(l => l.mes === m), l => l.valor)); });
  const acoes = [];
  const pm = {}; lanc.forEach(l => { const k = l.mes + '|' + l.conta; (pm[k] = pm[k] || []).push(l); });
  Object.entries(pm).forEach(([k, ls]) => { const [mes, conta] = k.split('|'); const v = r2(soma(ls, l => l.valor)); if (Math.abs(v) < 1) return;
    acoes.push({ tipo: 'RECLASSIFICAR', mes, conta, contaPara: '1.2.2.01.003', valor: v, lanc: ls, texto: 'Compra de equipamento/mobiliário (' + [...new Set(ls.map(l => l.fornecedor.slice(0, 25)))].join(', ') + ') lançada como despesa na conta ' + conta + '. No P&L gerencial isso é CAPEX (IT Equipment & Computers / Furniture & Fixtures): tirar da despesa e ativar no imobilizado (1.2.2.01.x).' }); });
  casos.push({ bloco: 'CAPEX (sai da despesa)', nome: 'Equipamentos e mobiliário', chaves: [...new Set(lanc.map(l => l.chave))], sublinhas: ['IT Equipment & Computers', 'Furniture & Fixtures'], metodo: 'fornecedor de equipamento',
    lancamentos: lanc, alvoMes: razM, capexGer, permitidas: ['1.2.2.01.003'], contaPadrao: '1.2.2.01.003', razMes: razM, sobra: {}, sobraTot: 0, timing: true, acoes });
}

// fornecedores do razão sem par (fora de folha) + não-pessoas em conta de folha/passagem
const naFolha = new Set(pessoas.flatMap(p => p.lancamentos).map(idL));
const semParLanc0 = [...semPar.flatMap(s => s.lancamentos), ...naoPessoaFolha].filter(l => !naFolha.has(idL(l)) && !pegos.has(idL(l)));
{
  const vis = new Set();
  const ls = semParLanc0.filter(l => { const id = idL(l); if (vis.has(id) || !RG.eCompetencia2025(l)) return false; vis.add(id); return true; });
  ls.forEach(l => pegos.add(idL(l)));
  const razM = {}; MESES.forEach(m => { razM[m] = r2(soma(ls.filter(l => l.mes === m), l => l.valor)); });
  casos.push({ bloco: 'Competência 2025 (sem par)', nome: 'Lançamentos de 2025 sem fornecedor no P&L', chaves: [...new Set(ls.map(l => l.chave))], sublinhas: [], metodo: 'data de 2025 no histórico',
    lancamentos: ls, alvoMes: Object.fromEntries(MESES.map(m => [m, 0])), permitidas: [...new Set(ls.map(l => l.conta))], contaPadrao: ls.length ? ls[0].conta : '', razMes: razM, sobra: {}, sobraTot: 0, timing: true,
    acoes: ls.map(l => ({ tipo: 'COMPETÊNCIA 2025', mes: l.mes, conta: l.conta, valor: -l.valor, lanc: [l], texto: textoData2025(l) + ' (' + l.fornecedor.slice(0, 40) + ')' })) });
}
const semParLanc = semParLanc0.filter(l => !pegos.has(idL(l)));
const vistos = new Set();
const semParPorChave = {};
semParLanc.forEach(l => { const id = idL(l); if (vistos.has(id)) return; vistos.add(id); (semParPorChave[l.chave] = semParPorChave[l.chave] || []).push(l); });
const semParCasos = Object.entries(semParPorChave).map(([chave, ls]) => {
  const razMes = {}; MESES.forEach(m => { razMes[m] = r2(soma(ls.filter(l => l.mes === m), l => l.valor)); });
  const contas = [...new Set(ls.map(l => l.conta))];
  const naPassagem = ls.filter(l => RG.CONTAS_PASSAGEM[l.conta]);
  const contaBoa = Object.entries(ls.filter(l => !RG.CONTAS_PASSAGEM[l.conta]).reduce((o, l) => (o[l.conta] = (o[l.conta] || 0) + l.valor, o), {})).sort((a, b) => b[1] - a[1])[0];
  return { chave, fornecedor: ls[0].fornecedor, razMes, total: r2(soma(ls, l => l.valor)), contas, lancamentos: ls,
    passagem: r2(soma(naPassagem, l => l.valor)), contaSugerida: naPassagem.length && contaBoa ? contaBoa[0] : '' };
}).filter(x => Math.abs(x.total) >= 1 || x.lancamentos.length);

fs.writeFileSync(path.join(__dirname, 'achados.json'), JSON.stringify({ casos, semParCasos, foraEscopo }));

// ---------- resumo ----------
const tipos = {};
casos.forEach(c => c.acoes.forEach(a => { tipos[a.tipo] = tipos[a.tipo] || { n: 0, v: 0 }; tipos[a.tipo].n++; tipos[a.tipo].v += a.valor; }));
console.log('casos:', casos.length, '| sem par:', semParCasos.length);
Object.entries(tipos).forEach(([k, o]) => console.log(k.padEnd(28), String(o.n).padStart(4), 'R$', Math.round(o.v).toLocaleString('pt-BR')));
['Fornecedores (P&L)', 'Linhas agregadas do P&L', 'Folha PJ (por pessoa)'].forEach(b => {
  const cs = casos.filter(c => c.bloco === b);
  const R = soma(cs, c => soma(MESES, m => c.razMes[m])), A = soma(cs, c => soma(MESES, m => c.alvoMes[m]));
  console.log(b.padEnd(26), 'razão', Math.round(R).toLocaleString('pt-BR'), '| régua', Math.round(A).toLocaleString('pt-BR'), '| dif', Math.round(R - A).toLocaleString('pt-BR'));
});
console.log('sem par no gerencial (razão):', Math.round(soma(semParCasos, s => s.total)).toLocaleString('pt-BR'), '| dos quais em conta de passagem:', Math.round(soma(semParCasos, s => s.passagem)).toLocaleString('pt-BR'));
