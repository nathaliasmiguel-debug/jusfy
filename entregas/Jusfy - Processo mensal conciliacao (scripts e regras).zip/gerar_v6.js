// Excel pra Syhus: Resumo, O QUE FAZER (mínimo de lançamentos), Onde a Syhus erra, DRE Consolidado, Jan..Jun (DRE aberto
// por conta e fornecedor do razão) e Notas e pendências. Tudo sai dos dados (razão, P&L oficial, ERP) — nada estimado.
const ExcelJS = require('exceljs');
const path = require('path');
const RG = require('./regras.js');
const L = require('./lancamentos.json');
const A = require('./achados.json');
const calcular = require('./selecao.js');
const { efeitos } = require('./selecao.js');
const { M, r2, grupoConta, contaDaAcao, ger, antes, nota, pend } = require('./metas.js');
const SEMPAR = require('./sempar_classif.json');

const MESNOME = { Jan: 'Janeiro', Fev: 'Fevereiro', Mar: 'Março', Abr: 'Abril', Mai: 'Maio', Jun: 'Junho' };
const soma = (a, f) => a.reduce((s, x) => s + f(x), 0);
const fmt = v => 'R$ ' + Math.round(Math.abs(v)).toLocaleString('pt-BR');
const nomeConta = {}; L.forEach(l => { nomeConta[l.conta] = l.contaNome; });
Object.assign(nomeConta, { '6.2.1.03.004': 'Custo de Inteligência Artificial', '4.1.3.01.009': 'Twitter Ads', '1.2.2.01.003': 'Imobilizado — Equipamentos e móveis' });
const dre = c => /^(4\.1|6\.2)/.test(c) && !RG.CONTAS_NAO_OPERACIONAIS.test(c);
const RAZ = L.filter(l => dre(l.conta) && !RG.naoOperacional(l));
const PROVISAO = '930 - Provisão de Fornecedores';

// ---------- os lançamentos escolhidos (mínimo exato, ver selecao.js / otimo.py) ----------
const { moves } = calcular({ C: 0.005, O: 0.005, T: 0.005 });
const { escolhidos } = require('./milp_out.json');
const casoPorNome = {}; A.casos.forEach(c => { casoPorNome[c.nome] = c; });
const maisFrequente = arr => { const n = {}; arr.forEach(x => { n[x] = (n[x] || 0) + 1; }); return Object.keys(n).sort((a, b) => n[b] - n[a] || b.length - a.length)[0]; };
function nomeRazao(a) {
  const doLanc = (a.lanc || []).map(l => l.fornecedor).filter(Boolean);
  if (doLanc.length) return maisFrequente(doLanc);
  const c = casoPorNome[a.rubricaOriginal || a.entidade];
  if (c) {
    const naConta = c.lancamentos.filter(l => l.conta === a.contaUsada).map(l => l.fornecedor).filter(Boolean);
    const todos = c.lancamentos.map(l => l.fornecedor).filter(Boolean);
    if (naConta.length) return maisFrequente(naConta);
    if (todos.length) return maisFrequente(todos);
  }
  return a.entidade;
}
const ORDEM_TIPO = ['EXCLUIR DUPLICADO', 'ESTORNAR PROVISÃO', 'RECLASSIFICAR', 'REVERTER (NF adiantada)', 'BAIXAR PROVISÃO', 'REDUZIR PROVISÃO', 'PROVISIONAR', 'COMPLEMENTAR PROVISÃO', 'FALTA LANÇAR', 'LANÇAR MDR PAGAR.ME'];
const acoes = escolhidos.flatMap(k => moves[k].map(a => ({ ...a, mv: k })))
  .map(a => ({ ...a, razao: nomeRazao(a), linhaPL: a.rubricaOriginal || a.entidade }))
  .sort((a, b) => M.indexOf(a.mes) - M.indexOf(b.mes) || ORDEM_TIPO.indexOf(a.tipo) - ORDEM_TIPO.indexOf(b.tipo) || Math.abs(b.valor) - Math.abs(a.valor));
acoes.forEach((a, i) => { a.n = i + 1; });
acoes.forEach(a => { const par = acoes.find(b => b !== a && b.mv === a.mv); if (par) a.par = par.n; });

const ROTULO = {
  'EXCLUIR DUPLICADO': 'Excluir — lançado em dobro', 'ESTORNAR PROVISÃO': 'Estornar provisão que nunca foi baixada', 'RECLASSIFICAR': 'Trocar de conta',
  'REVERTER (NF adiantada)': 'Reverter — NF é do mês seguinte', 'BAIXAR PROVISÃO': 'Baixar a provisão (a NF chegou)', 'REDUZIR PROVISÃO': 'Reduzir a provisão',
  'PROVISIONAR': 'Provisionar no mês certo', 'COMPLEMENTAR PROVISÃO': 'Complementar a provisão', 'FALTA LANÇAR': 'Lançar — falta no razão',
  'LANÇAR MDR PAGAR.ME': 'Lançar o MDR da Pagar.me (retido no repasse)',
};
function partidas(a) { // débito / crédito, sempre com contas que existem no razão
  const v = a.valor;
  const cn = c => c + ' - ' + (nomeConta[c] || '');
  if (a.tipo === 'RECLASSIFICAR') return v >= 0 ? [cn(a.contaPara), cn(a.conta)] : [cn(a.conta), cn(a.contaPara)];
  const X = cn(a.contaUsada);
  const Y = a.tipo === 'EXCLUIR DUPLICADO' ? ((a.lanc || [])[0] || {}).contrapartida || 'contrapartida do lançamento em dobro'
    : a.tipo === 'LANÇAR MDR PAGAR.ME' ? 'Pagar.me — valores a receber (conta do repasse)' : PROVISAO;
  return v >= 0 ? [X, Y] : [Y, X];
}
function prova(a) {
  let t = a.texto;
  const m = /^Razão tem R\$ ([\d.]+) a menos que o gerencial em (\w+)\. Provisionar a diferença em \w+\.$/.exec(t);
  if (m) t = 'O P&L de ' + MESNOME[m[2]].toLowerCase() + ' tem R$ ' + m[1] + ' deste fornecedor e o razão não tem a NF desse mês. Provisionar pelo valor do P&L; quando a NF chegar, baixar a provisão' + (a.mes === 'Jun' ? ' (a NF de junho chega em julho: baixar em julho).' : '.');
  if (a.tipo === 'RECLASSIFICAR') {
    const c = casoPorNome[a.rubricaOriginal || a.entidade] || {};
    const pq = c.bloco === 'Folha PJ (por pessoa)' ? 'PJ da área ' + c.area + ' (Cadastro). No P&L oficial, só a folha de Engenharia é custo; as demais áreas são despesa. '
      : /^1\.2\.2/.test(a.contaPara) ? 'No P&L é investimento (imobilizado), não despesa. ' : 'No P&L este fornecedor está em ' + (c.sublinhas || []).join(', ') + '. ';
    t = pq + t;
  }
  if (a.par) t += ' (Faz par com o lançamento nº ' + a.par + '.)';
  return t;
}

// ---------- DRE por mês: conta × fornecedor do razão ----------
const chave = (m, c, f) => m + '|' + c + '|' + f;
const linhasDRE = {};
const pega = (m, c, f) => (linhasDRE[chave(m, c, f)] = linhasDRE[chave(m, c, f)] || { mes: m, conta: c, forn: f, esta: 0, ajuste: 0, nums: [], obs: new Set() });
RAZ.forEach(l => { pega(l.mes, l.conta, l.fornecedor || l.chave || '(sem fornecedor no histórico)').esta += l.valor; });
acoes.forEach(a => {
  const f = a.razao;
  if (a.tipo === 'RECLASSIFICAR') {
    const de = pega(a.mes, a.conta, f); de.ajuste -= a.valor; de.nums.push(a.n);
    if (dre(a.contaPara)) { const p = pega(a.mes, a.contaPara, f); p.ajuste += a.valor; p.nums.push(a.n); }
    else de.obs.add('Sai da despesa: vai para o imobilizado ' + a.contaPara + '.');
    return;
  }
  const x = pega(a.mes, a.contaUsada, f); x.ajuste += a.valor; x.nums.push(a.n);
});
// competência 2025 fica em 2026 (nota): marca as linhas do razão que são de 2025
A.casos.forEach(c => c.acoes.filter(a => a.tipo === 'COMPETÊNCIA 2025').forEach(a => (a.lanc || []).forEach(l => {
  const x = linhasDRE[chave(l.mes, l.conta, l.fornecedor || l.chave || '(sem fornecedor no histórico)')];
  if (x) x.obs.add('Tem ' + fmt(l.valor) + ' de competência 2025: fica em 2026 (exercício encerrado), é nota explicativa.');
})));
const TODAS = Object.values(linhasDRE).map(x => ({ ...x, esta: r2(x.esta), ajuste: r2(x.ajuste), deve: r2(x.esta + x.ajuste) }));

// ---------- visual (Poppins, tons pastel) ----------
const NAVY = 'FF12395E', INK = 'FF1F2933', MUTED = 'FF6B7A88', LINE = 'FFDDE4EA', CINZA = 'FFEEF1F4';
const VERDE = 'FFE3F1E8', AMARELO = 'FFFFF4CC', LARANJA = 'FFFDE7D6', VERMELHO = 'FFF8DEDE', AZUL = 'FFE3EEF8', LILAS = 'FFEDE7F6';
const F = (o = {}) => Object.assign({ name: 'Poppins', size: 10, color: { argb: INK } }, o);
const fill = c => ({ type: 'pattern', pattern: 'solid', fgColor: { argb: c } });
const MONEY = '#,##0.00;[Red]-#,##0.00;"-"';
const PCT = '0.00%;[Red]-0.00%';
const COR_TIPO = { 'RECLASSIFICAR': AZUL, 'EXCLUIR DUPLICADO': VERMELHO, 'ESTORNAR PROVISÃO': VERMELHO, 'PROVISIONAR': LARANJA, 'BAIXAR PROVISÃO': LARANJA,
  'COMPLEMENTAR PROVISÃO': LARANJA, 'REDUZIR PROVISÃO': LARANJA, 'REVERTER (NF adiantada)': LARANJA, 'FALTA LANÇAR': AMARELO, 'LANÇAR MDR PAGAR.ME': AMARELO };
function titulo(ws, t, s, n) {
  ws.mergeCells(1, 1, 1, n); const a = ws.getCell(1, 1); a.value = t; a.font = F({ size: 15, bold: true, color: { argb: NAVY } });
  ws.mergeCells(2, 1, 2, n); const b = ws.getCell(2, 1); b.value = s; b.font = F({ size: 10, italic: true, color: { argb: MUTED } }); b.alignment = { wrapText: true, vertical: 'top' };
  ws.getRow(1).height = 26; ws.getRow(2).height = Math.max(30, Math.ceil(s.length / 140) * 15);
}
function cab(ws, l, cols, congela = true) {
  cols.forEach((h, i) => { const c = ws.getCell(l, i + 1); c.value = h; c.font = F({ bold: true, color: { argb: 'FFFFFFFF' } }); c.fill = fill(NAVY); c.alignment = { vertical: 'middle', wrapText: true }; });
  ws.getRow(l).height = 30; if (congela) ws.views = [{ state: 'frozen', ySplit: l }];
}
function lin(ws, l, vals, o = {}) {
  vals.forEach((v, i) => {
    const c = ws.getCell(l, i + 1); c.value = v; c.font = F(o.bold ? { bold: true } : {});
    c.alignment = { wrapText: true, vertical: 'top' }; c.border = { bottom: { style: 'thin', color: { argb: LINE } } };
    if ((o.money || []).includes(i)) c.numFmt = MONEY;
    if ((o.pct || []).includes(i)) c.numFmt = PCT;
    if (o.fillAll) c.fill = fill(o.fillAll);
    if (o.fill && o.fill[i]) c.fill = fill(o.fill[i]);
  });
}
const secao = (ws, l, t, n) => { ws.mergeCells(l, 1, l, n); const c = ws.getCell(l, 1); c.value = t; c.font = F({ bold: true, size: 12, color: { argb: 'FFFFFFFF' } }); c.fill = fill(NAVY); ws.getRow(l).height = 22; };
const fx = (formula, result) => ({ formula, result: r2(result) });

const wb = new ExcelJS.Workbook(); wb.creator = 'Nathalia'; wb.lastModifiedBy = 'Nathalia';
wb.calcProperties.fullCalcOnLoad = true; // Excel recalcula tudo ao abrir (não depende do valor guardado)

// ================= ABAS DE MÊS (primeiro, pra saber as células que o Consolidado e o Resumo puxam) =================
const celula = {}; // conta|mes -> linha do subtotal na aba do mês
const totMes = {}; // mes -> linhas dos totais
M.forEach(m => {
  const ws = wb.addWorksheet(m);
  ws.columns = [{ width: 14 }, { width: 34 }, { width: 46 }, { width: 15 }, { width: 14 }, { width: 15 }, { width: 11 }, { width: 70 }];
  titulo(ws, MESNOME[m] + '/2026 — DRE contábil aberto por conta e fornecedor', 'Cada conta do DRE com os fornecedores do razão (nome como está no livro da Syhus). "Como está" = razão de hoje. "Ajuste" = os lançamentos da aba O QUE FAZER (nº na coluna G). "Como deve ficar" = como a conta fica depois. Os subtotais e totais são fórmulas.', 8);
  let r = 4;
  cab(ws, r, ['Conta', 'Descrição', 'Fornecedor (razão)', 'Como está', 'Ajuste', 'Como deve ficar', 'Lançamento nº', 'Observação']); r++;
  const doMes = TODAS.filter(x => x.mes === m);
  const contas = [...new Set(doMes.map(x => x.conta))].sort((a, b) => (grupoConta(a) === 'C' ? 0 : 1) - (grupoConta(b) === 'C' ? 0 : 1) || a.localeCompare(b));
  const subC = [], subO = [];
  contas.forEach(ct => {
    const itens = doMes.filter(x => x.conta === ct).sort((a, b) => Math.abs(b.ajuste) - Math.abs(a.ajuste) || Math.abs(b.esta) - Math.abs(a.esta));
    const rc = r; r++;
    const ini = r;
    itens.forEach(x => {
      const cor = x.nums.length ? (COR_TIPO[(acoes.find(a => a.n === x.nums[0]) || {}).tipo] || AZUL) : null;
      lin(ws, r, ['', '', x.forn, x.esta, x.ajuste || 0, fx('D' + r + '+E' + r, x.deve), x.nums.join(', '), [...x.obs].join(' ')], { money: [3, 4, 5], fill: cor ? { 4: cor, 6: cor } : {} });
      if (x.nums.length) ws.getCell(r, 5).font = F({ bold: true });
      r++;
    });
    const fim = r - 1;
    const e = r2(soma(itens, x => x.esta)), aj = r2(soma(itens, x => x.ajuste));
    lin(ws, rc, [ct, nomeConta[ct] || '', 'TOTAL DA CONTA', fx('SUM(D' + ini + ':D' + fim + ')', e), fx('SUM(E' + ini + ':E' + fim + ')', aj), fx('SUM(F' + ini + ':F' + fim + ')', e + aj), '', ''], { money: [3, 4, 5], bold: true, fillAll: CINZA });
    celula[ct + '|' + m] = { r: rc, esta: e, ajuste: aj };
    (grupoConta(ct) === 'C' ? subC : subO).push(rc);
  });
  r++;
  const i = M.indexOf(m);
  const somaRef = (rows, col) => rows.length ? rows.map(x => col + x).join('+') : '0';
  const tC = { e: soma(subC, x => doMes.filter(y => y.conta === ws.getCell(x, 1).value).reduce((s, y) => s + y.esta, 0)) };
  const vC = { esta: antes.C[i], aj: r2(soma(doMes.filter(x => grupoConta(x.conta) === 'C'), x => x.ajuste)) };
  const vO = { esta: antes.O[i], aj: r2(soma(doMes.filter(x => grupoConta(x.conta) === 'O'), x => x.ajuste)) };
  const T = {};
  T.C = r; lin(ws, r, ['', '', 'TOTAL CUSTO (6.2)', fx(somaRef(subC, 'D'), vC.esta), fx(somaRef(subC, 'E'), vC.aj), fx(somaRef(subC, 'F'), vC.esta + vC.aj), '', ''], { money: [3, 4, 5], bold: true, fillAll: AZUL }); r++;
  T.O = r; lin(ws, r, ['', '', 'TOTAL DESPESA (4.1)', fx(somaRef(subO, 'D'), vO.esta), fx(somaRef(subO, 'E'), vO.aj), fx(somaRef(subO, 'F'), vO.esta + vO.aj), '', ''], { money: [3, 4, 5], bold: true, fillAll: AZUL }); r++;
  T.T = r; lin(ws, r, ['', '', 'TOTAL DO MÊS', fx('D' + T.C + '+D' + T.O, vC.esta + vO.esta), fx('E' + T.C + '+E' + T.O, vC.aj + vO.aj), fx('F' + T.C + '+F' + T.O, vC.esta + vC.aj + vO.esta + vO.aj), '', ''], { money: [3, 4, 5], bold: true, fillAll: VERDE }); r++;
  totMes[m] = { ...T, vC, vO };
  ws.autoFilter = { from: { row: 4, column: 1 }, to: { row: T.C - 2, column: 8 } };
});

// ================= DRE CONSOLIDADO (puxa das abas de mês) =================
const dc = wb.addWorksheet('DRE Consolidado');
dc.columns = [{ width: 14 }, { width: 40 }, ...M.map(() => ({ width: 14 })), { width: 15 }];
titulo(dc, 'DRE contábil consolidado — como vai ficar, conta por conta', 'Cada célula puxa o subtotal da conta na aba do mês ("Como deve ficar" e "Ajuste"). Embaixo, o gerencial (P&L oficial) e a diferença por grupo. As notas aceitas (competência 2025, taxa Pagar.me, folha) estão explicadas no Resumo.', 9);
let r = 4;
const contasTodas = [...new Set(TODAS.map(x => x.conta))].sort((a, b) => (grupoConta(a) === 'C' ? 0 : 1) - (grupoConta(b) === 'C' ? 0 : 1) || a.localeCompare(b));
const blocoConsol = (tituloSec, col, campo) => {
  secao(dc, r, tituloSec, 9); r++;
  cab(dc, r, ['Conta', 'Descrição', ...M, 'Total'], false); r++;
  const linhasG = { C: [], O: [] };
  contasTodas.forEach(ct => {
    const vals = M.map(m => { const c = celula[ct + '|' + m]; if (!c) return 0; return fx("'" + m + "'!" + col + c.r, campo === 'deve' ? c.esta + c.ajuste : c.ajuste); });
    const tot = r2(soma(vals, v => (typeof v === 'object' ? v.result : v)));
    if (campo === 'ajuste' && Math.abs(tot) < 0.5 && vals.every(v => Math.abs(typeof v === 'object' ? v.result : v) < 0.5)) return;
    lin(dc, r, [ct, nomeConta[ct] || '', ...vals, fx('SUM(C' + r + ':H' + r + ')', tot)], { money: [2, 3, 4, 5, 6, 7, 8] });
    linhasG[grupoConta(ct)].push(r); r++;
  });
  const out = {};
  ['C', 'O'].forEach(g => {
    const rows = linhasG[g];
    const vals = M.map((m, i) => { const v = campo === 'deve' ? (g === 'C' ? totMes[m].vC.esta + totMes[m].vC.aj : totMes[m].vO.esta + totMes[m].vO.aj) : (g === 'C' ? totMes[m].vC.aj : totMes[m].vO.aj); const colL = String.fromCharCode(67 + i); return fx(rows.length ? 'SUM(' + rows.map(x => colL + x).join(',') + ')' : '0', v); });
    out[g] = r;
    lin(dc, r, ['', g === 'C' ? 'TOTAL CUSTO (6.2)' : 'TOTAL DESPESA (4.1)', ...vals, fx('SUM(C' + r + ':H' + r + ')', soma(vals, v => v.result))], { money: [2, 3, 4, 5, 6, 7, 8], bold: true, fillAll: AZUL }); r++;
  });
  const totV = M.map((m, i) => fx(String.fromCharCode(67 + i) + out.C + '+' + String.fromCharCode(67 + i) + out.O, soma([out.C, out.O], x => dc.getCell(x, 3 + i).value.result)));
  out.T = r; lin(dc, r, ['', 'TOTAL', ...totV, fx('SUM(C' + r + ':H' + r + ')', soma(totV, v => v.result))], { money: [2, 3, 4, 5, 6, 7, 8], bold: true, fillAll: VERDE }); r++;
  return out;
};
const deve = blocoConsol('COMO VAI FICAR (contábil depois dos lançamentos)', 'F', 'deve');
const G = {};
[['C', 'Gerencial — custo (P&L oficial)'], ['O', 'Gerencial — despesa (P&L oficial)']].forEach(([g, t]) => { G[g] = r; lin(dc, r, ['', t, ...ger[g], fx('SUM(C' + r + ':H' + r + ')', soma(ger[g], x => x))], { money: [2, 3, 4, 5, 6, 7, 8] }); r++; });
[['C', 'Diferença — custo'], ['O', 'Diferença — despesa']].forEach(([g, t]) => {
  const vals = M.map((m, i) => { const cl = String.fromCharCode(67 + i); return fx(cl + deve[g] + '-' + cl + G[g], dc.getCell(deve[g], 3 + i).value.result - ger[g][i]); });
  lin(dc, r, ['', t + ' (antes das notas explicativas)', ...vals, fx('SUM(C' + r + ':H' + r + ')', soma(vals, v => v.result))], { money: [2, 3, 4, 5, 6, 7, 8], fillAll: AMARELO }); r++;
});
r++;
blocoConsol('AJUSTE DESTA REVISÃO (soma dos lançamentos por conta)', 'E', 'ajuste');

// ================= RESUMO =================
const rs = wb.addWorksheet('Resumo');
rs.columns = [{ width: 58 }, ...M.map(() => ({ width: 14 })), { width: 15 }];
titulo(rs, 'JUSFY — DRE contábil × gerencial · Janeiro a Junho 2026', 'Três degraus, por mês: (1) como está hoje; (2) depois dos ' + acoes.length + ' lançamentos da Syhus (aba O QUE FAZER) — a única nota explicativa é a competência 2025, que fica em 2026 porque o exercício de 2025 já fechou; (3) depois das pendências que dependem de resposta da Jusfy (aba Notas e pendências). Meta: até 0,5%.', 8);
r = 4;
const M7 = [1, 2, 3, 4, 5, 6, 7];
const tot = v => r2(v.reduce((a, b) => a + b, 0));
const porG = (obj, g) => (g === 'T' ? M.map((m, i) => obj.C[i] + obj.O[i]) : obj[g]);
const blocoRes = (g, nomeG) => {
  secao(rs, r, nomeG, 8); r++;
  cab(rs, r, ['', ...M, 'Total'], false); r++;
  const razH = porG(antes, g);
  const aj = M.map(m => g === 'T' ? totMes[m].vC.aj + totMes[m].vO.aj : (g === 'C' ? totMes[m].vC.aj : totMes[m].vO.aj));
  const gr = porG(ger, g);
  const c25 = porG(nota.comp2025, g);
  const depois = M.map((m, i) => razH[i] + aj[i]);
  const difHoje = M.map((m, i) => razH[i] - gr[i] - c25[i]);
  const difSyhus = M.map((m, i) => depois[i] - gr[i] - c25[i]);
  const P = { verif: porG(pend.verif, g), semPar: porG(pend.semPar, g), agregadas: porG(pend.agregadas, g), folha: porG(pend.folha, g) };
  const difFinal = M.map((m, i) => difSyhus[i] - P.verif[i] - P.semPar[i] - P.agregadas[i] - P.folha[i]);
  const pct = v => [...v.map((x, i) => x / gr[i]), tot(v) / tot(gr)];
  lin(rs, r, ['Gerencial (P&L oficial)', ...gr.map(r2), tot(gr)], { money: M7 }); r++;
  lin(rs, r, ['Razão como está hoje', ...razH.map(r2), tot(razH)], { money: M7 }); r++;
  lin(rs, r, ['(−) Competência 2025 lançada em 2026 — NOTA EXPLICATIVA (exercício encerrado, fica em 2026)', ...c25.map(r2), tot(c25)], { money: M7, fillAll: LILAS }); r++;
  lin(rs, r, ['1) Diferença HOJE', ...difHoje.map(r2), tot(difHoje)], { money: M7, bold: true, fillAll: AMARELO }); r++;
  lin(rs, r, ['    % sobre o gerencial', ...pct(difHoje)], { pct: M7, fillAll: AMARELO }); r++;
  lin(rs, r, ['(+) Lançamentos da Syhus (aba O QUE FAZER)', ...aj.map(r2), tot(aj)], { money: M7 }); r++;
  lin(rs, r, ['2) Diferença DEPOIS DA SYHUS', ...difSyhus.map(r2), tot(difSyhus)], { money: M7, bold: true, fillAll: AZUL }); r++;
  lin(rs, r, ['    % sobre o gerencial', ...pct(difSyhus)], { pct: M7, fillAll: AZUL }); r++;
  lin(rs, r, ['(−) Pendência Jusfy: razão maior que o P&L, sem prova de qual NF sobra', ...P.verif.map(r2), tot(P.verif)], { money: M7, fillAll: CINZA }); r++;
  lin(rs, r, ['(−) Pendência Jusfy: fornecedor do razão que não está no P&L', ...P.semPar.map(r2), tot(P.semPar)], { money: M7, fillAll: CINZA }); r++;
  lin(rs, r, ['(−) Pendência Jusfy: linha agregada do P&L (Hotels, Taxi…) sem fornecedor no razão', ...P.agregadas.map(r2), tot(P.agregadas)], { money: M7, fillAll: CINZA }); r++;
  lin(rs, r, ['(−) Pendência Jusfy: folha — painel de pessoas × cadastro/ERP', ...P.folha.map(r2), tot(P.folha)], { money: M7, fillAll: CINZA }); r++;
  lin(rs, r, ['3) Diferença DEPOIS DAS PENDÊNCIAS DA JUSFY', ...difFinal.map(r2), tot(difFinal)], { money: M7, bold: true, fillAll: VERDE }); r++;
  lin(rs, r, ['    % sobre o gerencial', ...pct(difFinal)], { pct: M7, bold: true, fillAll: VERDE }); r += 2;
  return { difHoje, difSyhus, difFinal, gr };
};
const RES = { C: blocoRes('C', 'CUSTO (contas 6.2)'), O: blocoRes('O', 'DESPESA (contas 4.1)'), T: blocoRes('T', 'TOTAL (custo + despesa)') };

// ================= O QUE FAZER =================
const qf = wb.addWorksheet('O QUE FAZER');
qf.columns = [{ width: 6 }, { width: 7 }, { width: 40 }, { width: 30 }, { width: 38 }, { width: 38 }, { width: 14 }, { width: 16 }, { width: 70 }, { width: 16 }];
titulo(qf, 'O QUE FAZER — ' + acoes.length + ' lançamentos (é só isso)', 'Todos os erros claros (lançamento em dobro, provisão que nunca foi baixada, MDR da Pagar.me) mais o mínimo que falta pra custo, despesa e total ficarem dentro de 0,5% do gerencial (depois das pendências da Jusfy). Cada linha é um fornecedor, com o nome como está no razão, débito, crédito, NF e a prova. Provisão e baixa do mesmo fornecedor andam juntas. Coluna "Status" é pra Syhus marcar.', 10);
r = 4;
cab(qf, r, ['Nº', 'Mês', 'Fornecedor (razão)', 'O que fazer', 'Débito', 'Crédito', 'Valor', 'NF', 'Por quê (a prova)', 'Status Syhus']); r++;
acoes.forEach(a => {
  const [deb, cred] = partidas(a);
  const nfs = [...new Set((a.lanc || []).map(l => l.nf).filter(Boolean))].join(', ') || '—';
  lin(qf, r, [a.n, a.mes, a.razao, ROTULO[a.tipo], deb, cred, Math.abs(a.valor), nfs, prova(a), ''], { money: [6], fill: { 3: COR_TIPO[a.tipo] || CINZA } });
  qf.getRow(r).height = Math.min(90, 16 * Math.max(2, Math.ceil(prova(a).length / 85)));
  r++;
});
lin(qf, r, ['', '', 'TOTAL (' + acoes.length + ' lançamentos, ' + new Set(acoes.map(a => a.razao)).size + ' fornecedores)', '', '', '', '', '', '', ''], { bold: true, fillAll: CINZA });
qf.autoFilter = { from: { row: 4, column: 1 }, to: { row: r - 1, column: 10 } };

// ================= ONDE A SYHUS ERRA =================
const oe = wb.addWorksheet('Onde a Syhus erra');
oe.columns = [{ width: 46 }, { width: 11 }, { width: 16 }, { width: 50 }, { width: 70 }];
titulo(oe, 'Onde a Syhus erra — e a regra pra não repetir', 'Contagem no semestre inteiro (jan a jun), com todos os erros encontrados — não só os ' + acoes.length + ' lançamentos desta revisão. Seguindo estas regras daqui pra frente, a conciliação do mês fica pequena.', 5);
r = 4;
cab(oe, r, ['Erro', 'Vezes', 'Valor', 'Exemplos (fornecedor como está no razão)', 'Regra pra não errar mais']); r++;
const todasAc = A.casos.flatMap(c => c.acoes.map(a => ({ ...a, c })));
const exemplos = arr => { const n = {}; arr.forEach(a => { const k = ((a.lanc || [])[0] || {}).fornecedor || a.c.nome; n[k] = (n[k] || 0) + Math.abs(a.valor); }); return Object.entries(n).sort((x, y) => y[1] - x[1]).slice(0, 4).map(x => x[0]).join('; '); };
const PROVT = ['PROVISIONAR', 'BAIXAR PROVISÃO', 'REVERTER (NF adiantada)', 'COMPLEMENTAR PROVISÃO', 'REDUZIR PROVISÃO'];
const recl = todasAc.filter(a => a.tipo === 'RECLASSIFICAR');
const padroes = [
  ['PJ de engenharia lançado como despesa', recl.filter(a => a.contaPara === '6.2.1.01.001'), 'Todo PJ da área de Engenharia (Cadastro) vai em 6.2.1.01.001 (custo). Produto e as demais áreas ficam em 4.1.6.01.007 (despesa) — é assim que está no P&L oficial.', AZUL],
  ['Fornecedor de dados/API lançado como licença ou consultoria', recl.filter(a => a.contaPara === '6.2.1.03.003'), 'Fornecedor de dados/API (Digesto, VIR, Judit, Nova DD, Big Data, Datacube, Carbigdata…) vai em 6.2.1.03.003 — Custo de APIs de Terceiros.', AZUL],
  ['"Mera importação" (4.1.2.05.011) usada como conta de passagem', recl.filter(a => a.conta === '4.1.2.05.011'), 'Não deixar NF parada em 4.1.2.05.011: toda NF importada vai direto pra conta do fornecedor (a mesma dos outros meses).', AZUL],
  ['Compra de equipamento/móvel lançada como despesa', recl.filter(a => /^1\.2\.2/.test(a.contaPara)), 'Computador, monitor, móvel e revestimento da sede são imobilizado (1.2.2.01.003), não despesa.', AZUL],
  ['Distrato (rescisão) lançado como custo', recl.filter(a => a.contaPara === '4.1.6.02.007'), 'Distrato é sempre despesa de RH — Contract Termination (4.1.6.02.007), qualquer que seja a área da pessoa. Não vai em 6.2.1.01.001 nem junto com a NF de serviço.', AZUL],
  ['Outras trocas de conta', recl.filter(a => !['6.2.1.01.001', '6.2.1.03.003', '4.1.6.02.007'].includes(a.contaPara) && a.conta !== '4.1.2.05.011' && !/^1\.2\.2/.test(a.contaPara)), 'Usar sempre a conta que o fornecedor já tem nos outros meses; na dúvida, perguntar à Jusfy antes de lançar.', AZUL],
  ['MDR da Pagar.me não lançado', todasAc.filter(a => a.tipo === 'LANÇAR MDR PAGAR.ME'), 'Todo mês lançar a taxa cheia da Pagar.me pelo extrato de liquidação (o MDR retido no repasse), não só as NFs de serviço.', AMARELO],
  ['NF lançada pela data de chegada, não pela competência', todasAc.filter(a => a.tipo === 'PROVISIONAR' && !/^Razão tem/.test(a.texto)), 'Quando a NF chega depois do mês do serviço: provisionar no mês do serviço (conta 930) e baixar a provisão quando a NF chegar.', LARANJA],
  ['Mês sem a despesa do fornecedor (sem NF e sem provisão)', todasAc.filter(a => a.tipo === 'PROVISIONAR' && /^Razão tem/.test(a.texto)), 'No fechamento, conferir com a Jusfy os fornecedores recorrentes que ainda não mandaram NF e provisionar pelo valor do mês.', LARANJA],
  ['Provisão que nunca foi baixada', todasAc.filter(a => a.tipo === 'ESTORNAR PROVISÃO'), 'Toda provisão tem que ser baixada no mês em que a NF chega — conferir a conta 930 todo fechamento.', VERMELHO],
  ['Lançado em dobro', todasAc.filter(a => a.tipo === 'EXCLUIR DUPLICADO'), 'Antes de lançar pagamento (cartão, PIX, boleto), conferir se a NF daquele valor já está no razão.', VERMELHO],
  ['Despesa de 2025 lançada em 2026', todasAc.filter(a => a.tipo === 'COMPETÊNCIA 2025'), 'No fechamento de dezembro, provisionar o que já se sabe que vai chegar atrasado. (O que já caiu em 2026 fica em 2026 — é só nota explicativa.)', LILAS],
];
padroes.filter(p => p[1].length).forEach(p => {
  lin(oe, r, [p[0], p[1].length, r2(soma(p[1], a => Math.abs(a.valor))), exemplos(p[1]), p[2]], { money: [2], fill: { 0: p[3] } });
  oe.getRow(r).height = Math.min(70, 16 * Math.max(2, Math.ceil(p[2].length / 80))); r++;
});
r++;
oe.getCell(r, 1).value = 'Mudança de regra nesta revisão'; oe.getCell(r, 1).font = F({ bold: true, size: 11, color: { argb: NAVY } }); r++;
lin(oe, r, ['Folha de Produto é despesa', '', '', '', 'No P&L oficial, só a folha de Engenharia é custo ("Engineering & Technology Payroll"). Os PJs de Produto ficam em 4.1.6.01.007 (despesa). As pessoas de Produto que já estão em despesa estão certas.'], {}); oe.getRow(r).height = 40;

// ================= NOTAS E PENDÊNCIAS =================
const nt = wb.addWorksheet('Notas e pendências');
nt.columns = [{ width: 44 }, { width: 8 }, { width: 15 }, { width: 34 }, { width: 34 }, { width: 70 }];
titulo(nt, 'Nota explicativa e pendências da Jusfy — a Syhus não precisa fazer nada aqui', 'A: a única nota explicativa — competência 2025 que caiu em 2026 (o exercício de 2025 já fechou, então fica em 2026), por fornecedor, pra auditoria e CFO. B: pendências que dependem de resposta da Jusfy (cada uma com o valor e o que falta). C: parece erro, mas o P&L diz que o valor é devido — não mexer sem a Jusfy confirmar.', 6);
r = 4;
secao(nt, r, 'A. NOTA EXPLICATIVA — Competência 2025 lançada em 2026 (fica em 2026: exercício de 2025 encerrado)', 6); r++;
cab(nt, r, ['Fornecedor (razão)', 'Mês', 'Valor', 'Conta', 'Linha do P&L', 'Explicação'], false); r++;
const c25 = A.casos.flatMap(c => c.acoes.filter(a => a.tipo === 'COMPETÊNCIA 2025').map(a => ({ ...a, c }))).sort((a, b) => M.indexOf(a.mes) - M.indexOf(b.mes) || a.valor - b.valor);
c25.forEach(a => { const cu = contaDaAcao(a.c, a); lin(nt, r, [nomeRazao({ ...a, entidade: a.c.nome, contaUsada: cu }), a.mes, -a.valor, cu + ' ' + (nomeConta[cu] || ''), a.c.nome, a.texto], { money: [2], fill: { 2: LILAS } }); r++; });
lin(nt, r, ['TOTAL (' + c25.length + ' linhas)', '', r2(soma(c25, a => -a.valor)), '', '', ''], { money: [2], bold: true, fillAll: CINZA }); r += 2;

secao(nt, r, 'B1. Pendência Jusfy — razão maior que o P&L, sem prova de qual NF sobra', 6); r++;
cab(nt, r, ['Fornecedor (razão)', 'Mês', 'A mais no razão', 'Conta', 'Linha do P&L', 'O que falta'], false); r++;
const vf = A.casos.flatMap(c => c.acoes.filter(a => a.tipo === 'VERIFICAR').map(a => ({ ...a, c }))).sort((a, b) => a.valor - b.valor);
vf.forEach(a => { const cu = contaDaAcao(a.c, a); lin(nt, r, [nomeRazao({ ...a, entidade: a.c.nome, contaUsada: cu }), a.mes, -a.valor, cu + ' ' + (nomeConta[cu] || ''), a.c.nome, 'O razão tem ' + fmt(a.valor) + ' a mais que o P&L no mês, e não é NF em dobro, provisão esquecida nem NF de outro mês. Jusfy: mandar a NF / dizer se o P&L está sem alguma nota.'], { money: [2] }); r++; });
lin(nt, r, ['TOTAL (' + vf.length + ' linhas)', '', r2(soma(vf, a => -a.valor)), '', '', ''], { money: [2], bold: true, fillAll: CINZA }); r += 2;

secao(nt, r, 'B2. Pendência Jusfy — fornecedor do razão que não está no P&L (conferido na base do ERP)', 6); r++;
cab(nt, r, ['Fornecedor (razão)', 'Mês', 'Valor', 'Conta', 'Situação', 'Evidência / o que falta'], false); r++;
const spAbertos = SEMPAR.filter(x => !/^Está no P&L/.test(x.categoria)), spCasados = SEMPAR.filter(x => /^Está no P&L/.test(x.categoria));
spAbertos.forEach(x => { lin(nt, r, [x.fornecedor, x.mes, x.valor, x.conta + ' ' + (nomeConta[x.conta] || ''), x.categoria, x.evidencia + ' ' + x.acao], { money: [2], fill: { 4: AMARELO } }); r++; });
lin(nt, r, ['TOTAL em aberto (' + spAbertos.length + ' linhas)', '', r2(soma(spAbertos, x => x.valor)), '', '', ''], { money: [2], bold: true, fillAll: CINZA }); r++;
spCasados.forEach(x => { lin(nt, r, [x.fornecedor, x.mes, x.valor, x.conta + ' ' + (nomeConta[x.conta] || ''), 'Já casado', x.evidencia], { money: [2], fill: { 4: VERDE } }); r++; });
lin(nt, r, ['Já casados com a linha de RH do P&L (' + spCasados.length + ' linhas)', '', r2(soma(spCasados, x => x.valor)), '', '', 'Não são pendência: entram no P&L dentro de "HR Expenses & Payroll" (auxílio educacional).'], { money: [2], bold: true, fillAll: VERDE }); r += 2;

secao(nt, r, 'B3. Pendência Jusfy — linha agregada do P&L com diferença e sem fornecedor provado no razão', 6); r++;
cab(nt, r, ['Linha do P&L', 'Mês', 'Diferença', 'Conta', 'Tipo', 'O que falta'], false); r++;
const LANC0 = a => !a.semLancar && a.tipo !== 'VERIFICAR' && !/^NOTA/.test(a.tipo) && a.tipo !== 'COMPETÊNCIA 2025';
const agreg = A.casos.flatMap(c => require('./explode_fornecedor.js').explodir(c.bloco, c.acoes.filter(LANC0).map(a => ({ ...a, entidade: c.nome, contaUsada: contaDaAcao(c, a) }))).semFornecedor);
agreg.sort((a, b) => M.indexOf(a.mes) - M.indexOf(b.mes)).forEach(a => { lin(nt, r, [a.entidade, a.mes, a.valor, a.contaUsada + ' ' + (nomeConta[a.contaUsada] || ''), a.tipo, 'O P&L não abre esta linha por fornecedor e o razão não mostra qual fornecedor falta/sobra. ' + a.texto + ' Jusfy: dizer o fornecedor (ou mandar a NF).'], { money: [2] }); r++; });
lin(nt, r, ['TOTAL (' + agreg.length + ' linhas)', '', r2(soma(agreg, a => a.valor)), '', '', ''], { money: [2], bold: true, fillAll: CINZA }); r += 2;

secao(nt, r, 'B4. Pendência Jusfy — folha: painel de pessoas × cadastro/ERP', 6); r++;
cab(nt, r, ['Assunto', 'Mês', 'Valor', '', '', 'O que é / o que falta'], false); r++;
const F2 = require('./folha.json');
(F2.distratosAplicados || []).filter(d => /somado/.test(d.obs) && /^jun$/i.test(d.mes) && !/Vitor/i.test(d.pessoa)).forEach(d => { lin(nt, r, ['Distrato de ' + d.pessoa, 'Jun', d.valor, '', '', 'Está no ERP (competência e vencimento jun/26, conta 4.1.6.02.007) e no razão, mas o Contract Termination do painel de pessoas de junho só tem R$ 3.000 (Vitor). Jusfy: confirmar se entra no P&L de junho.'], { money: [2] }); r++; });
M.forEach((m, i) => { const v = pend.folha.C[i]; if (Math.abs(v) >= 1) { lin(nt, r, ['Área custo × despesa (Engenharia no painel × no Cadastro)', m, v, '', '', 'O painel conta como Engenharia (custo) cerca de ' + fmt(v) + ' a mais que as pessoas de Engenharia no Cadastro; o mesmo valor aparece a mais em despesa. Jusfy: dizer qual pessoa o painel põe em Engenharia e o Cadastro não.'], { money: [2] }); r++; } });
r++;

const revisar = require('./forca_revisar.json').filter(mv => !mv.some(a => acoes.some(b => b.tipo === a.tipo && b.mes === a.mes && Math.abs(b.valor - a.valor) < 1 && (b.linhaPL === a.entidade || b.entidade === a.entidade))));
secao(nt, r, 'C. Parece erro, mas o P&L diz que o valor é devido — não mexer sem a Jusfy confirmar', 6); r++;
cab(nt, r, ['Fornecedor', 'Mês', 'Valor', '', 'O que parecia', 'Por que não mexer'], false); r++;
revisar.flat().forEach(a => { lin(nt, r, [a.entidade, a.mes, a.valor, '', a.tipo + ': ' + a.texto, 'Se fizer este ajuste, o fornecedor fica mais longe do P&L do mês — ou seja, o P&L tem esse valor. Jusfy confirma antes.'], { money: [2] }); r++; });

const ordem = ['Resumo', 'O QUE FAZER', 'Onde a Syhus erra', 'DRE Consolidado', ...M, 'Notas e pendências'];
wb._worksheets = [undefined, ...ordem.map(n => wb.getWorksheet(n))].map((w, i) => { if (w) w.orderNo = i; return w; });
const out = path.join(__dirname, 'Jusfy - DRE Contabil Q1-Q2 2026 v3 - 24.09.26.xlsx');
module.exports = { acoes, TODAS, RES, out };
wb.xlsx.writeFile(out).then(() => console.log('OK', out, '| lançamentos:', acoes.length));
