// Regra fixa do processo: "Linhas agregadas do P&L" e "CAPEX" são categorias do P&L, não fornecedores.
// Uma ação nessas categorias só pode virar lançamento se o razão provar o fornecedor real (via lanc).
// Sem prova de fornecedor = nunca genérico, nunca "linha contábil": a ação fica de fora até ter prova.
const RUBRICA_GENERICA = new Set(['Linhas agregadas do P&L', 'CAPEX (sai da despesa)']);
const r2 = x => Math.round(x * 100) / 100;

// Recebe as ações "brutas" de um caso (já com entidade = nome do caso) e devolve a lista final:
// - fora de rubrica genérica: devolve como está.
// - rubrica genérica com 1 fornecedor no lanc: relabela a entidade para o fornecedor real.
// - rubrica genérica com vários fornecedores: separa uma linha por fornecedor (valor real de cada um).
// - rubrica genérica sem lanc (sem prova de fornecedor): não relanhum fornecedor pra provar -> vai para `semFornecedor` (não é ação de lançar).
function explodir(bloco, acoesBrutas) {
  if (!RUBRICA_GENERICA.has(bloco)) return { acoes: acoesBrutas, semFornecedor: [] };
  const acoes = [], semFornecedor = [];
  acoesBrutas.forEach(a => {
    const forns = [...new Set((a.lanc || []).map(l => l.fornecedor).filter(Boolean))];
    if (!forns.length) { semFornecedor.push(a); return; }
    if (forns.length === 1) { acoes.push({ ...a, rubricaOriginal: a.entidade, entidade: forns[0] }); return; }
    forns.forEach(f => {
      const linhasF = a.lanc.filter(l => l.fornecedor === f);
      const vAjustado = r2(linhasF.reduce((s, l) => s + l.valor, 0));
      acoes.push({ ...a, rubricaOriginal: a.entidade, entidade: f, valor: vAjustado, lanc: linhasF, texto: a.texto + ' (' + f + ': R$ ' + Math.round(Math.abs(vAjustado)).toLocaleString('pt-BR') + ')' });
    });
  });
  return { acoes, semFornecedor };
}

module.exports = { explodir, RUBRICA_GENERICA };
