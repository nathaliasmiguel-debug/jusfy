// Classifica cada fornecedor-mês em que o razão tem mais que o P&L (VERIFICAR), linha a linha contra o ERP (erp_linhas.js).
const A = require('./achados.json');
const { porLinha, nomeMes, M, R } = require('./erp_linhas.js');
const norm = s => String(s || '').toUpperCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
const { chave } = require('./erp_linhas.js');
const ymi = s => { const n = parseFloat(s); if (!n) return null; const d = new Date(Date.UTC(1899, 11, 30) + n * 864e5); return (d.getUTCFullYear() - 2026) * 12 + d.getUTCMonth(); };
const val = s => -(parseFloat(String(s).replace(/[^\d,-]/g, '').replace(',', '.')) || 0);
const usados = new Set([...porLinha.values()].flatMap(h => h.ids));
const erpMes = R.map((r, id) => ({ id, nome: norm(r['9'] + ' ' + (r['17'] || '')), i: ymi(r['14']), v: val(r['11']), ok: r['1'] === 'OK', fornecedor: r['9'] })).filter(e => e.ok && e.i !== null);
const r2 = x => Math.round(x * 100) / 100;
const out = [];
A.casos.forEach(c => c.acoes.forEach((a, ai) => {
  if (a.tipo !== 'VERIFICAR') return;
  const i = M.indexOf(a.mes), E = r2(-a.valor);
  const linhas = c.lancamentos.filter(l => l.mes === a.mes).map(l => {
    const h = porLinha.get(l);
    if (l.valor <= 0) return { l, st: 'estorno' };
    if (h && h.i === i) return { l, st: 'ok', erp: h };
    if (h) {
      const dest = h.i;
      const gapDest = dest >= 0 && dest < 6 ? r2((c.razMes[M[dest]] || 0) - (c.alvoMes[M[dest]] || 0)) : null;
      return { l, st: 'timing', erp: h, dest, gapDest };
    }
    // líquido: mesma competência, mesmo fornecedor, ERP entre 80% e 99,9% do valor da NF (imposto retido)
    const k = chave(l.fornecedor || l.chave || c.nome);
    const liq = erpMes.filter(e => !usados.has(e.id) && e.i === i && k && e.nome.split(' ').includes(k) && Math.abs(e.v) >= l.valor * 0.8 && Math.abs(e.v) < l.valor - 0.5)
      .sort((x, y) => Math.abs(y.v) - Math.abs(x.v))[0];
    if (liq) { usados.add(liq.id); return { l, st: 'liquido', erp: liq, ret: r2(l.valor - Math.abs(liq.v)) }; }
    return { l, st: 'fora' };
  });
  out.push({ caso: c.nome, ai, bloco: c.bloco, mes: a.mes, i, E, raz: c.razMes[a.mes] || 0, pl: c.alvoMes[a.mes] || 0, linhas });
}));
module.exports = { out, nomeMes, M };
if (require.main === module) {
  const f = v => Math.round(v).toLocaleString('pt-BR');
  out.forEach(o => {
    const s = st => o.linhas.filter(x => x.st === st);
    console.log(o.mes, o.caso.slice(0, 30).padEnd(30), 'a mais', f(o.E).padStart(7),
      '| timing', s('timing').map(x => f(x.l.valor) + '→' + nomeMes(x.dest) + (x.gapDest !== null ? '(gap ' + f(x.gapDest) + ')' : '')).join(' ') || '-',
      '| líquido', s('liquido').map(x => f(x.ret)).join(' ') || '-',
      '| fora', s('fora').map(x => (x.l.nf || 's/nº') + ':' + f(x.l.valor)).join(' ') || '-',
      '| ok', s('ok').length, '| est', s('estorno').map(x => f(x.l.valor)).join(' ') || '-');
  });
}
