// Cada linha do razão sem par × base financeira (ERP que alimenta o P&L): nome + valor + competência.
const A=require('./achados.json'),R=require('../extracted/dados/base_mari_rows.json');
const M=['Jan','Fev','Mar','Abr','Mai','Jun'];
const ym=s=>{const n=parseFloat(s);if(!n)return '';return new Date(Date.UTC(1899,11,30)+n*864e5).toISOString().slice(0,7)};
const norm=s=>String(s||'').toUpperCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^A-Z0-9 ]/g,' ').replace(/\s+/g,' ').trim();
const STOP=new Set(['LTDA','EPP','DE','DA','DO','DOS','DAS','EM','NF','PIX','ENVIADO','PARA','ESTORNO','PAGAMENTO','PAGAMENTOS','FATURA','COM','SERVICOS','SERVICO','TECNOLOGIA','BRASIL','CONFORME','RECIBO','FORNECEDOR','BOLETO','PARCELA','SOLUCOES','COMERCIO','INDUSTRIA','PRODUTOS','CONTA','PAGAR','GERADA','PARTIR','COPIA','OUTRA','VENCIMENTO','CUPOM','FISCAL','RUBRICA','VALOR','PROVISAO','NOTA','SILVA','SANTOS','OLIVEIRA','SOUZA','COSTA','FERREIRA','MARIA','LUCAS','RAFAEL','CARLOS','JOAO','PAULO','ANDRADE','GONCALVES','CARVALHO','RODRIGUES','ALEXANDRE','BIANCA']);
const val=s=>{const t=String(s).replace(/[^\d,-]/g,'').replace(',','.');return -(parseFloat(t)||0)};
const mi=c=>{const [y,m]=c.split('-').map(Number);return (y-2026)*12+m-1}; // jan/26 = 0
const base=R.filter(r=>r['1']==='OK'&&ym(r['14'])).map(r=>({nome:norm(r['9']+' '+(r['17']||'')),nomeOrig:r['9'],comp:ym(r['14']),ci:mi(ym(r['14'])),classe:String(r['5']),conta:String(r['10']),v:val(r['11']),cc:r['13']}));
const toks=s=>norm(s).split(' ').filter(t=>t.length>=4&&!STOP.has(t)&&!/^\d+$/.test(t));
const res=[];
A.semParCasos.forEach(s=>s.lancamentos.forEach(l=>{
  const tk=toks(s.chave+' '+(s.fornecedor||''));const li=M.indexOf(l.mes);
  const nomeOk=b=>tk.some(t=>b.nome.split(' ').includes(t));
  const valOk=b=>Math.abs(Math.abs(b.v)-Math.abs(l.valor))<=Math.max(1,0.01*Math.abs(l.valor));
  let c=base.filter(b=>nomeOk(b)&&valOk(b)&&b.ci>=li-6&&b.ci<=li+1);
  const sameM=c.filter(b=>b.ci===li);if(sameM.length)c=sameM;
  c.sort((a,b)=>Math.abs(a.ci-li)-Math.abs(b.ci-li));
  res.push({l,ch:s.chave,hit:c[0]||null,soNome:c.length?null:base.filter(b=>nomeOk(b)&&b.ci>=-3&&b.ci<=6).slice(0,3)});
}));
module.exports=res;
if(require.main===module){
  const f=x=>Math.round(x).toLocaleString('pt-BR');
  res.sort((a,b)=>Math.abs(b.l.valor)-Math.abs(a.l.valor)).forEach(x=>{
    const h=x.hit;
    console.log(x.l.mes,f(x.l.valor).padStart(7),x.ch.slice(0,30).padEnd(30),'|',h?('ERP '+h.comp+' '+f(h.v)+' | '+h.classe.slice(0,28)+' | '+h.conta.slice(0,32)+' | '+h.nomeOrig.slice(0,24)):'— não achado'+(x.soNome&&x.soNome.length?' (só nome: '+x.soNome.map(b=>b.comp+' '+f(b.v)+' '+b.nomeOrig.slice(0,18)).join('; ')+')':''));
  });
}
