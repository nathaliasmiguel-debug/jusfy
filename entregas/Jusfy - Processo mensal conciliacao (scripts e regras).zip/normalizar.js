// Passo 2: cada lançamento do razão vira uma linha com fornecedor, tipo e NF.
const fs = require('fs');
const path = require('path');
const R = require('./razao_bruto_jan_jun.json');

const GENERICO = /(Meio de Recebimento|Banco(?!\s+de\s+Dados)|Cart[ãa]o de Cr[ée]dito|Provis[ãa]o|a Pagar|Adiantamento|Dep\. Acumulada|Fopag|IRRF|ISS|PIS|COFINS|CSLL|INSS|Encerramento|Apura[çc][ãa]o|Resultado|Lucros|Caixa|Aplica[çc])/i;

function limpar(s) {
  return String(s || '')
    .replace(/_x000D_/gi, ' ').replace(/\r/g, ' ')
    .replace(/^\(\d{2}\/\d{2}\/\d{4}\)\s*/, '')
    .split(/\s-\s*PAGAMENTO CONFIRMADO|FORMA DE PAGAMENTO|CODIGO DE AUTENTICACAO/i)[0]
    .replace(/\s+\d\.\d\.\d\.\d{2}\.\d{3}\b.*$/, '')      // "NOME 4.1.2.01.003 - Desc"
    .replace(/\s+-\s*\d{2}\/\d{2}\/\d{4}.*$/, '')         // "NOME  - 25/05/2025"
    .replace(/^[\s-]+/, '')
    .replace(/^(?:PARC\.?\s*)?\d{1,3}\/\d{1,3}\s*-?\s*/i, '')
    .replace(/\s+\d{1,3}\/\d{1,3}$/, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function extrair(hist) {
  const ls = String(hist || '').split('\n').map(x => x.trim());
  const l1 = ls[0] || '';
  const l2 = (ls.length > 1 ? ls.slice(1).join(' ') : l1).trim();
  const m1 = l1.match(/^(\d+)\s*-\s*(.+)$/);
  const contrap = m1 ? m1[2].trim() : l1;
  const contrapEhFornecedor = m1 && !GENERICO.test(m1[2]);
  let nf = '';
  let nome = '';
  let m;

  if (/TARIFA E COMISS/i.test(l2)) { nome = 'OMIEXPERIENCE LTDA.'; }
  else if (/GERADO AUTOMATICAMENTE PELO OMIE/i.test(l2) && (m = l2.match(/\bPARA\s+(.+?)\s+\d{2}\s?\.?\d{3}/i))) { nome = m[1]; }
  else if ((m = l2.match(/^Estorno\s*-\s*(.+?)(?:\s*-\s*\d+)?$/i))) { nome = m[1]; }
  else if ((m = l2.match(/nota fiscal n[ºo°]\s*(\S*?)\s+do fornecedor\s+(.+)$/i))) { nf = m[1]; nome = m[2]; }
  else if ((m = l2.match(/nota fiscal n[ºo°]\s+(.+)$/i))) { nome = m[1]; }
  else if (/revers[ãa]o prov|estorno/i.test(l2) && contrapEhFornecedor) { nome = contrap; }
  else if ((m = l2.match(/^PAGAMENTO\s+(?:REF\.?\s+)?([A-Za-zÀ-ú][^]*?)\s+NF\b/i)) && !/^NF\b|^DE CONTA/i.test(m[1])) { nome = m[1]; }
  else if ((m = l2.match(/PARC\s*\d+\/\d+\s*-?\s*([A-Za-zÀ-ú].+)$/i))) { nome = m[1]; }
  else if ((m = l2.match(/PAGAMENTO DE CONTA A PAGAR.*?\d{2,3}\/\d{2,3}\s*-\s*(.+)$/i))) { nome = m[1]; }
  else if ((m = l2.match(/conforme fornecedor\s*(.+)$/i))) { nome = m[1]; }
  else if ((m = l2.match(/^PAGAMENTO\s+(?:REF\.?\s+)?(.+?)\s+NF\b/i))) { nome = m[1]; }
  else if ((m = l2.match(/^(?:D[ée]bito|Cr[ée]dito) em Conta Corrente\s+(.+?)(?:\s{2,}|$)/i))) { nome = m[1]; }
  else if ((m = l2.match(/^Conta (?:Paga|Recebida)\s+(.+?)(?:\s{2,}|$)/i))) { nome = m[1]; }
  else if ((m = l2.match(/^Provis[ãa]o de despesas? (?:com|p\/)\s+(.+?)(?:\s+-\s+Compet|$)/i))) { nome = m[1]; }
  else if ((m = l2.match(/^PAGAMENTO\s+(?:REF\.?\s+)?(.+)$/i))) { nome = m[1]; }
  else if (contrapEhFornecedor) { nome = contrap; }
  else { nome = l2 || l1; }

  if ((m = l2.match(/NF\s+([A-Z0-9]{3,})/i)) && !nf) nf = m[1];
  return { contrapartida: l1, nome: limpar(nome), nf };
}

function tipo(hist, contrapartida) {
  const h = String(hist);
  if (/revers[ãa]o prov/i.test(h)) return 'REVERSAO';
  if (/estorno/i.test(h)) return 'ESTORNO';
  if (/^930\s*-|Provis[ãa]o de Fornecedores/i.test(contrapartida) || /^\s*Provis[ãa]o/im.test(h.split('\n')[1] || '')) return 'PROVISAO';
  if (/Cart[ãa]o de Cr[ée]dito/i.test(contrapartida)) return 'CARTAO';
  if (/Banco(?!\s+de\s+Dados)/i.test(contrapartida)) return 'BANCO';
  if (/Fopag/i.test(h)) return 'FOLHA';
  if (/nota fiscal n[ºo°]\s*\S*\d/i.test(h)) return 'NF';
  const m1 = String(contrapartida).match(/^\d+\s*-\s*(.+)$/);
  if (m1 && !GENERICO.test(m1[1])) return 'NF';
  return 'OUTRO';
}

const SUFIXOS = /\b(LTDA|LTD|S\/?A|SA|EIRELI|ME|EPP|INC|LLC|CORP|CORPORATION|SOCIEDADE INDIVIDUAL DE ADVOCACIA|SERVICOS|SERVICO|DO BRASIL|BRASIL|DE|DA|DO|E|EM|PF)\b/g;
function chave(nome) {
  let s = String(nome).toUpperCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  s = s.replace(/^\d{1,3}(\.\d{3}){2}\s+/, '')     // "62.593.366 NOME"
       .replace(/\s\d{11}\b/g, '')                  // CPF colado
       .replace(/\s-?\s*#\d+/g, '')
       .replace(/[^A-Z0-9 ]/g, ' ')
       .replace(SUFIXOS, ' ')
       .replace(/\s+/g, ' ').trim();
  return s || String(nome).toUpperCase();
}

const out = [];
for (const [mes, contas] of Object.entries(R)) {
  for (const [conta, c] of Object.entries(contas)) {
    for (const l of c.lancamentos) {
      const e = extrair(l.historico);
      out.push({
        mes, conta, contaNome: c.nome, data: l.data,
        contrapartida: e.contrapartida, tipo: tipo(l.historico, e.contrapartida),
        nf: e.nf, fornecedor: e.nome, chave: chave(e.nome),
        debito: l.debito, credito: l.credito, valor: +(l.debito - l.credito).toFixed(2),
        historico: l.historico,
      });
    }
  }
}

// junta chaves em que uma é prefixo (por palavra) de exatamente uma outra mais longa
const chaves = [...new Set(out.map(o => o.chave))];
const alias = {};
for (const a of chaves) {
  const ta = a.split(' ');
  if (ta[0].length < 4) continue;
  const maiores = chaves.filter(b => b !== a && b.split(' ').length > ta.length && b.startsWith(a + ' '));
  if (maiores.length === 1) alias[a] = maiores[0];
}
out.forEach(o => { if (alias[o.chave]) o.chave = alias[o.chave]; });

fs.writeFileSync(path.join(__dirname, 'lancamentos.json'), JSON.stringify(out));
const tipos = {}; out.forEach(o => tipos[o.tipo] = (tipos[o.tipo] || 0) + 1);
console.log('lançamentos:', out.length, '| fornecedores distintos:', new Set(out.map(o => o.chave)).size, '| aliases unidos:', Object.keys(alias).length);
console.log('por tipo:', tipos);
