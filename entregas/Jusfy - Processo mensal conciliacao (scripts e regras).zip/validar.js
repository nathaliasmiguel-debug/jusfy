// Confere o Excel entregue contra a lista fixa de exigências da Nathalia. Lê o arquivo gerado e recalcula por fora.
const ExcelJS = require('exceljs');
const RG = require('./regras.js');
const L = require('./lancamentos.json');
const { M, ger, antes, notasG, pendG, grupoConta } = require('./metas.js');
const calcular = require('./selecao.js');
const { efeitos } = require('./selecao.js');
const arq = process.argv[2];
const falhas = [], oks = [];
const ok = (cond, msg) => (cond ? oks : falhas).push(msg);
// fórmula com resultado 0 volta sem o valor guardado (o Excel recalcula ao abrir): conta como 0
const val = c => (c && typeof c === 'object' && 'formula' in c ? (c.result === undefined ? 0 : c.result) : c);

(async () => {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile(arq);
  const nomes = wb.worksheets.map(w => w.name);
  const esperadas = ['Resumo', 'O QUE FAZER', 'Onde a Syhus erra', 'DRE Consolidado', ...M, 'Notas e pendências'];
  ok(JSON.stringify(nomes) === JSON.stringify(esperadas), 'abas na ordem: ' + nomes.join(', '));
  ok(wb.creator === 'Nathalia' && wb.lastModifiedBy === 'Nathalia', 'autor Nathalia');

  let erros = 0;
  wb.worksheets.forEach(ws => ws.eachRow(row => row.eachCell(c => { if (c.value && typeof c.value === 'object' && c.value.error) erros++; })));
  ok(erros === 0, 'erros de fórmula: ' + erros);

  // lançamentos escolhidos, recalculados por fora
  const { moves } = calcular({ C: 0.005, O: 0.005, T: 0.005 });
  const flat = require('./milp_out.json').escolhidos.flatMap(k => moves[k]);
  const ef = { C: M.map(() => 0), O: M.map(() => 0) };
  flat.forEach(a => efeitos(a).forEach(e => { ef[e.g][e.i] += e.v; }));

  // O QUE FAZER
  const qf = wb.getWorksheet('O QUE FAZER');
  const linhasQF = [];
  qf.eachRow((row, i) => { if (i > 4 && typeof row.getCell(1).value === 'number') linhasQF.push(row); });
  ok(linhasQF.length === flat.length, 'O QUE FAZER tem ' + linhasQF.length + ' lançamentos (esperado ' + flat.length + ')');
  const nomesRazao = new Set(L.map(l => l.fornecedor).filter(Boolean));
  const genericos = ['Hotels', 'Taxi', 'Meals', 'Supplies', 'Maintenance', 'Perdas', 'Linhas agregadas do P&L', 'CAPEX (sai da despesa)', 'Cursos e Treinamentos'];
  const foraRazao = linhasQF.filter(r => !nomesRazao.has(r.getCell(3).value)).map(r => r.getCell(3).value);
  ok(foraRazao.length === 0, 'fornecedor com nome do razão em todas as linhas' + (foraRazao.length ? ' — fora: ' + [...new Set(foraRazao)].join('; ') : ''));
  ok(!linhasQF.some(r => genericos.includes(r.getCell(3).value) || /\?/.test(r.getCell(3).value)), 'nenhum fornecedor genérico/linha do P&L/"?"');
  ok(linhasQF.every(r => r.getCell(5).value && r.getCell(6).value && r.getCell(5).value !== r.getCell(6).value), 'débito e crédito preenchidos e diferentes em todas as linhas');
  ok(linhasQF.every(r => typeof r.getCell(7).value === 'number' && r.getCell(7).value > 0), 'valor positivo em todas as linhas');
  ok(linhasQF.every(r => String(r.getCell(9).value || '').length > 20), 'prova escrita em todas as linhas');
  ok(!linhasQF.some(r => /COMPET[ÊE]NCIA 2025|2025/.test(String(r.getCell(4).value))), 'competência 2025 fora das ações');

  // abas de mês: totais = razão de hoje + ajustes recalculados
  M.forEach((m, i) => {
    const ws = wb.getWorksheet(m);
    let tC = null, tO = null, tT = null, somaConta = { D: 0, E: 0 }, somaForn = { D: 0, E: 0 };
    ws.eachRow((row, n) => {
      const c3 = row.getCell(3).value;
      if (c3 === 'TOTAL CUSTO (6.2)') tC = row; else if (c3 === 'TOTAL DESPESA (4.1)') tO = row; else if (c3 === 'TOTAL DO MÊS') tT = row;
      else if (c3 === 'TOTAL DA CONTA') { somaConta.D += val(row.getCell(4).value); somaConta.E += val(row.getCell(5).value); }
      else if (n > 4 && typeof row.getCell(4).value === 'number') { somaForn.D += row.getCell(4).value; somaForn.E += row.getCell(5).value || 0; }
    });
    const q = (a, b) => Math.abs(a - b) < 1;
    ok(q(val(tC.getCell(4).value), antes.C[i]) && q(val(tO.getCell(4).value), antes.O[i]), m + ': "como está" = razão de hoje (custo e despesa)');
    ok(q(val(tC.getCell(5).value), ef.C[i]) && q(val(tO.getCell(5).value), ef.O[i]), m + ': ajuste = soma dos lançamentos (custo e despesa)');
    ok(q(somaConta.D, somaForn.D) && q(somaConta.E, somaForn.E), m + ': subtotais das contas = soma dos fornecedores');
  });

  // Consolidado: cada fórmula aponta pro subtotal certo da aba do mês
  const dc = wb.getWorksheet('DRE Consolidado');
  let refs = 0, refsOk = 0;
  dc.eachRow(row => row.eachCell(c => {
    const f = c.value && c.value.formula; if (!f) return;
    const mm = /^'(\w+)'!([A-Z])(\d+)$/.exec(f); if (!mm) return;
    refs++; const alvo = wb.getWorksheet(mm[1]).getCell(mm[2] + mm[3]).value;
    if (Math.abs(val(alvo) - val(c.value)) < 1) refsOk++;
  }));
  ok(refs > 0 && refs === refsOk, 'Consolidado: ' + refsOk + '/' + refs + ' células puxam o valor certo das abas de mês');

  // Resumo: só a competência 2025 como nota; os três degraus batem com o recálculo; meta no degrau 3
  const rs = wb.getWorksheet('Resumo');
  const rotulos = []; rs.eachRow(row => rotulos.push(String(row.getCell(1).value || '')));
  ok(rotulos.filter(t => /NOTA EXPLICATIVA/.test(t)).length === 3 && !rotulos.some(t => /Pagar\.me|painel de pessoas × realizado/.test(t) && /\(−\)/.test(t) && /NOTA/.test(t)), 'Resumo: a única nota explicativa é a competência 2025');
  const linha = (bloco, rot) => { let em = false, achou = null; rs.eachRow(row => { const t = String(row.getCell(1).value || ''); if (t === bloco) em = true; else if (/^(CUSTO|DESPESA|TOTAL) \(/.test(t)) em = false; if (em && t === rot) achou = row; }); return achou; };
  [['C', 'CUSTO (contas 6.2)'], ['O', 'DESPESA (contas 4.1)'], ['T', 'TOTAL (custo + despesa)']].forEach(([g, bloco]) => {
    const G = i => (g === 'T' ? ger.C[i] + ger.O[i] : ger[g][i]);
    const dS = i => (g === 'T' ? ['C', 'O'].reduce((s, k) => s + antes[k][i] + ef[k][i] - ger[k][i] - notasG[k][i], 0) : antes[g][i] + ef[g][i] - ger[g][i] - notasG[g][i]);
    const dF = i => dS(i) - (g === 'T' ? pendG.C[i] + pendG.O[i] : pendG[g][i]);
    const r2 = linha(bloco, '2) Diferença DEPOIS DA SYHUS'), r3 = linha(bloco, '3) Diferença DEPOIS DAS PENDÊNCIAS DA JUSFY');
    ok(M.every((m, i) => Math.abs(r2.getCell(i + 2).value - dS(i)) < 1), bloco + ': degrau 2 bate com o recálculo');
    ok(M.every((m, i) => Math.abs(r3.getCell(i + 2).value - dF(i)) < 1), bloco + ': degrau 3 bate com o recálculo');
    ok(M.every((m, i) => Math.abs(dF(i) / G(i)) <= 0.005 + 1e-9), bloco + ': dentro de 0,5% em todos os meses depois das pendências (' + M.map((m, i) => (dF(i) / G(i) * 100).toFixed(2) + '%').join(' ') + ')');
  });

  console.log('OK (' + oks.length + '):'); oks.forEach(x => console.log('  ✓ ' + x));
  console.log('FALHAS (' + falhas.length + '):'); falhas.forEach(x => console.log('  ✗ ' + x));
  process.exit(falhas.length ? 1 : 0);
})();
