// Seleciona o menor conjunto de lançamentos (respeitando pares provisiona+baixa) que fecha a meta de 0,5% em todo mês.
const A = require('./achados.json'), Q = require('./quadro_dados.js');
const M = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'];
const r2 = x => Math.round(x * 100) / 100;
const LANCAVEL = a => !a.semLancar && a.tipo !== 'VERIFICAR' && !/^NOTA/.test(a.tipo);
const TOL = 0.005;

const RUBRICA_GENERICA = new Set(['Linhas agregadas do P&L', 'CAPEX (sai da despesa)']);

function calcular() {
  const moves = [];
  let excluidasSemFornecedor = 0;
  A.casos.forEach(c => {
    let acoesBrutas = c.acoes.filter(LANCAVEL).map(a => ({ ...a, entidade: c.nome, impactaTotal: a.tipo !== 'RECLASSIFICAR' || /^1\.2\.2/.test(a.contaPara) }));
    // "Linhas agregadas do P&L" e "CAPEX": o P&L não abre por fornecedor, então SÓ vale a ação se o razão prova o fornecedor real (via lanc).
    // Sem lanc = sem fornecedor identificado = não entra (nunca genérico, nunca "provisionar a diferença" sem prova).
    if (RUBRICA_GENERICA.has(c.bloco)) {
      const partidas = [];
      acoesBrutas.forEach(a => {
        const forns = [...new Set((a.lanc || []).map(l => l.fornecedor).filter(Boolean))];
        if (!forns.length) { excluidasSemFornecedor++; return; }
        if (forns.length === 1) { partidas.push({ ...a, entidade: forns[0] }); return; }
        // mais de um fornecedor no mesmo lançamento: separa por fornecedor (soma real das linhas de cada um)
        forns.forEach(f => {
          const linhasF = a.lanc.filter(l => l.fornecedor === f);
          const vAjustado = r2(linhasF.reduce((s, l) => s + l.valor, 0));
          partidas.push({ ...a, entidade: f, valor: vAjustado, lanc: linhasF, texto: a.texto + ' (' + f + ': R$ ' + Math.round(Math.abs(vAjustado)).toLocaleString('pt-BR') + ')' });
        });
      });
      acoesBrutas = partidas;
    }
    const acoes = acoesBrutas;
    const usados = new Set();
    const provBaixa = ['PROVISIONAR', 'BAIXAR PROVISÃO', 'REVERTER (NF adiantada)', 'COMPLEMENTAR PROVISÃO', 'REDUZIR PROVISÃO'];
    for (let i = 0; i < acoes.length; i++) {
      if (usados.has(i) || !provBaixa.includes(acoes[i].tipo)) continue;
      let par = -1;
      for (let j = i + 1; j < acoes.length; j++) {
        if (usados.has(j) || !provBaixa.includes(acoes[j].tipo)) continue;
        if (acoes[j].mes === acoes[i].mes) continue;
        if (Math.abs(Math.abs(acoes[j].valor) - Math.abs(acoes[i].valor)) <= 1 && Math.sign(acoes[j].valor) !== Math.sign(acoes[i].valor)) { par = j; break; }
      }
      if (par >= 0) { usados.add(i); usados.add(par); moves.push({ partes: [acoes[i], acoes[par]] }); }
    }
    acoes.forEach((a, i) => { if (!usados.has(i)) moves.push({ partes: [a] }); });
  });

  const g = {}, budget = {}, cum = {}, antes = {};
  M.forEach((m, i) => { g[m] = Q.ger[i]; budget[m] = r2(Q.ger[i] * TOL); cum[m] = 0; antes[m] = Q.antes[i]; });
  const gapAtual = m => r2(antes[m] + cum[m] - g[m]);
  const foraMeta = m => Math.abs(gapAtual(m)) > budget[m];

  let restantes = moves.slice();
  const escolhidos = [];
  while (M.some(foraMeta)) {
    let melhor = null, melhorScore = 0;
    for (const mv of restantes) {
      const meses = [...new Set(mv.partes.filter(p => p.impactaTotal).map(p => p.mes))];
      if (!meses.length) continue;
      let score = 0, pioraAlgum = false;
      for (const m of meses) {
        const antesGap = Math.abs(gapAtual(m));
        const efeito = mv.partes.filter(p => p.impactaTotal && p.mes === m).reduce((s, p) => s + p.valor, 0);
        const depoisGap = Math.abs(r2(antes[m] + cum[m] + efeito - g[m]));
        score += antesGap - depoisGap;
        if (!foraMeta(m) && depoisGap > budget[m]) pioraAlgum = true;
      }
      if (pioraAlgum) continue;
      if (score > melhorScore) { melhorScore = score; melhor = mv; }
    }
    if (!melhor || melhorScore <= 0) break;
    melhor.partes.forEach(p => { if (p.impactaTotal) cum[p.mes] = r2(cum[p.mes] + p.valor); });
    escolhidos.push(melhor);
    restantes = restantes.filter(mv => mv !== melhor);
  }

  const flat = escolhidos.flatMap(mv => mv.partes);
  const resumoMeses = M.map(m => ({ mes: m, ger: g[m], antes: antes[m], gapAntes: r2(antes[m] - g[m]), budget: budget[m], gapDepois: gapAtual(m), ok: !foraMeta(m) }));
  return { flat, resumoMeses, excluidasSemFornecedor, totalAcoesCompletas: A.casos.reduce((s, c) => s + c.acoes.filter(LANCAVEL).length, 0) };
}

module.exports = calcular;

if (require.main === module) {
  const { flat, resumoMeses, totalAcoesCompletas } = calcular();
  console.log('Mês  | gap hoje    | meta ±   | gap com a seleção | status');
  resumoMeses.forEach(r => console.log(r.mes.padEnd(4), '|', String(Math.round(r.gapAntes)).padStart(10), '| ±' + Math.round(r.budget), '|', String(Math.round(r.gapDepois)).padStart(8), r.ok ? 'OK' : 'FORA'));
  console.log('\nlançamentos selecionados:', flat.length, 'de', totalAcoesCompletas, 'no total');
  flat.sort((a, b) => M.indexOf(a.mes) - M.indexOf(b.mes) || Math.abs(b.valor) - Math.abs(a.valor))
    .forEach(a => console.log(a.mes, a.tipo.padEnd(22), String(Math.round(a.valor)).padStart(9), a.entidade.slice(0, 42)));
}
