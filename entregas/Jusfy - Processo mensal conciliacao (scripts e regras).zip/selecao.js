// Menor conjunto de lançamentos (sempre por fornecedor, com prova) que deixa o total, o CUSTO e a DESPESA
// dentro da tolerância contra o gerencial em todos os meses. Provisão + baixa do mesmo fornecedor em meses
// diferentes andam juntas (nunca meia operação).
const A = require('./achados.json');
const { explodir } = require('./explode_fornecedor.js');
const { M, r2, grupoConta, contaDaAcao, ger, antes, notasG } = require('./metas.js');

const LANCAVEL = a => !a.semLancar && a.tipo !== 'VERIFICAR' && !/^NOTA/.test(a.tipo) && a.tipo !== 'COMPETÊNCIA 2025';
const PROV = ['PROVISIONAR', 'BAIXAR PROVISÃO', 'REVERTER (NF adiantada)', 'COMPLEMENTAR PROVISÃO', 'REDUZIR PROVISÃO'];

function efeitos(a) {
  const i = M.indexOf(a.mes);
  if (a.tipo === 'RECLASSIFICAR') {
    const out = [], de = grupoConta(a.conta), para = grupoConta(a.contaPara);
    if (de) out.push({ g: de, i, v: -a.valor });
    if (para) out.push({ g: para, i, v: a.valor });
    return out;
  }
  const g = grupoConta(a.contaUsada);
  return g ? [{ g, i, v: a.valor }] : [];
}

function acoesLancaveis() {
  const todas = [], semForn = [];
  A.casos.forEach(c => {
    const brutas = c.acoes.filter(LANCAVEL).map(a => ({ ...a, entidade: c.nome, bloco: c.bloco, sublinhas: c.sublinhas, contaUsada: contaDaAcao(c, a) }));
    const { acoes, semFornecedor } = explodir(c.bloco, brutas);
    todas.push(...acoes);
    semForn.push(...semFornecedor);
  });
  return { todas, semForn };
}

function montarMoves(todas) {
  const moves = [], usados = new Set(), porEnt = {};
  todas.forEach((a, idx) => { (porEnt[a.entidade] = porEnt[a.entidade] || []).push(idx); });
  Object.values(porEnt).forEach(ids => {
    // par já definido (provisão/baixa provadas pelo ERP): anda junto com o seu par, e só com ele
    for (const i of ids) {
      if (usados.has(i) || !todas[i].par) continue;
      const j = ids.find(j => j !== i && !usados.has(j) && todas[j].par === todas[i].par);
      if (j !== undefined) { usados.add(i); usados.add(j); moves.push([todas[i], todas[j]]); }
    }
    for (const i of ids) {
      if (usados.has(i) || !PROV.includes(todas[i].tipo)) continue;
      if (todas[i].par) continue;
      const par = ids.find(j => j !== i && !usados.has(j) && !todas[j].par && PROV.includes(todas[j].tipo) && todas[j].mes !== todas[i].mes
        && Math.abs(Math.abs(todas[j].valor) - Math.abs(todas[i].valor)) <= 1 && Math.sign(todas[j].valor) !== Math.sign(todas[i].valor));
      if (par !== undefined) { usados.add(i); usados.add(par); moves.push([todas[i], todas[par]]); }
    }
  });
  todas.forEach((a, i) => { if (!usados.has(i)) moves.push([a]); });
  return moves;
}

// tol: { C: fração, O: fração, T: fração } (T = total custo+despesa)
function calcular(tol = { C: 0.005, O: 0.005, T: 0.005 }) {
  const { todas, semForn } = acoesLancaveis();
  const moves = montarMoves(todas);
  const mvEf = moves.map(mv => mv.flatMap(efeitos));
  const lim = { C: ger.C.map(v => v * tol.C), O: ger.O.map(v => v * tol.O), T: ger.C.map((v, i) => (v + ger.O[i]) * tol.T) };
  const base = { C: M.map((m, i) => antes.C[i] - ger.C[i] - notasG.C[i]), O: M.map((m, i) => antes.O[i] - ger.O[i] - notasG.O[i]) };
  const excesso = cum => {
    let s = 0;
    M.forEach((m, i) => {
      const gc = base.C[i] + cum.C[i], go = base.O[i] + cum.O[i];
      s += Math.max(0, Math.abs(gc) - lim.C[i]) + Math.max(0, Math.abs(go) - lim.O[i]) + Math.max(0, Math.abs(gc + go) - lim.T[i]);
    });
    return s;
  };
  const aplicar = (cum, k, sinal = 1) => { mvEf[k].forEach(e => { cum[e.g][e.i] += sinal * e.v; }); };
  const cum = { C: M.map(() => 0), O: M.map(() => 0) };
  let escolhidos = [];
  const livres = new Set(moves.map((mv, k) => k).filter(k => mvEf[k].length));
  let atual = excesso(cum);
  while (atual > 0.5) {
    let melhor = -1, melhorExc = atual - 0.5;
    for (const k of livres) { aplicar(cum, k); const e = excesso(cum); aplicar(cum, k, -1); if (e < melhorExc - 1e-6) { melhorExc = e; melhor = k; } }
    if (melhor < 0) break;
    aplicar(cum, melhor); escolhidos.push(melhor); livres.delete(melhor); atual = melhorExc;
  }
  // poda: tira o que ficou sobrando (menor valor primeiro) sem sair da tolerância
  const valorMove = k => moves[k].reduce((s, a) => s + Math.abs(a.valor), 0);
  let mudou = true;
  while (mudou) {
    mudou = false;
    for (const k of [...escolhidos].sort((a, b) => valorMove(a) - valorMove(b))) {
      aplicar(cum, k, -1);
      if (excesso(cum) <= atual + 1e-6) { escolhidos = escolhidos.filter(x => x !== k); livres.add(k); mudou = true; }
      else aplicar(cum, k);
    }
  }
  // troca 2→1: tenta substituir dois escolhidos por um livre
  let trocou = true;
  while (trocou) {
    trocou = false;
    const esc = [...escolhidos];
    fora: for (let x = 0; x < esc.length; x++) for (let y = x + 1; y < esc.length; y++) {
      aplicar(cum, esc[x], -1); aplicar(cum, esc[y], -1);
      for (const k of livres) {
        aplicar(cum, k);
        if (excesso(cum) <= atual + 1e-6) { escolhidos = escolhidos.filter(z => z !== esc[x] && z !== esc[y]).concat(k); livres.delete(k); livres.add(esc[x]); livres.add(esc[y]); trocou = true; break fora; }
        aplicar(cum, k, -1);
      }
      aplicar(cum, esc[x]); aplicar(cum, esc[y]);
    }
  }
  const flat = escolhidos.flatMap(k => moves[k]);
  const resumo = M.map((m, i) => {
    const o = { mes: m };
    ['C', 'O'].forEach(g => {
      const gd = base[g][i] + cum[g][i];
      o[g] = { ger: ger[g][i], antes: antes[g][i], notas: notasG[g][i], ajuste: r2(cum[g][i]), gapAntes: r2(base[g][i]), gapDepois: r2(gd), lim: r2(lim[g][i]), ok: Math.abs(gd) <= lim[g][i] + 0.5 };
    });
    const gt = o.C.gapDepois + o.O.gapDepois;
    o.T = { ger: r2(ger.C[i] + ger.O[i]), gapAntes: r2(base.C[i] + base.O[i]), gapDepois: r2(gt), lim: r2(lim.T[i]), ok: Math.abs(gt) <= lim.T[i] + 0.5 };
    return o;
  });
  return { flat, resumo, todas, semForn, moves, escolhidos, excessoFinal: atual };
}

module.exports = calcular;
module.exports.efeitos = efeitos;

if (require.main === module) {
  const cenarios = [
    ['só total 0,5%', { C: 9, O: 9, T: 0.005 }],
    ['total 0,5% + custo e despesa 1%', { C: 0.01, O: 0.01, T: 0.005 }],
    ['total 0,5% + custo e despesa 0,75%', { C: 0.0075, O: 0.0075, T: 0.005 }],
    ['custo e despesa 0,5% cada', { C: 0.005, O: 0.005, T: 0.005 }],
  ];
  const f = x => String(Math.round(x)).padStart(9);
  for (const [nome, tol] of cenarios) {
    const { flat, resumo, excessoFinal } = calcular(tol);
    console.log('\n=== ' + nome + ': ' + flat.length + ' lançamentos | sobra fora da meta: ' + Math.round(excessoFinal));
    const pct = (g) => resumo.map(r => ((r[g].gapDepois / r[g].ger) * 100).toFixed(2).padStart(8) + '%').join('');
    console.log('  custo   %', pct('C'));
    console.log('  despesa %', pct('O'));
    console.log('  total   %', pct('T'));
  }
}
