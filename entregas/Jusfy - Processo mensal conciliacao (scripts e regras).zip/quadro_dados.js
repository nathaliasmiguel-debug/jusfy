// Quadro mensal com a régua completa: P&L gerencial (fornecedores no escopo) + folha do painel People (salários, bônus, benefícios).
// Antes = razão operacional como está; Depois = razão com os ajustes lançáveis (todas.json). Composição = de onde vem a diferença que sobra.
const T = require('./todas.json'), L = require('./lancamentos.json'), RG = require('./regras.js');
const A = require('./achados.json');
const G0 = require('../extracted/dados/gerencial_fornecedor.json'), D = require('../extracted/dados/payroll_area_dashboard.json');
const M = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'], m3 = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun'];
const r2 = x => Math.round(x * 100) / 100;
const fora = r => RG.FORA_ESCOPO_SUBLINHA.has(r.sublinha) || RG.FORA_ESCOPO_FORNECEDOR.has(r.fornecedor.trim());
const dre = c => /^(4\.1|6\.2)/.test(c) && !RG.CONTAS_NAO_OPERACIONAIS.test(c);
const dreT = x => dre(x.conta) && !(/^4\.1\.5\./.test(x.conta) && !/PAGAR/i.test(x.entidade || ''));
const raz = L.filter(l => dre(l.conta) && !RG.naoOperacional(l));
const painel = i => ['SALARIES', 'BONUSES', 'BENEFITS'].reduce((s, c) => s + Object.values(D[c]).reduce((a, o) => a + ((o.monthly || {})[m3[i]] || 0), 0), 0);
const gerF = m => G0.filter(x => x.mes === m && !fora(x)).reduce((s, x) => s + x.valor, 0);

const ger = M.map((m, i) => r2(gerF(m) + painel(i)));
const antes = M.map(m => r2(raz.filter(l => l.mes === m).reduce((s, l) => s + l.valor, 0)));
const depois = M.map(m => r2(T.filter(x => x.mes === m && dreT(x)).reduce((s, x) => s + x.deve, 0)));

const acao = (m, f) => r2(A.casos.reduce((a, c) => a + c.acoes.filter(x => x.mes === m && f(x)).reduce((b, x) => b - x.valor, 0), 0));
const pagarme = M.map(m => acao(m, x => /^NOTA/.test(x.tipo)));
const verif = M.map(m => acao(m, x => x.tipo === 'VERIFICAR'));
const semPar = M.map(m => r2(A.semParCasos.reduce((a, s) => a + (s.razMes[m] || 0), 0)));
const folha = M.map((m, i) => r2(A.casos.filter(c => /^Folha/.test(c.bloco)).reduce((a, c) => a + (c.alvoMes[m] || 0), 0) - painel(i)));
const gerSemRazao = M.map(m => r2(-(gerF(m) - A.casos.filter(c => /Fornecedores|Linhas/.test(c.bloco)).reduce((a, c) => a + (c.alvoMes[m] || 0), 0))));
const dif = M.map((m, i) => r2(depois[i] - ger[i]));
const resto = M.map((m, i) => r2(dif[i] - pagarme[i] - verif[i] - semPar[i] - folha[i] - gerSemRazao[i]));

module.exports = {
  ger, antes, depois,
  composicao: [
    ['Pagar.me: taxas que o P&L tem e o razão de despesa não tem (nota)', pagarme, 'nota'],
    ['Folha: base de distratos/ERP × painel People (jun: 6 distratos fora do P&L) (nota)', folha, 'nota'],
    ['A mais no razão sem prova — pedir NF (aba 6)', verif, 'pend'],
    ['Razão sem par no gerencial — classificar (aba 7)', semPar, 'pend'],
    ['P&L sem lançamento correspondente no razão', gerSemRazao, 'pend'],
    ['Arredondamento (até R$ 50 por fornecedor/mês)', resto, ''],
  ],
};
if (require.main === module) {
  const f = x => Math.round(x).toLocaleString('pt-BR').padStart(11);
  console.log('ger    ', ger.map(f).join(''));
  console.log('depois ', depois.map(f).join(''));
  module.exports.composicao.forEach(([n, v]) => console.log(n.slice(0, 40).padEnd(40), v.map(f).join('')));
}
