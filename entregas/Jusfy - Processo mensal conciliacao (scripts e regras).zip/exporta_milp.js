// Exporta os lançamentos possíveis (movimentos atômicos) e a régua pro otimizador exato (otimo.py).
// Além de total/custo/despesa por mês, exporta a regra "nunca piorar": por fornecedor(caso) × mês × grupo, a distância
// até o P&L depois dos lançamentos escolhidos não pode ser maior que antes.
const fs = require('fs');
const A = require('./achados.json');
const calcular = require('./selecao.js');
const { efeitos } = require('./selecao.js');
const { M, grupoConta, contaDaAcao, ger, antes, notasG, pendG } = require('./metas.js');
const tol = { C: +(process.argv[2] || 0.005), O: +(process.argv[3] || 0.005), T: +(process.argv[4] || 0.005) };
const nuncaPiorar = process.argv[5] !== 'livre';
const { moves } = calcular(tol);
const ef = moves.map(mv => { const e = { C: M.map(() => 0), O: M.map(() => 0) }; mv.flatMap(efeitos).forEach(x => { e[x.g][x.i] += x.v; }); return e; });
// régua da Syhus: diferença depois de tirar a nota (competência 2025) e as pendências da Jusfy (que a Syhus não resolve sozinha)
const base = { C: M.map((m, i) => antes.C[i] - ger.C[i] - notasG.C[i] - pendG.C[i]), O: M.map((m, i) => antes.O[i] - ger.O[i] - notasG.O[i] - pendG.O[i]) };
const lim = { C: ger.C.map(v => v * tol.C), O: ger.O.map(v => v * tol.O), T: ger.C.map((v, i) => (v + ger.O[i]) * tol.T) };

// distância por caso × mês × grupo antes dos lançamentos (alvo no grupo da conta certa; competência 2025 fica, então entra no alvo)
const r0 = {};
const key = (c, i, g) => c + '|' + i + '|' + g;
A.casos.forEach(c => {
  const gp = grupoConta(c.contaPadrao);
  M.forEach((m, i) => ['C', 'O'].forEach(g => { const d = (c.alvoDistrato || {})[m] || 0; r0[key(c.nome, i, g)] = -((g === gp ? (c.alvoMes[m] || 0) - d : 0) + (g === 'O' ? d : 0)); }));
  c.lancamentos.forEach(l => { const g = grupoConta(l.conta); if (g) r0[key(c.nome, M.indexOf(l.mes), g)] += l.valor; });
  c.acoes.filter(a => a.tipo === 'COMPETÊNCIA 2025').forEach(a => { const g = grupoConta(contaDaAcao(c, a)); if (g) r0[key(c.nome, M.indexOf(a.mes), g)] -= -a.valor; });
});
const linhasCaso = {}; // key -> {k: efeito}
moves.forEach((mv, k) => mv.forEach(a => efeitos(a).forEach(e => {
  const kk = key(a.rubricaOriginal || a.entidade, e.i, e.g);
  (linhasCaso[kk] = linhasCaso[kk] || {})[k] = ((linhasCaso[kk] || {})[k] || 0) + e.v;
})));
const pior = nuncaPiorar ? Object.entries(linhasCaso).map(([kk, efs]) => ({ r0: r0[kk] || 0, efs })) : [];
// erro com prova clara entra sempre: lançamento em dobro, provisão que nunca foi baixada, MDR da Pagar.me
const FORCA = process.env.SEM_FORCA ? [] : ['EXCLUIR DUPLICADO', 'ESTORNAR PROVISÃO', 'LANÇAR MDR PAGAR.ME'];
// só força o que também aproxima o fornecedor do P&L (se afasta, o próprio P&L diz que o valor é devido: não é erro claro)
const aproxima = k => Object.entries(linhasCaso).every(([kk, efs]) => { const e = efs[k]; if (!e) return true; const r = r0[kk] || 0; return Math.abs(r + e) <= Math.abs(r) + 1; });
const candidatos = moves.map((mv, k) => (mv.some(a => FORCA.includes(a.tipo)) ? k : -1)).filter(k => k >= 0);
// NF em outro mês provada pelo ERP (aplica_erp.js já conferiu que aproxima o fornecedor do P&L): entra sempre
const provadosERP = process.env.SEM_FORCA ? [] : moves.map((mv, k) => (mv.some(a => a.erp) ? k : -1)).filter(k => k >= 0);
const forcados = [...new Set([...candidatos.filter(aproxima), ...provadosERP])];
const naoForcados = candidatos.filter(k => !aproxima(k));
fs.writeFileSync('forca_revisar.json', JSON.stringify(naoForcados.map(k => moves[k].map(a => ({ tipo: a.tipo, mes: a.mes, entidade: a.entidade, valor: a.valor, texto: a.texto }))), null, 1));
// onde há erro obrigatório, a correção do erro manda: a regra "nunca piorar" vale nos demais fornecedor×mês
const tocados = new Set(Object.entries(linhasCaso).filter(([kk, efs]) => forcados.some(k => efs[k])).map(([kk]) => kk));
const piorFinal = nuncaPiorar ? Object.entries(linhasCaso).filter(([kk]) => !tocados.has(kk)).map(([kk, efs]) => ({ r0: r0[kk] || 0, efs })) : [];
fs.writeFileSync('milp_in.json', JSON.stringify({ n: moves.length, peso: moves.map(mv => mv.length), ef, base, lim, pior: piorFinal, forcados }));
console.log('movimentos:', moves.length, '| regras "nunca piorar":', pior.length, '| obrigatórios:', forcados.length, '| erro claro que afasta do P&L (não forçado):', naoForcados.length);
