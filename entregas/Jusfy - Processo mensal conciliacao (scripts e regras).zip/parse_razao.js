const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');

const FILES = {
  Jan: '/root/.claude/uploads/adeaa6d4-ddd2-5fcc-b36b-6b40321dd771/5bb9b84d-Raz_o01.xlsx',
  Fev: '/root/.claude/uploads/adeaa6d4-ddd2-5fcc-b36b-6b40321dd771/3fb62502-Raz_o02.xlsx',
  Mar: '/root/.claude/uploads/adeaa6d4-ddd2-5fcc-b36b-6b40321dd771/481e85fd-Raz_o03.xlsx',
  Abr: '/root/.claude/uploads/adeaa6d4-ddd2-5fcc-b36b-6b40321dd771/6c6831ca-Raz_o04.xlsx',
  Mai: '/root/.claude/uploads/adeaa6d4-ddd2-5fcc-b36b-6b40321dd771/82c78bdd-Raz_o05.xlsx',
  Jun: '/root/.claude/uploads/adeaa6d4-ddd2-5fcc-b36b-6b40321dd771/13ee7c5e-Raz_o06.xlsx',
};

function extrairFornecedor(historico) {
  if (!historico) return '(sem histórico)';
  const h = String(historico).replace(/_x000D_/g, ' ').replace(/\r/g, '\n');
  const linhas = h.split('\n').map(s => s.trim()).filter(Boolean);

  // padrão: "nota fiscal nº <n> (do fornecedor )?NOME"
  let m = h.match(/nota fiscal n[ºo]\s*\d*\s*(?:do fornecedor\s+)?([A-ZÀ-Ú][A-ZÀ-Ú0-9 .&,\-\/]{3,80})/i);
  if (m) return m[1].trim().replace(/\s+/g, ' ');

  // padrão cartão: "PAGAMENTO NF <n> PARC xxx/yyy NOME" ou "PAGAMENTO NOME NF <n> PARC xxx/yyy"
  m = h.match(/PAGAMENTO\s+NF\s*\S*\s*(?:FATURA\s*)?(?:PARC\s*\d+\/\d+\s*)?([A-ZÀ-Ú][A-ZÀ-Ú0-9 .&,\-\/]{3,80})$/im);
  if (m) return m[1].trim().replace(/\s+/g, ' ');

  // segunda linha do histórico (formato "código - Conta bancária\nDESCRIÇÃO ... NOME ...")
  if (linhas.length >= 2) {
    let seg = linhas[1];
    // remove sufixos de forma de pagamento / código de autenticação
    seg = seg.split(/PAGAMENTO CONFIRMADO|FORMA DE PAGAMENTO|CODIGO DE AUTENTICACAO/i)[0].trim();
    if (seg.length > 2) return seg.replace(/\s+/g, ' ').slice(0, 100);
  }
  return linhas[0] ? linhas[0].slice(0, 100) : '(sem histórico)';
}

function excelSerialToDate(s) {
  if (typeof s !== 'number') return null;
  const d = new Date((s - 25569) * 86400 * 1000);
  return d;
}

function parseRazao(filePath, mesNome) {
  const wb = XLSX.readFile(filePath);
  const ws = wb.Sheets[wb.SheetNames[0]];
  const data = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });

  const contas = {}; // codigo -> {nome, lancamentos:[{data,historico,fornecedor,debito,credito,valor}], totalMesDeb, totalMesCred}
  let contaAtual = null;

  for (let i = 0; i < data.length; i++) {
    const r = data[i];
    const c0 = String(r[0] || '').trim();
    const c1 = r[1];
    const c2 = String(r[2] || '').trim();

    if (c0 === 'Conta:') {
      const codigo = c2;
      const nome = String(r[5] || r[4] || '').trim();
      contaAtual = codigo;
      if (!contas[codigo]) contas[codigo] = { nome, lancamentos: [], totalMesDeb: 0, totalMesCred: 0 };
      continue;
    }
    if (!contaAtual) continue;

    // linha "Total do mês:"
    const c6 = String(r[6] || '').trim();
    if (c6 === 'Total do mês:') {
      contas[contaAtual].totalMesDeb = Number(r[8]) || 0;
      contas[contaAtual].totalMesCred = Number(r[9]) || 0;
      continue;
    }
    if (c0 === '' && String(r[4] || '').trim() === 'Total da conta:') continue;
    if (c2 === 'SALDO ANTERIOR') continue;

    // linha de lançamento real: coluna A = data (serial numérico) ou vazio, coluna C = histórico
    const historico = String(r[2] || '').trim();
    const debito = Number(r[8]) || 0;
    const credito = Number(r[9]) || 0;
    if (!historico && !debito && !credito) continue;
    if (/encerramento do exerc[ií]cio|zeramento/i.test(historico)) continue;
    if (!debito && !credito) continue;

    const fornecedor = extrairFornecedor(historico);
    contas[contaAtual].lancamentos.push({
      data: r[0], historico, fornecedor, debito, credito, valor: debito - credito,
    });
  }

  return contas;
}

const resultado = {};
for (const [mes, file] of Object.entries(FILES)) {
  console.log('parsing', mes, '...');
  resultado[mes] = parseRazao(file, mes);
}

fs.writeFileSync(path.join(__dirname, 'razao_bruto_jan_jun.json'), JSON.stringify(resultado));
console.log('salvo razao_bruto_jan_jun.json');

// sanity check: comparar total por conta (soma dos lancamentos) com o "Total do mes" declarado no arquivo
let okCount = 0, mismatchCount = 0;
const mismatches = [];
Object.entries(resultado).forEach(([mes, contas]) => {
  Object.entries(contas).forEach(([codigo, c]) => {
    const somaDeb = c.lancamentos.reduce((a, l) => a + l.debito, 0);
    const somaCred = c.lancamentos.reduce((a, l) => a + l.credito, 0);
    const diffDeb = Math.abs(somaDeb - c.totalMesDeb);
    const diffCred = Math.abs(somaCred - c.totalMesCred);
    if (diffDeb > 1 || diffCred > 1) {
      mismatchCount++;
      mismatches.push({ mes, codigo, nome: c.nome, somaDeb, totalMesDeb: c.totalMesDeb, somaCred, totalMesCred: c.totalMesCred });
    } else okCount++;
  });
});
console.log('contas OK (bateu com Total do mês):', okCount, '| contas com diferença:', mismatchCount);
mismatches.slice(0, 15).forEach(m => console.log(JSON.stringify(m)));
