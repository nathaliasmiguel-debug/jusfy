// Regras fixas do processo mensal (guardar e reusar todo mês).
// Fonte: "Árvore Oficial do DRE" (depara_contas_gerais) com 5.2.1.x renomeado para 6.2.1.x.

// Sublinha do P&L -> contas contábeis onde o gasto pode estar (a 1ª é a conta padrão).
const CONTAS_DA_SUBLINHA = {
  'Legal Data Enrichment Services': ['6.2.1.03.003'],
  'Legal Data APIs': ['6.2.1.03.003'],
  'I.T. Infraestructure': ['6.2.1.03.001', '6.2.1.03.004'],
  'Engineering & Technology Software': ['6.2.1.03.002'],
  'Electronic Signature Platforms': ['6.2.1.03.002'],
  'JusTraker Expenses': ['6.2.1.03.001', '6.2.1.03.002', '6.2.1.03.003'],
  'Other Product Expenses': ['6.2.1.03.002', '6.2.1.03.004'],
  'Product Testing': ['6.2.1.03.002'],
  'Payment Processing Fees': ['6.2.1.01.003', '4.1.5.01.003'],
  'Partnerships': ['4.1.3.01.005'],
  'Offline Advertising': ['4.1.3.01.001'],
  'Travel Expenses': ['4.1.2.04.001', '4.1.2.04.002', '4.1.2.04.003', '4.1.2.04.004', '4.1.2.04.005', '4.1.2.04.007'],
  'CX & Support Software': ['4.1.2.01.003'],
  'Marketing Software': ['4.1.2.01.003'],
  'Product Development Tools': ['4.1.2.01.003'],
  'General Productivity Software': ['4.1.2.01.003'],
  'Analytics Software': ['4.1.2.01.003'],
  'Finance & Accounting Software': ['4.1.2.01.003'],
  'Office Rent': ['4.1.2.02.001'],
  'Events': ['4.1.2.05.007', '4.1.8.09.001', '4.1.8.09.002'],
  'BAR Associations': ['4.1.2.01.003', '4.1.3.01.001', '4.1.2.05.007', '4.1.2.04.001', '4.1.2.04.005'],
  'Accounting & Audit Services': ['4.1.6.01.001'],
  'CX Strategy Consulting': ['4.1.6.01.002', '4.1.6.01.008'],
  'Management Consulting Services': ['4.1.6.01.002', '4.1.6.01.008'],
  'Legal & Corporate Services': ['4.1.6.01.003', '4.1.2.05.005'],
  'Public Relations & Image Services': ['4.1.6.01.005'],
  'Other CX & Support Expenses': ['4.1.2.01.001'],
  'Other Administrative Services': ['4.1.6.01.008', '4.1.2.02.005', '4.1.2.05.003', '4.1.2.01.001', '4.1.2.01.002',
    '4.1.2.02.002', '4.1.2.02.004', '4.1.2.05.001', '4.1.2.05.002', '4.1.2.05.008', '4.1.2.05.009', '4.1.4.01.001',
    '4.1.4.01.002', '4.1.4.01.004', '4.1.4.02.002', '4.1.4.03.001', '4.1.8.09.004', '4.1.8.09.005', '4.1.9.01.002'],
  'Other Financial Expenses': ['4.1.5.01.001', '4.1.5.01.002', '4.1.5.01.003', '4.1.5.01.006'],
};

// Plataformas de mídia casam por CONTA, não por nome (razão social ≠ nome gerencial).
const ADS = {
  'Google Ads': '4.1.3.01.002', 'Facebook Ads': '4.1.3.01.003', 'TikTok Ads': '4.1.3.01.004',
  'Microsoft Ads': '4.1.3.01.006', 'Reddit Ads': '4.1.3.01.007', 'LinkedIn Ads': '4.1.3.01.008',
  'Linkedin Ads': '4.1.3.01.008', 'X/Twitter Ads': '4.1.3.01.009',
};

// De-para de nome confirmado pela Controladoria (gerencial -> chave do razão).
const ALIAS = {
  'Messaging & Live Chat': ['TREBLE AI DIGITAIS'],
  'Treble.AI': ['TREBLE AI DIGITAIS'],
  'Rafael Candia': ['CAPI CANDIA CURSOS', 'RAFAEL CANDIA JOSE'],
  'Microsoft Ads': ['MICROSOFT IMPORTACAO COMERCIO SOFTWARE VIDEO GAMES'], // confirmado pela Nathália: é Ads, não SaaS
  'Microsoft Office': ['PPRO MICROSOFT'],
  'Microsoft (Engenharia)': ['PPRO MICROSOFT'],
  'GCP Cloud': ['GOOGLE CLOUD COMPUTACAO DADOS'],
  'GCP AI': ['GOOGLE CLOUD COMPUTACAO DADOS'],
  'Sede Nova = CDL?': ['CAMARA DIRIGENTES LOJISTAS SANTA MARIA'],
  'Google Suite': ['GOOGLE CLOUD COMPUTACAO DADOS'], // Workspace faturado pela Google Cloud: razão jan/fev R$8.934/R$8.759 x Suite R$8.430/R$8.506 (GCP ~R$150)
  'ELIZABETH': ['ELISABETE SILVA PULHESE'], // por evidência: nome + R$2.000/mês + Serviços de Limpeza — confirmar
  'Aluguel CPD FLN - Castelbras': ['CASTELBRAS DESIGN COMUNICACAO TECNOLOGIA'], // histórico: 533 - CASTELBRAS, R$2.000/mês
  'JESSICA ABREU - INSTITUTO NACIONAL DE DIREITO BANCARIO (INDB)': ['INSTITUTO NACIONAL DIREITO BANCARIO'], // mai R$6.200 exato
  '2CO.COM|WINGIFY': ['WINGIFY'], // R$13.226,53 exato
  'Ava Brasil Educacao e Tecnologia Ltda': ['AVA TREINAMENTOS MENTORIAS', 'AVA EDUCACAO TECNOLOGIA'], // ~R$20k/mês + ~R$1k/mês = valor do gerencial
  'TIMEWORK': ['TIMEWORK', 'WEWORK'], // jan-fev Timework, mar-jun WeWork: valores idênticos ao gerencial
  'ERP Software - Omie': ['OMIEXPERIENCE', 'NOSSO NUMERO DESPESAS COM SOFTWARE OMIEXPERIENCE', 'DESPESAS COM SOFTWARE FIXED DUEDATE OMIEXPERIENCE'],
  'ACONCAIA': ['RECH LONGO'], // R$9.916 idêntico em mai; jan-abr R$9.767 x R$9.916 todo mês
  'Pacote Adobe': ['ADOBE'],
  // provados pela base financeira (ERP): mesmo fornecedor, valor e competência
  'Números telefone Salvy': ['SALVY', 'IG SALVY', 'G SALVY'],
  'Pagar.me': ['PAGAR INSTITUICAO PAGAMENTO S A', 'PAGAR PAGAMENTOS', 'PAGAR TARIFAS BANCARIAS', 'PAGAR LINK 001 001 PAGARME S', 'PAGARME PAGAMENTOS'],
  'ANTHROPIC CLAUDE TEAM': ['ANTHROPIC CLAUDE TEAM', 'CLAUDE AI SUBSCRIPTION', 'NF FATURA CLAUDE AI SUBSCRIPTION', 'ANTHROPICT'],
  'GODADDY BRASIL': ['NT 001 001 GODADDY', 'NF FATURA GODADDY ONLINE'],
  'MOBBIN.COM': ['MOBBIN COM', 'MOBBIN COM PARCELA'],
  'RR CURSOS JURIDICOS': ['RR DIGITAIS'],
  // Fornecedor trocado (A CONFIRMAR): o gerencial separa em 2 fornecedores o que o razão lança num só.
  'ROLE FILMES': ['ZEE FILMS PRODUCOES'], // Offline Advertising: ZEE NF 10 (mai) R$74.800 = ZEE jun R$39.780 + ROLE mai R$34.850 (dif. R$170); razão não tem nenhuma linha ROLE
  'Junqueira e Candia Advocacia': ['VITORIA CANDIA JUNQUEIRA CANDIA ADVOCACIA', 'CAPI CANDIA CURSOS'], // Partnerships: CAPI emite NFs de R$2.500 (26,27,30,31) fora da série de R$25.000; o razão não tem NF da Junqueira
  'HubSpot': ['HUBSPOT', 'NEXFORCE HUBSPOT'],
  'Viagens OAB': ['ORDEM DOS ADVOGADOS SECCAO SAO PAULO'],
  'COMISSÃO OAB': ['ORDEM DOS ADVOGADOS SECCAO SAO PAULO'],
  'Patronicio OAB': ['ORDEM DOS ADVOGADOS SECCAO SAO PAULO'],
};

// Linhas do gerencial que NÃO são fornecedor (rubrica agregada): casam pela conta, com o que sobrar nela.
// Fornecedores do razão que o ERP classifica numa linha agregada do P&L (prova: base financeira, mesmo valor e competência)
const RUBRICA_FORNECEDOR = {
  'Processos Judiciais - Clientes': ['PODER JUDICIARIO ESTADO RIO', 'RODRIGUES LEMES ADVOGADOS'],
  'Hotels': ['SERRA CANELA HOTEL', 'HOTELARIA POA'],
  'Taxi': ['JULIANO OLIVEIRA COSTA'],
  'Telephony and Internet': ['AVATO TECNOLOGIA', 'RVT TELECOMUNICACOES'],
  'Supplies': ['HIPERSUL PRODUTOS LIMPEZA', 'JRP INDUSTRIA COM BEB'],
  'Eventos + Brindes': ['OLADA PRODUCOES AUDIOVISUAIS'],
  'Other Executive Leadership-related Suppliers': ['DOACAO CONFORME RECIBO N 34727'],
  'Various Equipment': ['PIX ENVIADO PARA RAFAEL CANDIA'],
};
// Linhas do razão que o ERP registra com competência 2025 (prova: base financeira)
const ERP_2025 = [
  { re: /^CARTAO CONTA SIMPLES INFINITY/, prova: 'ERP: Cartão Conta Simples Infinity R$ 1.633 competência 12/2025' },
  { re: /^ANITA MENDOZA/, prova: 'ERP: Anita Mendoza Branquinho R$ 50 competência 12/2025' },
];
const RUBRICAS = {
  'Hotels': ['4.1.2.04.005'], 'Airline and Bus Tickets': ['4.1.2.04.001'], 'Taxi': ['4.1.2.04.003', '4.1.2.04.004', '4.1.2.04.007'],
  'Meals': ['4.1.2.04.002'], 'Eventos + Brindes': ['4.1.2.05.007', '4.1.8.09.001', '4.1.8.09.002'],
  'Supplies': ['4.1.2.02.004', '4.1.2.05.001', '4.1.2.05.003'], 'Telephony and Internet': ['4.1.2.01.001'],
  'Electrical Energy': ['4.1.2.02.002'], 'Maintenance': ['4.1.2.02.005'], 'Tax suppliers': ['4.1.4.01.001', '4.1.4.01.002', '4.1.4.01.004', '4.1.4.02.002', '4.1.4.03.001'],
  // Perdas: 4.1.8.10.002 = estornos a clientes (ERP: classe 2.2 Estornos à clientes)
  'Perdas': ['4.1.9.01.002', '4.1.8.10.002'], 'Processos Judiciais - Clientes': ['4.1.8.09.004', '4.1.8.09.005'],
  'Various Equipment': ['4.1.2.01.002'], 'Other Executive Leadership-related Suppliers': ['4.1.8.09.003', '4.1.2.05.002']
};

// Fora do escopo desta conciliação (não são despesa no razão de resultado ou têm base própria).
const FORA_ESCOPO_FORNECEDOR = new Set(['Contas Morgan LCC', 'Contas Morgan']);
const FORA_ESCOPO_SUBLINHA = new Set(['Stock Buyback', 'Fintech Expenses', 'IT Equipment & Computers', 'Furniture & Fixtures', 'Contas Morgan', 'Other Marketing Expenses', 'Other Financial Expenses']);
const MOTIVO_FORA = {
  'Stock Buyback': 'Recompra de participação — não é despesa operacional.',
  'Fintech Expenses': 'POCs Fintech ficam em contas de ativo (1.1.9.01.x), não no razão de resultado.',
  'IT Equipment & Computers': 'CAPEX (1.2.2.01.x) — imobilizado, não despesa.',
  'Furniture & Fixtures': 'CAPEX (1.2.2.01.x) — imobilizado, não despesa.',
  'Contas Morgan': 'Conta no exterior sem lançamento no razão da Jusfy Brasil.',
  'Other Financial Expenses': 'Despesa financeira (pós-EBITDA) — conciliada à parte.',
  'Other Marketing Expenses': 'No P&L é linha própria sem realizado; a base extraída repetia as filhas de BAR Associations.',
};

// Contas de folha: conciliadas por PESSOA contra o Realizado ERP + Cadastro, não contra o P&L por fornecedor.
const CONTAS_FOLHA = new Set(['4.1.6.01.007', '6.2.1.01.001', '4.1.1.01.001', '4.1.1.01.003', '4.1.1.01.005',
  '4.1.6.02.001', '4.1.6.02.002', '4.1.6.02.003', '4.1.6.02.004', '4.1.6.02.005', '4.1.6.02.006', '4.1.6.02.007', '6.2.1.02.004']);

// Contas que não são despesa real (conta de passagem / encerramento): o saldo tem que ir para a conta do fornecedor.
const CONTAS_PASSAGEM = { '4.1.2.05.011': 'Mera importação', '4.1.2.04.006': 'Estacionamento (usada como passagem em abr)', '4.1.8.10.001': 'Despesas indedutíveis' };

// Contas fora do comparativo com o P&L operacional (impostos, depreciação, financeiras não operacionais).
const CONTAS_NAO_OPERACIONAIS = /^4\.1\.2\.05\.004$/; // depreciação
// linha fora do DRE operacional: depreciação e financeiras (IOF, juros, tarifas, multas) — Pagar.me fica (é custo de transação no P&L)
const naoOperacional = l => CONTAS_NAO_OPERACIONAIS.test(l.conta) || (/^4\.1\.5\./.test(l.conta) && !/PAGAR/.test(l.chave));

// PJ com nome de empresa diferente do Cadastro: vínculo provado por valor mensal idêntico ao Realizado ERP.
const VINCULO_PJ = {
  'DKSWEB': { pessoa: 'Deyvid Kenid da Silva', evidencia: 'R$26.000 idêntico ao ERP em jan-jun (6 meses)' },
  'DRF INFORMATICA': { pessoa: 'Dailton Rodrigues de Carvalho Filho', evidencia: 'R$10.000 idêntico ao ERP em 5 meses; iniciais DRF' },
  'HAGROEX': { pessoa: 'Hugo Bretz Cabral Hennies', evidencia: 'mai R$17.000 e jun R$15.000 idênticos ao ERP' },
  'ROCHA CASTANHA': { pessoa: 'Clarissa Castanha', evidencia: 'fev-mar R$22.937 idênticos ao ERP; sobrenome Castanha' },
  'LAB CONSULTORIA ORGANIZACAO EVENTOS': { pessoa: "Emanuela Yamara Sampaio de Araujo Sant'Ana", evidencia: 'jan R$44.610 idêntico ao ERP' },
  'LAB GESTAO SOLUCOES EMPRESARIAIS': { pessoa: "Emanuela Yamara Sampaio de Araujo Sant'Ana", evidencia: 'jun idêntico ao ERP; mesma LAB de jan' },
  'JMR SOLUCOES DIGITAIS': { pessoa: 'Jéssica Montardo Rosado', evidencia: 'iniciais JMR; mai R$3.000 idêntico ao ERP' },
};

// Diferenças estruturais já conhecidas: viram nota explicativa, não ajuste de lançamento.
const GAP_CONHECIDO = {
  'Pagar.me': 'O contábil registra só a parte faturada da taxa; o MDR retido na liquidação não passa pelo razão de despesa. Diferença recorrente conhecida — definir com a Syhus antes de lançar.',
};

// Ajustes confirmados pela Controladoria: aplicados na linha exata do razão.
const CONFIRMADOS = [
  { re: /VILA VENTURA/, mes: 'Fev', valorLinha: 40000, tipo: 'EXCLUIR DUPLICADO', valor: -40000,
    texto: 'Linha de R$ 40.000 "conforme fornecedor Vila Ventura" (Confraternização) é adiantamento lançado como despesa: a NF 872 já cobre o evento. Baixar o adiantamento contra o fornecedor, não contra despesa. (Confirmado pela Controladoria: R$40k pagos em 2025 + R$40k de adiantamento em jan com NF emitida em fev.)' },
  { re: /VILA VENTURA/, mes: 'Fev', valorLinha: 179504, tipo: 'COMPETÊNCIA 2025', valor: -40000,
    texto: 'Da NF 872 (R$ 179.504, offsite de fevereiro), R$ 40.000 foram pagos e reconhecidos no gerencial em 2025 (confirmado pela Controladoria). É competência 2025: sai da despesa de 2026.' },
];

// Linha do razão de 2026 que carrega data de 2025 no histórico: baixa de adiantamento de 2025, NF/estorno de NF de 2025
// ou ajuste de "exercício anterior". Não é despesa de 2026 (cartão parcelado fica de fora: a parcela é paga em 2026).
const RE_DATA_2025 = /\b\d{2}\/\d{2}\/2025\b|exerc[ií]cio anterior/i;
const eCompetencia2025 = l => RE_DATA_2025.test(l.historico) && l.tipo !== 'CARTAO' && l.tipo !== 'PROVISAO';
const TOLERANCIA = 50; // R$ — diferença por fornecedor/mês abaixo disso é arredondamento

module.exports = { RUBRICA_FORNECEDOR, ERP_2025, eCompetencia2025, naoOperacional, CONFIRMADOS, VINCULO_PJ, GAP_CONHECIDO, FORA_ESCOPO_FORNECEDOR, CONTAS_DA_SUBLINHA, ADS, ALIAS, RUBRICAS, FORA_ESCOPO_SUBLINHA, MOTIVO_FORA, CONTAS_FOLHA, CONTAS_PASSAGEM, CONTAS_NAO_OPERACIONAIS, TOLERANCIA };
