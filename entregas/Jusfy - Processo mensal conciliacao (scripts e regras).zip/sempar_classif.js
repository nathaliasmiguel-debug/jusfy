// Classifica cada linha do razão "sem par" com a evidência da base do ERP (que alimenta o P&L). Uso interno Jusfy.
const X = require('./cruza_sempar_erp.js');
const M = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'];
const fmt = v => 'R$ ' + Math.round(v).toLocaleString('pt-BR');
const cat = x => {
  const n = x.ch + ' ' + (x.l.fornecedor || '');
  const h = x.hit;
  if (/FOPAG/i.test(n)) return ['Folha sem cadastro no painel de pessoas', 'Linha da folha (Fopag) — bolsa-auxílio/provisão de estagiário. Não está no painel de pessoas, por isso não entra no P&L de RH.', 'Jusfy: incluir a pessoa no Cadastro/painel ou confirmar que fica fora.'];
  if (h && /Auxílio Educacional/i.test(h.classe)) return ['Está no P&L (linha de RH: auxílio educacional)', 'No ERP: ' + h.classe + ', competência ' + h.comp + ', ' + fmt(h.v) + '. Entra no P&L dentro de "HR Expenses & Payroll".', 'Nada a fazer — casado.'];
  if (/CURSOS TREINAMENTOS/.test(x.ch) && x.l.mes === 'Jan') return ['Está no P&L (linha de RH: auxílio educacional)', 'Provisão de cursos de jan (R$ 9.040) feita a pedido da Jusfy: completa o auxílio educacional de jan do ERP (R$ 13.800 = Lucas 2.700 + CSP 2.060 + provisão 9.040).', 'Nada a fazer — casado.'];
  if (/CSP TREINAMENTO/.test(x.ch) && x.l.mes === 'Jan') return ['Está no P&L (linha de RH: auxílio educacional)', 'Parte do auxílio educacional de jan do ERP (R$ 13.800).', 'Nada a fazer — casado.'];
  if (/MAGAZINE LUIZA/.test(x.ch)) return ['Possível lançamento em dobro no razão', 'As notas de jun citam os mesmos números das notas de abril (que já estão certas, em brindes), com valor um pouco diferente e em conta de custo de software.', 'Syhus confirma se é repetição; se for, excluir.'];
  if (h && /identificar/i.test(h.classe)) return ['No ERP, mas ainda sem classificação', 'No ERP como "identificar" (' + h.conta + ', ' + h.comp + ', ' + fmt(h.v) + '): por isso não chegou ao P&L.', 'Jusfy: classificar no ERP (em qual linha do P&L entra).'];
  if (h) return ['No ERP em outra linha/mês', 'No ERP: ' + h.classe + ' (' + h.conta + '), competência ' + h.comp + ', ' + fmt(h.v) + '.', 'Jusfy: confirmar em qual linha do P&L está.'];
  return ['Não está no ERP nem no P&L', 'Nenhum pagamento deste fornecedor na base do ERP (out/25 a ago/26) com esse valor.', 'Jusfy: é despesa da Jusfy? Se sim, entra no ERP/P&L; se não, a Syhus tira do razão.'];
};
const linhas = X.map(x => { const [categoria, evidencia, acao] = cat(x); return { fornecedor: x.l.fornecedor || x.ch, mes: x.l.mes, conta: x.l.conta, valor: x.l.valor, categoria, evidencia, acao }; })
  .sort((a, b) => a.categoria.localeCompare(b.categoria) || Math.abs(b.valor) - Math.abs(a.valor));
require('fs').writeFileSync('sempar_classif.json', JSON.stringify(linhas, null, 1));
const resumo = {}; linhas.forEach(l => { resumo[l.categoria] = resumo[l.categoria] || { n: 0, v: 0 }; resumo[l.categoria].n++; resumo[l.categoria].v += l.valor; });
Object.entries(resumo).forEach(([k, o]) => console.log(k.padEnd(48), String(o.n).padStart(3), 'linhas', fmt(o.v).padStart(12)));
console.log('TOTAL', linhas.length, 'linhas', fmt(linhas.reduce((s, l) => s + l.valor, 0)));
