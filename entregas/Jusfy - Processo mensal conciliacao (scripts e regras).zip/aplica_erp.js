// Passo depois do ajusta_distratos.js: usa o casamento nota a nota com o ERP (base da Mari) nos fornecedor-mês em que o
// razão tem mais que o P&L (VERIFICAR).
// 1) NF que está no ERP em outro mês: provisiona no mês certo (competência do ERP) e baixa no mês em que a Syhus lançou.
//    Competência 2025 → nota explicativa (exercício encerrado). Competência jul/2026 → reverter no mês lançado.
//    Só entra se aproxima do P&L nos dois meses (nunca piora o fornecedor).
// 2) O que sobra fica como pendência, separada por motivo: Google Ads (P&L ≠ ERP), NF fora do ERP (tesouraria valida),
//    lançamento sem nº de NF (pedir à Syhus), imposto retido (razão bruto × ERP líquido), e o resto pra Nathalia classificar.
const fs = require('fs');
const path = require('path');
const arq = path.join(__dirname, 'achados.json');
const A = require(arq);
if ((A.ajustes || []).includes('erp')) { console.log('achados.json já tem o passo do ERP'); process.exit(0); }
const { out, nomeMes, M } = require('./verif_classif.js');
const r2 = x => Math.round(x * 100) / 100;
const f = v => 'R$ ' + r2(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const nfTxt = l => (l.nf && !/^(FATURA|RECIBO)$/i.test(l.nf) ? 'NF ' + l.nf : l.nf === 'FATURA' ? 'fatura do cartão' : l.nf === 'RECIBO' ? 'recibo' : 'lançamento sem nº') + ' de ' + f(l.valor);
const semNumero = l => !l.nf || /^s\/n/i.test(l.nf);
let seq = 0; const log = [];
// por fornecedor: junta as NFs "em outro mês" de todos os meses com diferença e escolhe, uma a uma, a que mais aproxima
// o fornecedor do P&L somando os seis meses (assim uma NF lançada sempre um mês atrasada anda em cadeia). Para quando
// nenhuma aproxima mais.
const porCaso = {};
out.forEach(o => { (porCaso[o.caso] = porCaso[o.caso] || []).push(o); });
Object.entries(porCaso).forEach(([nome, os]) => {
  const c = A.casos.find(c => c.nome === nome);
  // diferença do fornecedor no mês depois dos ajustes que ele já tem (mesma régua do VERIFICAR); reclassificação não muda o total
  const gap = {}; M.forEach(m => { gap[m] = r2((c.razMes[m] || 0) - (c.alvoMes[m] || 0)); });
  // "provisionar a diferença" (sem NF) fica de fora: se o ERP prova qual NF falta no mês, a provisão com NF substitui a genérica
  const generica = a => a.tipo === 'PROVISIONAR' && /a menos que o gerencial/.test(a.texto || '');
  c.acoes.filter(a => a.tipo !== 'VERIFICAR' && a.tipo !== 'RECLASSIFICAR' && !generica(a) && M.includes(a.mes)).forEach(a => { gap[a.mes] = r2(gap[a.mes] + a.valor); });
  const mesma = (x, y) => x.mes === y.mes && x.conta === y.conta && Math.abs(x.valor - y.valor) < 0.01 && (x.nf || '') === (y.nf || '') && x.historico === y.historico;
  const jaTratadas = c.acoes.filter(a => a.tipo !== 'VERIFICAR').flatMap(a => a.lanc || []);
  const gen0 = {}; c.acoes.filter(generica).forEach(a => { gen0[a.mes] = (gen0[a.mes] || 0) + a.valor; });
  os.forEach(o => { if (Math.abs(gap[o.mes] + (gen0[o.mes] || 0) - o.E) > 1) console.log('AVISO régua', nome, o.mes, gap[o.mes], o.E); });
  const novas = [];
  if (!/^Google Ads/.test(nome)) {
    const cand = os.flatMap(o => o.linhas.filter(x => x.st === 'timing' && !jaTratadas.some(y => mesma(x.l, y))).map(x => ({ ...x, mes: o.mes })));
    const ganho = x => { const md = x.dest >= 0 && x.dest < 6 ? M[x.dest] : null; const v = x.l.valor;
      return Math.abs(gap[x.mes]) - Math.abs(gap[x.mes] - v) + (md ? Math.abs(gap[md]) - Math.abs(gap[md] + v) : 0); };
    for (;;) {
      const x = cand.filter(x => !x.usado).sort((p, q) => ganho(q) - ganho(p))[0];
      if (!x || ganho(x) <= 0.5) break;
      x.usado = true;
      const v = x.l.valor, quando = x.erp.fornecedor + ', competência ' + nomeMes(x.dest) + ' no ERP';
      if (x.dest >= 0 && x.dest < 6) {
        const md = M[x.dest], par = 'erp' + (++seq);
        novas.push({ tipo: 'PROVISIONAR', mes: md, conta: x.l.conta, valor: r2(v), lanc: [x.l], erp: true, par,
          texto: 'A ' + nfTxt(x.l) + ' foi lançada em ' + x.mes + ', mas é de ' + md + ' (' + quando + '). Provisionar em ' + md + '.' });
        novas.push({ tipo: 'BAIXAR PROVISÃO', mes: x.mes, conta: x.l.conta, valor: r2(-v), lanc: [x.l], erp: true, par,
          texto: 'Baixar em ' + x.mes + ' a provisão de ' + md + ': a ' + nfTxt(x.l) + ' lançada aqui é de ' + md + ' (' + quando + ').' });
        gap[md] = r2(gap[md] + v);
      } else if (x.dest < 0) {
        novas.push({ tipo: 'COMPETÊNCIA 2025', mes: x.mes, conta: x.l.conta, valor: r2(-v), lanc: [x.l], erp: true,
          texto: 'A ' + nfTxt(x.l) + ' lançada em ' + x.mes + ' é de ' + nomeMes(x.dest) + ' (' + quando + '). Exercício 2025 encerrado: fica em 2026 e entra na nota explicativa.' });
      } else {
        novas.push({ tipo: 'REVERTER (NF adiantada)', mes: x.mes, conta: x.l.conta, valor: r2(-v), lanc: [x.l], erp: true,
          texto: 'A ' + nfTxt(x.l) + ' foi lançada em ' + x.mes + ', mas é de jul/2026 (' + quando + '). Reverter em ' + x.mes + ' e reconhecer em jul.' });
      }
      gap[x.mes] = r2(gap[x.mes] - v);
      log.push(x.mes + ' ' + nome + ': ' + f(v) + ' → ' + nomeMes(x.dest));
    }
  }
  // provisão genérica: só o que ainda falta no mês depois das NFs provadas pelo ERP
  if (novas.length) c.acoes.filter(generica).forEach(a => {
    const falta = r2(Math.max(0, Math.min(a.valor, -gap[a.mes])));
    if (Math.abs(falta - a.valor) < 0.5) return;
    log.push('   provisão genérica ' + a.mes + ' ' + nome + ': ' + f(a.valor) + ' → ' + f(falta) + ' (NF provada pelo ERP)');
    if (falta < 0.5) a._remover = true; else { a.valor = falta; a.texto = 'Razão tem ' + f(falta) + ' a menos que o gerencial em ' + a.mes + ', além das NFs que o ERP prova. Provisionar a diferença em ' + a.mes + '.'; }
    gap[a.mes] = r2(gap[a.mes] + (a._remover ? 0 : a.valor));
  });
  const pend = [];
  os.forEach(o => {
    const a = c.acoes[o.ai];
    // quanto sobra neste mês: diferença do fornecedor depois das NFs movidas (e da provisão genérica que ficou)
    const E = r2(gap[o.mes] + c.acoes.filter(x => generica(x) && !x._remover && x.mes === o.mes).reduce((s, x) => s + x.valor, 0));
    const usadas = new Set(novas.flatMap(n => n.lanc));
    const add = (cat, v, linhas, texto) => { if (v > 0.5) pend.push({ tipo: 'VERIFICAR', mes: o.mes, conta: a.conta, valor: r2(-v), lanc: linhas.map(x => x.l), semLancar: true, cat, linhasCat: linhas.map(x => ({ l: x.l, ret: x.ret, erpValor: x.erp ? Math.abs(x.erp.v) : null, erpMes: x.erp ? nomeMes(x.erp.i) : null, st: x.st })), texto }); };
    if (E <= 0.5) return;
    if (/^Google Ads/.test(nome)) return add('google', E, [], 'Google Ads: a soma das NFs do Google no razão é igual à base da Mari (ERP) na competência; o P&L está com outro valor. Ajustar o P&L.');
    let resto = E;
    const fora = o.linhas.filter(x => x.st === 'fora' && x.l.valor >= 1);
    const comNum = fora.filter(x => !semNumero(x.l)), semNum = fora.filter(x => semNumero(x.l));
    const liq = o.linhas.filter(x => x.st === 'liquido');
    const ret = liq.reduce((s, x) => s + x.ret, 0);
    const TXT_RET = 'NF lançada pelo valor bruto; o ERP tem o valor líquido pago (imposto retido na fonte).';
    if (ret > 0 && Math.abs(resto - ret) <= Math.max(5, resto * 0.03)) { add('retencao', resto, liq, TXT_RET); resto = 0; }
    const vT = Math.min(resto, comNum.reduce((s, x) => s + x.l.valor, 0)); add('tesouraria', vT, comNum, 'Nota que não está na base da Mari (ERP). Tesouraria confirma se foi paga e se é da Jusfy; se não for, a Syhus exclui.'); resto = r2(resto - vT);
    const vS = Math.min(resto, semNum.reduce((s, x) => s + x.l.valor, 0)); add('pedirNF', vS, semNum, 'Lançamento sem nº de NF e que não aparece no ERP por fornecedor e valor. Pedir a nota à Syhus.'); resto = r2(resto - vS);
    if (ret > 0 && resto > 0.5) { const vR = Math.min(resto, ret); add('retencao', vR, liq, TXT_RET); resto = r2(resto - vR); }
    const outroMes = o.linhas.filter(x => x.st === 'timing' && !usadas.has(x.l));
    if (outroMes.length) {
      const vO = Math.min(resto, outroMes.reduce((s, x) => s + x.l.valor, 0));
      add('outroMesCompleto', vO, outroMes, 'A nota está na base da Mari em outro mês, mas o razão desse outro mês já tem a nota dele: mover faria o outro mês ficar a mais. Parece a mesma nota lançada duas vezes, ou falta no ERP a deste mês.'); resto = r2(resto - vO);
    }
    add('classificar', resto, o.linhas.filter(x => x.st === 'ok'), 'As notas do razão estão na base da Mari no mesmo mês, mas o P&L tem menos para este fornecedor.');
  });
  os.forEach(o => { c.acoes[o.ai]._remover = true; });
  c.acoes.push(...novas, ...pend);
});
A.casos.forEach(c => { c.acoes = c.acoes.filter(a => !a._remover); });
A.ajustes = (A.ajustes || []).concat(['erp']);
fs.writeFileSync(arq, JSON.stringify(A));
log.forEach(x => console.log(x));
